package com.rumango.soap;

import java.math.BigDecimal;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.ws.api.accservice.CREATECUSTACCFSFSREQ;
import com.ws.api.client.ClServiceImpl;
import com.ws.api.clservice.AccountFullType;
import com.ws.api.clservice.CREATEACCOUNTFSFSREQ;
import com.ws.api.clservice.CREATEACCOUNTFSFSREQ.FCUBSBODY;
import com.ws.api.clservice.CREATEACCOUNTFSFSRES;
import com.ws.api.customerservice.QUERYCUSTOMERIOFSRES;
import com.ws.api.util.SoapPasswordService;
@Service
public class CLServiceImpl {
	SoapPasswordService soapPasswordService = new SoapPasswordService();
	ClServiceImpl clServiceImpl=new ClServiceImpl();
	
	com.ws.api.clservice.FCUBSHEADERType getHeader(){
		String messageId = "RMQA" + String.format("%08d", soapPasswordService.getSecureRandom().nextInt(100000000));
		com.ws.api.clservice.FCUBSHEADERType header1 = new com.ws.api.clservice.FCUBSHEADERType();
		com.ws.api.clservice.UBSCOMPType ubsType = com.ws.api.clservice.UBSCOMPType.fromValue("FCUBS");
		header1.setUBSCOMP(ubsType);
		header1.setSOURCE("FCAT");
		header1.setMSGID(messageId);
		header1.setCORRELID(messageId);
		header1.setUSERID("ADMINUSER1");
		header1.setPASSWORD(soapPasswordService.encryptPassword(messageId));
		header1.setBRANCH("000");
		header1.setSERVICE("FCUBSCLService");
		header1.setMODULEID("DE");
		return header1;
	}
//	ResponseEntity<?> res=  customerServiceClient.queryCustomerIO(req);
//    com.ws.api.customerservice.QUERYCUSTOMERIOFSRES.FCUBSBODY res1=(QUERYCUSTOMERIOFSRES.FCUBSBODY) res.getBody();
//
//    System.out.println("new resp"+res1.getCustomerFull().getCUSTNO());	

	public void createAccount() {
		
		com.ws.api.clservice.FCUBSHEADERType header=getHeader();
		header.setMODULEID("CL");
		header.setOPERATION("CreateAccount");
		header.setSOURCEOPERATION("CreateAccount");
		header.setFUNCTIONID("CLDACCNT");
		header.setACTION("NEW");
		
		CREATEACCOUNTFSFSREQ req = new CREATEACCOUNTFSFSREQ();

		CREATEACCOUNTFSFSREQ.FCUBSBODY body = new CREATEACCOUNTFSFSREQ.FCUBSBODY();
		body.setAccountMasterFull(null);
		AccountFullType  ioType=new AccountFullType ();
		ioType.setBRN("000");
		ioType.setPROD("2020");
		ioType.setCUSTID("000048");
		ioType.setCCY("INR");
		ioType.setAMTFINANCED(new BigDecimal(1000));
		req.setFCUBSBODY(body);
		req.setFCUBSHEADER(header);
		ResponseEntity<?> res=  clServiceImpl.createAccountFS(req);
	   FCUBSBODY  res1=(CREATEACCOUNTFSFSREQ.FCUBSBODY) res.getBody();
	
	    System.out.println("new resp"+res1.getAccountMasterFull().getACCNO());
	}
}
