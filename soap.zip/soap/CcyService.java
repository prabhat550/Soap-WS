package com.rumango.soap;

public class CcyService {

}
