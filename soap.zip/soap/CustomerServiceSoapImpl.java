package com.rumango.soap;

import java.math.BigDecimal;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.ws.api.client.CustomerServiceClient;
import com.ws.api.customerservice.*;
import com.ws.api.customerservice.CREATECUSTOMERFSFSRES.FCUBSBODY;
import com.rumango.config.PropertyConfiguration;
import com.rumango.icust.client.FlexCubeCient;
import com.rumango.icust.entity.IcustCustomerInfo;
import com.rumango.icust.model.CustomerCreateOrUpdateModel;
import com.ws.api.util.SoapPasswordService;

@Service
public class CustomerServiceSoapImpl {
	@Autowired
	RestTemplate  restTemplate;
	
	@Autowired
	FlexCubeCient flexCubeCient;

	@Autowired
	PropertyConfiguration propertyConfiguration;
	

	CustomerServiceClient customerServiceClient=new CustomerServiceClient();
		
	public com.ws.api.customerservice.FCUBSHEADERType createHeaderCustomer() {
		SoapPasswordService soapPasswordService = new SoapPasswordService();
		String messageId = "RMQA" + String.format("%08d", soapPasswordService.getSecureRandom().nextInt(100000000));
		com.ws.api.customerservice.FCUBSHEADERType header = new com.ws.api.customerservice.FCUBSHEADERType();
		com.ws.api.customerservice.UBSCOMPType ubsType = com.ws.api.customerservice.UBSCOMPType.fromValue("FCUBS");
		header.setUBSCOMP(ubsType);
		header.setSOURCE("FCAT");
		header.setMSGID(messageId);
		header.setCORRELID(messageId);
		header.setUSERID("ADMINUSER1");

		header.setBRANCH("102");
		header.setMODULEID("ST");
		header.setSERVICE("FCUBSCustomerService");
		return header;
	}
	
	public QUERYCUSTOMERIOFSREQ queryCustomerIo(String customerNo) {
		com.ws.api.customerservice.FCUBSHEADERType	header=	createHeaderCustomer();
		header.setOPERATION("QueryCustomer");
		header.setSOURCEOPERATION("QueryCustomer");
		//header.setFUNCTIONID("STDCIF");
		header.setMODULEID("ST");
	//	header.setACTION("NEW");

		
		QUERYCUSTOMERIOFSREQ req = new QUERYCUSTOMERIOFSREQ();
		QUERYCUSTOMERIOFSREQ.FCUBSBODY body = new QUERYCUSTOMERIOFSREQ.FCUBSBODY();
		CustomerQueryIOType query = new CustomerQueryIOType();
		
		query.setCUSTNO(customerNo);
		body.setCustomerIO(query);

		req.setFCUBSHEADER( header );
		req.setFCUBSBODY(body);
		System.out.println(req.toString());
		  ResponseEntity<?> res=  customerServiceClient.queryCustomerIO(req);
		    com.ws.api.customerservice.QUERYCUSTOMERIOFSRES.FCUBSBODY res1=(QUERYCUSTOMERIOFSRES.FCUBSBODY) res.getBody();

		    System.out.println("new resp"+res1.getCustomerFull().getCUSTNO());
		return req;
	
	}
	
	public QUERYCUSTSEGASSOCIATIONIOFSREQ queryCustSegAssociationIO(String customerNo) {
		QUERYCUSTSEGASSOCIATIONIOFSREQ req = new QUERYCUSTSEGASSOCIATIONIOFSREQ();
		QUERYCUSTSEGASSOCIATIONIOFSREQ.FCUBSBODY body = new QUERYCUSTSEGASSOCIATIONIOFSREQ.FCUBSBODY();
		CustSegAssociationQueryIOType query = new CustSegAssociationQueryIOType();
		query.setCUSTNO(customerNo);
		body.setCustSegMappingIO(query);
		
		req.setFCUBSHEADER(createHeaderCustomer());
		req.setFCUBSBODY(body);
		
		return req;
		
	}
	
	public QUERYNSFCBENQIOFSREQ queryNSFCBenqIO(BigDecimal upSeq) {
		QUERYNSFCBENQIOFSREQ req = new QUERYNSFCBENQIOFSREQ();
		QUERYNSFCBENQIOFSREQ.FCUBSBODY body = new QUERYNSFCBENQIOFSREQ.FCUBSBODY();
		StdncbqyQueryIOType query = new StdncbqyQueryIOType();
		query.setUPSEQ(upSeq);
		body.setCbDetIO(query);
		
		req.setFCUBSHEADER(createHeaderCustomer());
		req.setFCUBSBODY(body);
		
		return req;
	}
	
	public QUERYNSFCHECKIOFSREQ queryNSFCheckIO(String branchCode, String customerNo) {
		QUERYNSFCHECKIOFSREQ req = new QUERYNSFCHECKIOFSREQ();
		QUERYNSFCHECKIOFSREQ.FCUBSBODY body = new QUERYNSFCHECKIOFSREQ.FCUBSBODY();
		StdnsfqyQueryIOType query = new StdnsfqyQueryIOType();
		query.setBRANCHCODE(branchCode);
		query.setCUSTOMERNO(customerNo);
		body.setNsfEnqIO(query);
		
		req.setFCUBSHEADER(createHeaderCustomer());
		req.setFCUBSBODY(body);
		
		return req;
		
	}
	
	public QUERYNSFMUTUALIOFSREQ queryNSFMutualIO(String refNo) {
		QUERYNSFMUTUALIOFSREQ req = new QUERYNSFMUTUALIOFSREQ();
		QUERYNSFMUTUALIOFSREQ.FCUBSBODY body = new QUERYNSFMUTUALIOFSREQ.FCUBSBODY();
		StdnsfmsQueryIOType query = new StdnsfmsQueryIOType();
		query.setREFNO(refNo);
		body.setMutClrIO(query);
		
		req.setFCUBSHEADER(createHeaderCustomer());
		req.setFCUBSBODY(body);
		
		return req;
		
	}
	
	public QUERYTDAMOUNTBLOCKIOFSREQ queryTDAmountBlockIO(String amtBlkNo) {
		QUERYTDAMOUNTBLOCKIOFSREQ req = new QUERYTDAMOUNTBLOCKIOFSREQ();
		QUERYTDAMOUNTBLOCKIOFSREQ.FCUBSBODY body = new QUERYTDAMOUNTBLOCKIOFSREQ.FCUBSBODY();
		TDAmountBlockQueryIOType query = new TDAmountBlockQueryIOType();
		query.setAMTBLKNO(amtBlkNo);
		body.setAmountBlocksIO(query);
		
		req.setFCUBSHEADER(createHeaderCustomer());
		req.setFCUBSBODY(body);
		
		return req;
	}
	
	public CREATEACCOUNTSTRUCTUREFSFSREQ createAccountStructureFS() {
		CREATEACCOUNTSTRUCTUREFSFSREQ req = new CREATEACCOUNTSTRUCTUREFSFSREQ();
		CREATEACCOUNTSTRUCTUREFSFSREQ.FCUBSBODY body = new CREATEACCOUNTSTRUCTUREFSFSREQ.FCUBSBODY();
		StructureFullType model = new StructureFullType();
		model.setAUTHSTAT(null);
		model.setCHECKER(null);
		model.setCHECKERSTAMP(null);
		model.setGRPDESC(null);
		model.setMAKER(null);
		model.setMAKERSTAMP(null);
		model.setMODNO(null);
		model.setSTRUCTG(null);
		model.setTXNSTAT(null);
		
		body.setStructFull(model);
		
		req.setFCUBSHEADER(createHeaderCustomer());
		req.setFCUBSBODY(body);
		
		return req;
	}
	
	public CREATEACCOUNTSTRUCTUREIOPKREQ createAccountStructureIO() {
		CREATEACCOUNTSTRUCTUREIOPKREQ req = new CREATEACCOUNTSTRUCTUREIOPKREQ();
		CREATEACCOUNTSTRUCTUREIOPKREQ.FCUBSBODY body = new CREATEACCOUNTSTRUCTUREIOPKREQ.FCUBSBODY();
		StructureCreateIOType model = new StructureCreateIOType();
		
		model.setGRPDESC(null);
		model.setSTRUCTG(null);
		
		body.setStructIO(model);
		
		req.setFCUBSBODY(body);
		req.setFCUBSHEADER(createHeaderCustomer());
		
		return req;
	}
	
	
	public IcustCustomerInfo createCustomerFS(IcustCustomerInfo req) {
		com.ws.api.customerservice.FCUBSHEADERType	header=	createHeaderCustomer();
		header.setOPERATION("CreateCustomer");
		header.setSOURCEOPERATION("CreateCustomer");
		header.setFUNCTIONID("STDCIF");
		header.setMODULEID("ST");
		header.setACTION("NEW");
		com.ws.api.customerservice.CustomerFullType ioType = new com.ws.api.customerservice.CustomerFullType();

		com.ws.api.customerservice.CREATECUSTOMERFSFSREQ.FCUBSBODY body = new com.ws.api.customerservice.CREATECUSTOMERFSFSREQ.FCUBSBODY();

		ioType.setACCESSGROUP(null);
		ioType.setADDRLN1(null);
		ioType.setADDRLN2(null);
		ioType.setADDRLN3(null);
		ioType.setADDRLN4(null);
		ioType.setALGID(null);
		ioType.setAMLCUSTGRP(null);
		ioType.setAMLREQD(null);
		ioType.setARAPTRACKING(null);
		ioType.setAUTHSTAT(null);
		ioType.setAUTOGENSTMTPLAN(null);
		ioType.setCTYPE(req.getCustomerTypeId());
		ioType.setCCATEG(null);
		ioType.setCHECKER(null);
		ioType.setCHECKERSTAMP(null);
		ioType.setCHGGRP(null);
		ioType.setCHKDIGITVALREQD(null);
		ioType.setCIFCREATIONDT(null);
		ioType.setCIFSTAT(null);
		ioType.setCIFSTATSNC(null);
		ioType.setCLSCCYALLWD(null);
		ioType.setCONSTAXCERTRQD(null);
		ioType.setCOUNTRY(null);
		ioType.setCREATEACC(null);
		ioType.setCREATEDACCOUNT(null);
		ioType.setCRMCUST(null);
		ioType.setCRSCUSTTYPE(null);
		ioType.setCTYPE(null);
		ioType.setCustAccDet(null);
		ioType.setCustAccount(null);
		ioType.setCustacdetail(null);
		ioType.setCUSTCLASSFN(null);
		ioType.setCUSTCLGGRP(null);
		ioType.setCustcorp(null);
		ioType.setCustLiab(null);
		ioType.setCustmis(null);
		ioType.setCUSTNO(req.getCustomerId().toString());
		ioType.setCustpersonal(null);
		ioType.setCustsegment(null);
		ioType.setCUSTUNADV(null);
		ioType.setDEAD(null);
		ioType.setDoctypeRemarks(null);
		ioType.setDRCAT(null);
		ioType.setExtsysWsMaster(null);
		ioType.setFLGJOINT(null);
		ioType.setFLGUTLTYPRVDR(null);
		ioType.setFREQ(null);
		ioType.setFROZEN(null);
		ioType.setFTACCASOF(null);
		ioType.setFULLNAME(null);
		ioType.setFXCLEANRISK(null);
		ioType.setFXCUSTCLRILIM(null);
		ioType.setFXNETTCUST(null);
		ioType.setGRPCD(null);
		ioType.setHOACNO(null);
		ioType.setIdMaster(null);
		ioType.setINDTAXCERTRQD(null);
		ioType.setJointcustomer(null);
		ioType.setLBRN(null);
		ioType.setLCCOLLATPCT(null);
		ioType.setLIABID(null);
		ioType.setLIABUNADV(null);
		ioType.setLMCCY(null);
		ioType.setLOC(null);
		ioType.setMAILRSREQD(null);
		ioType.setMAKER(null);
		ioType.setMAKERSTAMP(null);
		ioType.setMaster(null);
		ioType.setMEDIA(null);
		ioType.setMfi1(null);
		ioType.setMFICUSTOMER(null);
		ioType.setMODNO(null);
		ioType.setMT920(null);
		ioType.setNAME(req.getFirstName() + req.getMiddleName() + req.getLastName());
		ioType.setNETTREQD(null);
		ioType.setNLTY(req.getNationality());
		ioType.setNsfEnq(null);
		ioType.setOVRLIM(null);
		ioType.setPADDRESSCODE(null);
		ioType.setPINCODE(null);
		ioType.setPRIVATECUSTOMER(null);
		ioType.setRELPRICING(null);
		ioType.setREVDT(null);
		ioType.setRISKCATEG(null);
		ioType.setRISKPRFL(null);
		ioType.setRMID(null);
		ioType.setSANCHKREQATTXNLVL(null);
		ioType.setSECCLRILIM(null);
		ioType.setSECCUSTCLRILIM(null);
		ioType.setSECPSRILIM(null);
		ioType.setSNAME(null);
		ioType.setSPECIALCUST(null);
		ioType.setSSN(null);
		ioType.setSSTAFF(null);
		ioType.setSTMTDAY(null);
		ioType.setSttmsDebit(null);
		ioType.setSWIFTCD(null);
		ioType.setTAXCNTRY(null);
		ioType.setTAXGROUP(null);
		ioType.setTAXIDENTITY(null);
		ioType.setTRACKLIMITS(null);
		ioType.setTXNSTAT(null);
		ioType.setUDF1(null);
		ioType.setUDF2(null);
		ioType.setUDF3(null);
		ioType.setUDF4(null);
		ioType.setUDF5(null);
		ioType.setUDFLBL1(null);
		ioType.setUDFLBL2(null);
		ioType.setUDFLBL3(null);
		ioType.setUDFLBL4(null);
		ioType.setUDFLBL5(null);
		ioType.setUIDNAME(null);
		ioType.setUIDVAL(null);
		ioType.setUPTYPE(null);
		ioType.setUTLTYPRVDRID(null);
		ioType.setWHRUNKN(null);
		ioType.setWITHHOLDINGTAXAP(null);
		ioType.setXREF(null);
		// ioType.setCustAccDet(null);

		body.setCustomerFull(ioType);

		com.ws.api.customerservice.CREATECUSTOMERFSFSREQ newreq = new com.ws.api.customerservice.CREATECUSTOMERFSFSREQ();
		newreq.setFCUBSHEADER(header);
		newreq.setFCUBSBODY(body);

	    ResponseEntity<?> res=  customerServiceClient.createCustomerFS(newreq);
	    FCUBSBODY res1=(CREATECUSTOMERFSFSRES.FCUBSBODY) res.getBody();
	    System.out.println(res);
	    System.out.println("new resp"+res1.getCustomerFull());
	    System.out.println("new resp"+res1.getCustomerFull().getNAME());
	    CustomerCreateOrUpdateModel res3=new CustomerCreateOrUpdateModel();
		return req;
	}
	
	
	public CREATECUSTOMERIOPKREQ createCustomerIO() {
		com.ws.api.customerservice.FCUBSHEADERType	header=	createHeaderCustomer();
		header.setOPERATION("CreateCustomer");
		header.setSOURCEOPERATION("CreateCustomer");
		header.setFUNCTIONID("STDCIF");
		header.setMODULEID("ST");
		header.setACTION("NEW");
		CREATECUSTOMERIOPKREQ req = new CREATECUSTOMERIOPKREQ();
		CREATECUSTOMERIOPKREQ.FCUBSBODY body = new CREATECUSTOMERIOPKREQ.FCUBSBODY();
		CustomerCreateIOType model = new CustomerCreateIOType();
		
		model.setADDRLN1(null);
		model.setADDRLN2(null);
		model.setADDRLN3(null);
		model.setADDRLN4(null);
		model.setALGID(null);
		model.setAMLCUSTGRP(null);
		model.setAMLREQD(null);
		model.setARAPTRACKING(null);
		model.setCCATEG(null);
		model.setCHGGRP(null);
		model.setCHKDIGITVALREQD(null);
		model.setCIFCREATIONDT(null);
		model.setCIFSTAT(null);
		model.setCIFSTATSNC(null);
		model.setCLSCCYALLWD(null);
	
		model.setCONSTAXCERTRQD(null);
		model.setCOUNTRY(null);
		model.setCREATEACC(null);
		model.setCRMCUST(null);
		
		model.setCTYPE(null);
		model.setCustAccDet(null);
		model.setCustaccdet(null);
		model.setCustAccount(null);
		model.setCustacdetail(null);
		model.setCUSTCLASSFN(null);
		model.setCUSTCLGGRP(null);
		model.setCustcorp(null);
		model.setCustLiab(null);
		model.setCustmis(null);
		model.setCUSTNO(null);
		model.setCustpersonal(null);
		model.setCustsegment(null);
		model.setCUSTUNADV(null);
		model.setDEAD(null);
		model.setDoctypeRemarks(null);
		model.setDRCAT(null);
	
		model.setExtsysWsMaster(null);
		model.setFLGJOINT(null);
		model.setFLGUTLTYPRVDR(null);
		model.setFROZEN(null);
		model.setFTACCASOF(null);
		model.setFULLNAME(null);
		model.setFXCLEANRISK(null);
		model.setFXCUSTCLRILIM(null);
		model.setFXNETTCUST(null);
		model.setGRPCD(null);
		model.setHOACNO(null);
		model.setINDTAXCERTRQD(null);
		
		model.setJointcustomer(null);
		model.setLBRN(null);
		model.setLCCOLLATPCT(null);
		model.setLIABID(null);
		model.setLIABUNADV(null);
		model.setLMCCY(null);
		model.setLOC(null);
		model.setMAILRSREQD(null);
		model.setMaster(null);
		model.setMEDIA(null);
		model.setMT920(null);
		model.setNAME(null);
		model.setNETTREQD(null);
		model.setNLTY(null);
		model.setNsfEnq(null);
		model.setOVRLIM(null);
		model.setPRIVATECUSTOMER(null);
		model.setRELPRICING(null);
		model.setREVDT(null);
		model.setRISKCATEG(null);
		model.setRISKPRFL(null);
		model.setRMID(null);
		model.setSECCLRILIM(null);
		model.setSNAME(null);
		model.setSECCUSTCLRILIM(null);
		model.setSSN(null);
		model.setSttmsDebit(null);
		model.setSWIFTCD(null);
		model.setTAXGROUP(null);
		model.setTRACKLIMITS(null);
	
		model.setUDF1(null);
		model.setUDF2(null);
		model.setUDF3(null);
		model.setUDF4(null);
		model.setUDF5(null);
		model.setUIDNAME(null);
		model.setUIDVAL(null);
		model.setUPTYPE(null);
		model.setUTLTYPRVDRID(null);
		model.setWHRUNKN(null);
		model.setXREF(null);
		
		body.setCustomerIO(model);
		req.setFCUBSBODY(body);
		req.setFCUBSHEADER(header);
		
		  ResponseEntity<?> res=  customerServiceClient.createCustomerIO(req);
		    FCUBSBODY res1=(CREATECUSTOMERFSFSRES.FCUBSBODY) res.getBody();
		    System.out.println(res);
		    System.out.println("new resp"+res1.getCustomerFull());
		    System.out.println("new resp"+res1.getCustomerFull().getNAME());
		return req;
		
	}
	
	public CREATECUSTSEGASSOCIATIONFSFSREQ createCustSegAssociationFS() {
		CREATECUSTSEGASSOCIATIONFSFSREQ req = new CREATECUSTSEGASSOCIATIONFSFSREQ();
		CREATECUSTSEGASSOCIATIONFSFSREQ.FCUBSBODY body = new CREATECUSTSEGASSOCIATIONFSFSREQ.FCUBSBODY();
		CustSegAssociationFullType model = new CustSegAssociationFullType();
		model.setAUTHSTAT(null);
		model.setCHECKER(null);
		model.setCHECKERSTAMP(null);
		model.setCUSTCCY(null);
		model.setCUSTNO(null);
		model.setCUSTSEGCD(null);
		model.setCUSTSEGSTATUS(null);
		model.setMAKER(null);
		model.setMAKERSTAMP(null);
		model.setMODNO(null);
		model.setNETWORTH(null);
		model.setNETWORTHCCY(null);
		model.setSEGEMENTDESCRIPTION(null);
		model.setTXNSTAT(null);
		
		body.setCustSegMappingFull(model);
		req.setFCUBSBODY(body);
		req.setFCUBSHEADER(createHeaderCustomer());
		
		return req;
	}
	
	public CREATECUSTSEGASSOCIATIONIOPKREQ createCustSegAssociationIO() {
		CREATECUSTSEGASSOCIATIONIOPKREQ req = new CREATECUSTSEGASSOCIATIONIOPKREQ();
		CREATECUSTSEGASSOCIATIONIOPKREQ.FCUBSBODY body = new CREATECUSTSEGASSOCIATIONIOPKREQ.FCUBSBODY();
		CustSegAssociationCreateIOType model = new CustSegAssociationCreateIOType();
		model.setCUSTCCY(null);
		model.setCUSTNO(null);
		model.setCUSTSEGCD(null);
		model.setCUSTSEGSTATUS(null);
		
		body.setCustSegMappingIO(model);
		
		req.setFCUBSBODY(body);
		req.setFCUBSHEADER(createHeaderCustomer());
		
		return req;
	}
	
	public CREATENSFMUTUALFSFSREQ createNSFMutualFS() {
		CREATENSFMUTUALFSFSREQ req = new CREATENSFMUTUALFSFSREQ();
		CREATENSFMUTUALFSFSREQ.FCUBSBODY body = new CREATENSFMUTUALFSFSREQ.FCUBSBODY();
		StdnsfmsFullType model = new StdnsfmsFullType();
		model.setAUTHSTAT(null);
		model.setBranchCode(null);
		
		body.setMutClrFull(model);
		req.setFCUBSBODY(body);
		req.setFCUBSHEADER(createHeaderCustomer());
		
		return req;

	}
	
	public CREATENSFMUTUALIOPKREQ createNSFMutualIO() {
		CREATENSFMUTUALIOPKREQ req = new CREATENSFMUTUALIOPKREQ();
		CREATENSFMUTUALIOPKREQ.FCUBSBODY body = new CREATENSFMUTUALIOPKREQ.FCUBSBODY();
		StdnsfmsCreateIOType model = new StdnsfmsCreateIOType();
		model.setCHEQUENO(null);
		model.setCUSTOMERNO(null);
		model.setREFNO(null);
		model.setREMARKS(null);
		model.setSETTTXNSTAT(null);
		
		body.setMutClrIO(model);
		
		req.setFCUBSBODY(body);
		req.setFCUBSHEADER(createHeaderCustomer());
		return req;
	}
	
	public CREATETDAMOUNTBLOCKFSFSREQ createTDAmountBlockFS() {
		CREATETDAMOUNTBLOCKFSFSREQ req = new CREATETDAMOUNTBLOCKFSFSREQ();
		CREATETDAMOUNTBLOCKFSFSREQ.FCUBSBODY body = new CREATETDAMOUNTBLOCKFSFSREQ.FCUBSBODY();
		TDAmountBlockFullType model = new TDAmountBlockFullType();
		model.setABLKTYPE(null);
		model.setACC(null);
		model.setAMT(null);
		model.setAMTBLKNO(null);
		model.setAUTHSTAT(null);
		model.setBRANCH(null);
		model.setCHECKER(null);
		model.setCHECKERSTAMP(null);
		model.setEFFDATE(null);
		model.setEXPDATE(null);
		model.setHOLDDESC(null);
		model.setHPCODE(null);
		model.setMAKER(null);
		model.setMAKERSTAMP(null);
		model.setMODNO(null);
		model.setREFERENCENO(null);
		model.setREM(null);
		model.setTXNSTAT(null);
		
		body.setAmountBlocksFull(model);
		
		req.setFCUBSBODY(body);
		req.setFCUBSHEADER(createHeaderCustomer());
		
		return req;
	}
	
	public CREATETDAMOUNTBLOCKIOPKREQ createTDAmountBlockIO() {
		CREATETDAMOUNTBLOCKIOPKREQ req = new CREATETDAMOUNTBLOCKIOPKREQ();
		CREATETDAMOUNTBLOCKIOPKREQ.FCUBSBODY body = new CREATETDAMOUNTBLOCKIOPKREQ.FCUBSBODY();
		TDAmountBlockCreateIOType model = new TDAmountBlockCreateIOType();
		model.setABLKTYPE(null);
		model.setACC(null);
		model.setAMT(null);
		model.setAMTBLKNO(null);
		model.setEFFDATE(null);
		model.setEXPDATE(null);
		model.setHPCODE(null);
		model.setREFERENCENO(null);
		model.setREM(null);
		
		body.setAmountBlocksIO(model);
		
		req.setFCUBSBODY(body);
		req.setFCUBSHEADER(createHeaderCustomer());
		
		return req;
	}
}





































