//package com.rumango.soap;
//
//import java.math.BigDecimal;
//import java.util.Calendar;
//import java.util.GregorianCalendar;
//import java.util.HashMap;
//import java.util.Map;
//
//import javax.xml.datatype.DatatypeConfigurationException;
//import javax.xml.datatype.DatatypeFactory;
//import javax.xml.datatype.XMLGregorianCalendar;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpHeaders;
//import org.springframework.http.HttpMethod;
//import org.springframework.http.MediaType;
//import org.springframework.http.ResponseEntity;
//import org.springframework.stereotype.Service;
//
//import com.rumango.icust.model.CashDepositWithdrawalModel;
//import com.ws.api.accservice.AUTHORIZECHECKBOOKFSFSREQ;
//import com.ws.api.accservice.AUTHORIZECHECKBOOKIOPKREQ;
//import com.ws.api.accservice.AccBalReqType;
//import com.ws.api.accservice.AccBalReqType.ACCBAL;
//import com.ws.api.accservice.AccmaintinstrType;
//import com.ws.api.accservice.CLOSECHECKBOOKFSFSREQ;
//import com.ws.api.accservice.CLOSECHECKBOOKIOPKREQ;
//import com.ws.api.accservice.CLOSECUSTACCFSFSREQ;
//import com.ws.api.accservice.CLOSECUSTACCIOPKREQ;
//import com.ws.api.accservice.CLOSESTOPPAYMENTSFSFSREQ;
//import com.ws.api.accservice.CLOSESTOPPAYMENTSIOPKREQ;
//import com.ws.api.accservice.CREATEACCLASSTFRFSFSREQ;
//import com.ws.api.accservice.CREATEACCLASSTFRIOPKREQ;
//import com.ws.api.accservice.CREATECHECKBOOKFSFSREQ;
//import com.ws.api.accservice.CREATECHECKBOOKIOPKREQ;
//import com.ws.api.accservice.CREATECUSTACCFSFSREQ;
//import com.ws.api.accservice.CREATECUSTACCFSFSRES;
//import com.ws.api.accservice.CREATECUSTACCFSFSRES.FCUBSBODY;
//import com.ws.api.accservice.CREATECUSTACCIOPKREQ;
//import com.ws.api.accservice.CREATECUSTACCIOPKRES;
//import com.ws.api.accservice.CREATESTOPPAYMENTSFSFSREQ;
//import com.ws.api.accservice.CREATESTOPPAYMENTSIOPKREQ;
//import com.ws.api.accservice.CREATETDCUSTACCFSFSREQ;
//import com.ws.api.accservice.CREATETDCUSTACCIOPKREQ;
//import com.ws.api.accservice.CREATETDSIMFSFSREQ;
//import com.ws.api.accservice.CREATETDSIMIOPKREQ;
//import com.ws.api.accservice.CheckBookAuthorizeIOType;
//import com.ws.api.accservice.CheckBookCloseIOType;
//import com.ws.api.accservice.CheckBookCreateIOType;
//import com.ws.api.accservice.CheckBookDeleteIOType;
//import com.ws.api.accservice.CheckBookFullType;
//import com.ws.api.accservice.CheckBookModifyIOType;
//import com.ws.api.accservice.CheckBookQueryIOType;
//import com.ws.api.accservice.CheckBookReopenIOType;
//import com.ws.api.accservice.CustAccCloseIOType;
//import com.ws.api.accservice.CustAccCreateIOType;
//import com.ws.api.accservice.CustAccDeleteIOType;
//import com.ws.api.accservice.CustAccFullType;
//import com.ws.api.accservice.CustAccModifyIOType;
//import com.ws.api.accservice.CustAccQueryIOType;
//import com.ws.api.accservice.CustAccReopenIOType;
//import com.ws.api.accservice.CustAccTfrCreateIOType;
//import com.ws.api.accservice.CustAccTfrDeleteIOType;
//import com.ws.api.accservice.CustAccTfrFullType;
//import com.ws.api.accservice.CustAccTfrModifyIOType;
//import com.ws.api.accservice.CustAccTfrQueryIOType;
//import com.ws.api.accservice.CustAccType;
//import com.ws.api.accservice.CustAccTypeIO4;
//import com.ws.api.accservice.CustAccountMISFullType;
//import com.ws.api.accservice.DELETEACCLASSTFRFSFSREQ;
//import com.ws.api.accservice.DELETEACCLASSTFRIOPKREQ;
//import com.ws.api.accservice.DELETECHECKBOOKFSFSREQ;
//import com.ws.api.accservice.DELETECHECKBOOKIOPKREQ;
//import com.ws.api.accservice.DELETECUSTACCFSFSREQ;
//import com.ws.api.accservice.DELETECUSTACCIOPKREQ;
//import com.ws.api.accservice.DELETESTOPPAYMENTSFSFSREQ;
//import com.ws.api.accservice.DELETESTOPPAYMENTSIOPKREQ;
//import com.ws.api.accservice.DELETETDCUSTACCFSFSREQ;
//import com.ws.api.accservice.DELETETDCUSTACCIOPKREQ;
//import com.ws.api.accservice.FCUBSHEADERType;
//import com.ws.api.accservice.MODIFYACCLASSTFRFSFSREQ;
//import com.ws.api.accservice.MODIFYACCLASSTFRIOPKREQ;
//import com.ws.api.accservice.MODIFYCHECKBOOKFSFSREQ;
//import com.ws.api.accservice.MODIFYCHECKBOOKIOPKREQ;
//import com.ws.api.accservice.MODIFYCUSTACCFSFSREQ;
//import com.ws.api.accservice.MODIFYCUSTACCIOPKREQ;
//import com.ws.api.accservice.MODIFYSTOPPAYMENTSFSFSREQ;
//import com.ws.api.accservice.MODIFYSTOPPAYMENTSIOPKREQ;
//import com.ws.api.accservice.MODIFYTDCUSTACCFSFSREQ;
//import com.ws.api.accservice.MODIFYTDCUSTACCIOPKREQ;
//import com.ws.api.accservice.QUERYACCBALIOFSREQ;
//import com.ws.api.accservice.QUERYACCBALIOFSRES;
//import com.ws.api.accservice.QUERYACCLASSTFRIOFSREQ;
//import com.ws.api.accservice.QUERYACCSUMMIOFSREQ;
//import com.ws.api.accservice.QUERYCHECKBOOKIOFSREQ;
//import com.ws.api.accservice.QUERYCUSTACCIOFSREQ;
//import com.ws.api.accservice.QUERYGENADVICEIOFSREQ;
//import com.ws.api.accservice.QUERYSTOPPAYMENTSIOFSREQ;
//import com.ws.api.accservice.QUERYTDCUSTACCIOFSREQ;
//import com.ws.api.accservice.QueryAccSummQueryIOType;
//import com.ws.api.accservice.REOPENCHECKBOOKFSFSREQ;
//import com.ws.api.accservice.REOPENCHECKBOOKIOPKREQ;
//import com.ws.api.accservice.REOPENCUSTACCFSFSREQ;
//import com.ws.api.accservice.REOPENCUSTACCIOPKREQ;
//import com.ws.api.accservice.StdgnadvPKType;
//import com.ws.api.accservice.StopPaymentsCloseIOType;
//import com.ws.api.accservice.StopPaymentsCreateIOType;
//import com.ws.api.accservice.StopPaymentsDeleteIOType;
//import com.ws.api.accservice.StopPaymentsFullType;
//import com.ws.api.accservice.StopPaymentsModifyIOType;
//import com.ws.api.accservice.StopPaymentsQueryIOType;
//import com.ws.api.accservice.TDCustAccCreateIOType;
//import com.ws.api.accservice.TDCustAccDeleteIOType;
//import com.ws.api.accservice.TDCustAccFullType;
//import com.ws.api.accservice.TDCustAccModifyIOType;
//import com.ws.api.accservice.TDCustAccQueryIOType;
//import com.ws.api.accservice.UBSCOMPType;
//import com.ws.api.client.AccServiceImpl;
//import com.ws.api.util.SoapPasswordService;
//@Service
//public class AccSoapService {
//	
//	
////	@Autowired
////	PropertyConfiguration propertyConfiguration;
//	AccServiceImpl accServiceImpl=new AccServiceImpl();
//
//		
//	public FCUBSHEADERType createHeaderAccService() {
//		SoapPasswordService soapPasswordService = new SoapPasswordService();
//	String messageId = "RMQA" + String.format("%08d", soapPasswordService.getSecureRandom().nextInt(100000000));
//
//		FCUBSHEADERType header = new FCUBSHEADERType();
//		UBSCOMPType ubsType =UBSCOMPType.fromValue("FCUBS");
//		header.setUBSCOMP(ubsType);
//		header.setSOURCE("FCAT");
//		header.setMSGID(messageId);
//		header.setCORRELID(messageId);
//		header.setUSERID("ADMINUSER1");
//		header.setPASSWORD(soapPasswordService.encryptPassword(messageId));
//		header.setBRANCH("101");
//		header.setSERVICE("FCUBSAccService");
//		return header;
//	}
//	public  XMLGregorianCalendar timestampToXmlGregorianCalendar(java.util.Date cDate) throws DatatypeConfigurationException {
//		Calendar createDate = Calendar.getInstance();
//		cDate = createDate.getTime();
//		GregorianCalendar c = new GregorianCalendar();
//		c.setTime(cDate);
//		XMLGregorianCalendar date2 = DatatypeFactory.newInstance().newXMLGregorianCalendar(c);
//
//		return date2;
//	}
//
////AuthorizeAcClassTfrFS
//
//	public AUTHORIZECHECKBOOKFSFSREQ authorizeAcClassTfrFS(CashDepositWithdrawalModel cashDepositWithdrawal) {
//		AUTHORIZECHECKBOOKFSFSREQ req = new AUTHORIZECHECKBOOKFSFSREQ();
//		AUTHORIZECHECKBOOKFSFSREQ.FCUBSBODY reqbody = new AUTHORIZECHECKBOOKFSFSREQ.FCUBSBODY();
//		CheckBookFullType iotype = new CheckBookFullType();
//
//		// CashDepositWithdrawalModel cashDepositWithdrawal=(CashDepositWithdrawalModel)
//		// cashDepositService.fetchByTransId(transactionId).getBody();
//		iotype.setACCOUNT(cashDepositWithdrawal.getAccountNumber().toString());
//		iotype.setCHBKTYPE(cashDepositWithdrawal.getAccountType());
//		iotype.setAUTHSTAT(cashDepositWithdrawal.getAuthStatus());
//		iotype.setTXNSTAT("status");
//		/*
//		 * iotype.setCHECKERSTAMP(null); iotype.setCHECKER(null);
//		 * iotype.setAPPLYCHARGE(null); iotype.setChargeMain(null);
//		 * iotype.setCHECKLEAVES(null); iotype.setDELIVERYADD1(null);
//		 * iotype.setDELIVERYADD2(null); iotype.setDELIVERYADD3(null);
//		 * iotype.setDELIVERYADD4(null); iotype.setDELIVERYMODE(null);
//		 * iotype.setEventMaster(null); iotype.setISSUEDATE(null);
//		 * iotype.setLANGCODE(null); iotype.setMAKER(null); iotype.setMAKERSTAMP(null);
//		 * iotype.setMODNO(null); iotype.setORDERDATE(null);
//		 * iotype.setORDERDETAILS(null); iotype.setREQUESTMODE(null);
//		 * iotype.setREQUESTSTATUS(null); iotype.setINCLFORCHKBOOKPRINTING(null);
//		 */
//		reqbody.setChqBkDetailsFull(null);
//
//		req.setFCUBSHEADER(createHeaderAccService());
//		req.setFCUBSBODY(reqbody);
//
//		return req;
//	}
////AuthorizeCheckBookIO
//
//	public AUTHORIZECHECKBOOKIOPKREQ authorizeCheckBookIO(CashDepositWithdrawalModel cashDepositWithdrawal) {
//		AUTHORIZECHECKBOOKIOPKREQ req = new AUTHORIZECHECKBOOKIOPKREQ();
//		AUTHORIZECHECKBOOKIOPKREQ.FCUBSBODY reqbody = new AUTHORIZECHECKBOOKIOPKREQ.FCUBSBODY();
//		CheckBookAuthorizeIOType iotype = new CheckBookAuthorizeIOType();
//		// CashDepositWithdrawalModel cashDepositWithdrawal=(CashDepositWithdrawalModel)
//		// cashDepositService.fetchByTransId(transactionId).getBody();
//		iotype.setACCOUNT(cashDepositWithdrawal.getAccountNumber().toString());
////	iotype.setCHECKER(null);
////	iotype.setCHECKERSTAMP(null);
////	iotype.setMODNO(null);
//		reqbody.setChqBkDetailsIO(iotype);
//
//		req.setFCUBSHEADER(createHeaderAccService());
//		req.setFCUBSBODY(reqbody);
//
//		return req;
//	}
//
////CloseCheckBookFS
//
//	public CLOSECHECKBOOKFSFSREQ closeCheckBookFS(CashDepositWithdrawalModel cashDepositWithdrawal) {
//		CLOSECHECKBOOKFSFSREQ req = new CLOSECHECKBOOKFSFSREQ();
//		CLOSECHECKBOOKFSFSREQ.FCUBSBODY body = new CLOSECHECKBOOKFSFSREQ.FCUBSBODY();
//		CheckBookFullType iotype = new CheckBookFullType();
//		// CashDepositWithdrawalModel cashDepositWithdrawal=(CashDepositWithdrawalModel)
//		// cashDepositService.fetchByTransId(transactionId).getBody();
//		iotype.setACCOUNT(cashDepositWithdrawal.getAccountNumber().toString());
//		iotype.setAUTHSTAT(cashDepositWithdrawal.getAuthStatus());
//		iotype.setTXNSTAT("status");
//		/*
//		 * iotype.setChargeMain(null); iotype.setCHBKTYPE(null);
//		 * iotype.setCHECKER(null); iotype.setCHECKERSTAMP(null);
//		 * iotype.setCHECKLEAVES(null); iotype.setDELIVERYADD1(null);
//		 * iotype.setDELIVERYADD2(null); iotype.setDELIVERYADD3(null);
//		 * iotype.setDELIVERYADD4(null); iotype.setDELIVERYMODE(null);
//		 * iotype.setEventMaster(null); iotype.setINCLFORCHKBOOKPRINTING(null);
//		 * iotype.setISSUEDATE(null); iotype.setLANGCODE(null); iotype.setMAKER(null);
//		 * iotype.setMAKERSTAMP(null); iotype.setMODNO(null); iotype.setORDERDATE(null);
//		 * iotype.setORDERDETAILS(null); iotype.setREQUESTMODE(null);
//		 * iotype.setREQUESTSTATUS(null); iotype.setAPPLYCHARGE(null);
//		 */
//		;
//		body.setChqBkDetailsFull(iotype);
//
////	req.setFCUBSHEADER(createHeaderAccService());
////	req.setFCUBSBODY(body);
//
//		return req;
//	}
////CloseCheckBookIO
//
//	public CLOSECHECKBOOKIOPKREQ closeCheckBookIO(CashDepositWithdrawalModel cashDepositWithdrawal) {
//		CLOSECHECKBOOKIOPKREQ req = new CLOSECHECKBOOKIOPKREQ();
//		CLOSECHECKBOOKIOPKREQ.FCUBSBODY body = new CLOSECHECKBOOKIOPKREQ.FCUBSBODY();
//		CheckBookCloseIOType iotype = new CheckBookCloseIOType();
//		// CashDepositWithdrawalModel cashDepositWithdrawal=(CashDepositWithdrawalModel)
//		// cashDepositService.fetchByTransId(transactionId).getBody();
//		iotype.setACCOUNT(cashDepositWithdrawal.getAccountNumber().toString());
//		iotype.setMAKER(null);
//		iotype.setMAKERSTAMP(null);
//		iotype.setMODNO(null);
//
//		body.setChqBkDetailsIO(iotype);
//
//		req.setFCUBSHEADER(createHeaderAccService());
//		req.setFCUBSBODY(body);
//
//		return req;
//	}
////CloseCustAccFS
//
//	public CLOSECUSTACCFSFSREQ closeCustAccFS(CashDepositWithdrawalModel cashDepositWithdrawal,
//			IcCountryModel icCountryModel) {
//		CLOSECUSTACCFSFSREQ req = new CLOSECUSTACCFSFSREQ();
//		CLOSECUSTACCFSFSREQ.FCUBSBODY body = new CLOSECUSTACCFSFSREQ.FCUBSBODY();
//		CustAccFullType iotype = new CustAccFullType();
//		// CashDepositWithdrawalModel cashDepositWithdrawal=(CashDepositWithdrawalModel)
//		// cashDepositService.fetchByTransId(transactionId).getBody();
//		// IcCountryModel icCountryModel = new IcCountryModel();
//
//		iotype.setACCTYPE(cashDepositWithdrawal.getAccountType());
//		iotype.setAUTHSTAT(cashDepositWithdrawal.getAuthStatus());
//		iotype.setBRN(cashDepositWithdrawal.getAccountBranch());
//		iotype.setCOUNTRYCODE(icCountryModel.getCountryCode());
//		/*
//		 * iotype.setACC(null); iotype.setAccclose(null);
//		 * iotype.setAcccrdrlmtsMain(null); iotype.setACCLS(null);
//		 * iotype.setAccmaintinstr(null); iotype.setACCOPENDT(null);
//		 * iotype.setACCOUNTAUTOCLOSED(null); iotype.setAccstatusMain(null);
//		 * iotype.setAccSvcacsig(null); iotype.setACSTMTCYCLE(null);
//		 * iotype.setACSTMTCYCLE2(null); iotype.setACSTMTCYCLE3(null);
//		 * iotype.setACSTMTCYCLE3(null); iotype.setACSTMTDAY(null);
//		 * iotype.setACSTMTDAY2(null); iotype.setACSTMTDAY3(null);
//		 * iotype.setACSTMTTYPE3(null); iotype.setACSTMTTYPEP(null);
//		 * iotype.setACSTMTTYPS(null); iotype.setADDR1(null); iotype.setADDR2(null);
//		 * iotype.setADDR3(null); iotype.setADESC(null); iotype.setALTACC(null);
//		 * iotype.setAmountDates(null); iotype.setAuthbicdetailsMain(null);
//		 * iotype.setAUTOCHEQUEBOOKREQ(null); iotype.setAUTODEBITCARDREQUEST(null);
//		 * iotype.setAUTODEPBAL(null); iotype.setCHECKER(null);
//		 * iotype.setCHECKERSTAMP(null); iotype.setCHQBOOK(null);
//		 * iotype.setCLRBNKCD(null); iotype.setCRLMREVDT(null);
//		 * iotype.setCRLMSTDT(null); iotype.setCRSSTSTREQD(null);
//		 * iotype.setCRTXNLMT(null); iotype.setCustAcc(null);
//		 * iotype.setCustAccCard(null); iotype.setCustAccCheck(null);
//		 * iotype.setCustaccIcccspcn(null); iotype.setCustaccIcchspcn(null);
//		 * iotype.setCustaccIccinstr(null); iotype.setCustaccIccintpo(null);
//		 * iotype.setCustaccSicdiary(null); iotype.setCustaccStccusbl(null);
//		 * iotype.setCUSTNAME(null); iotype.setCUSTNO(null);
//		 * iotype.setCustomerAcc(null); iotype.setCustomerAcc1(null);
//		 * iotype.setDAYLIGHTLIMIT(null); iotype.setDFLTWAIVER(null);
//		 * iotype.setDoctypeRemarks(null); iotype.setESCROWACCOUNT(null);
//		 * iotype.setESCROWBRNCODE(null); iotype.setESCROWPERCENTAGE(null);
//		 * iotype.setESCROWTRN(null); iotype.setExtsysWsMaster(null);
//		 * iotype.setFLGEXCLRVRTRANS(null); iotype.setGENSTMTMV(null);
//		 * iotype.setGENSTMTMV2(null); iotype.setGENSTMTMV3(null);
//		 * iotype.setIBANACC(null); iotype.setIBANBNKCD(null);
//		 * iotype.setIntdetails(null); iotype.setInterimDetails(null);
//		 * iotype.setINTERMEDIARYREQUIRED(null); iotype.setJointholdersMain(null);
//		 * iotype.setLinkedentities(null); iotype.setLMTCCY(null); iotype.setLOC(null);
//		 * iotype.setMaster(null); iotype.setMAKER(null); iotype.setMAKERSTAMP(null);
//		 * iotype.setMASTERACC(null); iotype.setMEDIA(null); iotype.setMINREQBAL(null);
//		 * iotype.setMODNO(null); iotype.setMT110RECONREQD(null);
//		 * iotype.setNETREQ(null); iotype.setNOM1(null); iotype.setNOM2(null);
//		 * iotype.setNoticepref(null); iotype.setNSFBLKSTAT(null);
//		 * iotype.setOFFLINELIM(null); iotype.setOPMODE(null);
//		 * iotype.setPASSBOOKNUMBER(null); iotype.setPASSBOOKSTATUS(null);
//		 * iotype.setPAYINOPTION(null); iotype.setPRDLST(null); iotype.setPrdtxn(null);
//		 * iotype.setPREVSTMTBAL(null); iotype.setPREVSTMTBAL2(null);
//		 * iotype.setPREVSTMTBAL3(null); iotype.setPREVSTMTDT(null);
//		 * iotype.setPREVSTMTDT2(null); iotype.setPREVSTMTDT3(null);
//		 * iotype.setPREVSTMTNO(null); iotype.setPREVSTMTNO2(null);
//		 * iotype.setPREVSTMTNO3(null); iotype.setPRIVATECUSTOMER(null);
//		 * iotype.setPROJACC(null); iotype.setProvisionMain(null);
//		 * iotype.setREGCCAVL(null); iotype.setREGDAPP(null); iotype.setREGDENDT(null);
//		 * iotype.setREGDPER(null); iotype.setREGDSTDT(null);
//		 * iotype.setREPLCUSTSIG(null); iotype.setSDREFNO(null);
//		 * iotype.setSODNOTP(null); iotype.setSPCONDLST(null);
//		 * iotype.setSPCONDTXN(null); iotype.setStatement(null); iotype.setSTMTAC(null);
//		 * iotype.setSttmsCustAccount(null); iotype.setSttmsDebit(null);
//		 * iotype.setSUBLIMIT(null); iotype.setSWEEPIN(null); iotype.setSWEEPOUT(null);
//		 * iotype.setSWPTYPE(null); iotype.setCCY(null); iotype.setTddetails(null);
//		 * iotype.setTddetails(null); iotype.setATMCUSTACNO(null); iotype.setATM(null);
//		 * iotype.setATMBRN(null); iotype.setATMDCNTLIM(null); iotype.setATMDLIM(null);
//		 * iotype.setTODLIMENDT(null); iotype.setTODLIMIT(null);
//		 * iotype.setTODLIMSTDT(null); iotype.setTodRenew(null); iotype.setTRKREC(null);
//		 * iotype.setTXNLST(null); iotype.setTXNSTAT(null);
//		 * iotype.setUNCOLFUNDLIMIT(null);
//		 */
//
//		body.setCustAccountFull(iotype);
//
//		req.setFCUBSHEADER(createHeaderAccService());
//		req.setFCUBSBODY(body);
//
//		return req;
//	}
////CloseCustAccIO
//
//	public CLOSECUSTACCIOPKREQ closeCustAccIO(CashDepositWithdrawalModel cashDepositWithdrawal) {
//		CLOSECUSTACCIOPKREQ req = new CLOSECUSTACCIOPKREQ();
//		CLOSECUSTACCIOPKREQ.FCUBSBODY body = new CLOSECUSTACCIOPKREQ.FCUBSBODY();
//		CustAccCloseIOType iotype = new CustAccCloseIOType();
//		// CashDepositWithdrawalModel cashDepositWithdrawal=(CashDepositWithdrawalModel)
//		// cashDepositService.fetchByTransId(transactionId).getBody();
//		iotype.setACC(cashDepositWithdrawal.getAccountNumber().toString());
//		iotype.setBRN(cashDepositWithdrawal.getAccountBranch());
//		// iotype.setMAKER(null);
//		// iotype.setMAKERSTAMP(null);
//		// iotype.setMODNO(null);
//
//		body.setCustAccountIO(iotype);
//
//		req.setFCUBSHEADER(createHeaderAccService());
//		req.setFCUBSBODY(body);
//
//		return req;
//	}
////CloseStopPaymentsFS
//
//	public CLOSESTOPPAYMENTSFSFSREQ closeStopPaymentsFS(CashDepositWithdrawalModel cashDepositWithdrawal)
//			throws RecordNotFoundException {
//		CLOSESTOPPAYMENTSFSFSREQ req = new CLOSESTOPPAYMENTSFSFSREQ();
//		CLOSESTOPPAYMENTSFSFSREQ.FCUBSBODY body = new CLOSESTOPPAYMENTSFSFSREQ.FCUBSBODY();
//		StopPaymentsFullType iotype = new StopPaymentsFullType();
//		// CashDepositWithdrawalModel cashDepositWithdrawal=(CashDepositWithdrawalModel)
//		// cashDepositService.fetchByTransId(transactionId).getBody();
//
//		iotype.setAMOUNT(BigDecimal.valueOf((cashDepositWithdrawal.getAccountAmount())));
//		iotype.setAUTHSTAT(cashDepositWithdrawal.getAuthStatus());
//		/*
//		 * iotype.setSTARTCHECKNO(cashDepositWithdrawal.getChequeNumber());
//		 * iotype.setADVFTREQDFLG(null); iotype.setChargeMain(null);
//		 * iotype.setCHECKER(null); iotype.setCHECKERSTAMP(null);
//		 * iotype.setCONFIRMED(null); iotype.setEFFECTIVEDATE(null);
//		 * iotype.setENDCHECKNO(null); iotype.setEventMaster(null);
//		 * iotype.setEXPIRYDATE(null); iotype.setMAKER(null);
//		 * iotype.setMAKERSTAMP(null); iotype.setMODNO(null);
//		 * iotype.setRELETEDREFERENCE(null); iotype.setREMARKS(null);
//		 * iotype.setAPPLYCHARGE(null); iotype.setSTOPPAYMENTNO(null);
//		 * iotype.setSTOPPAYMENTTYPE(null); iotype.setTXNSTAT(null);
//		 */
//
//		body.setCatmsStopPaymentsFull(iotype);
//
//		req.setFCUBSHEADER(createHeaderAccService());
//		req.setFCUBSBODY(body);
//
//		return req;
//
//	}
////CloseStopPaymentsIO
//
//	public CLOSESTOPPAYMENTSIOPKREQ closeStopPaymentsIO(CashDepositWithdrawalModel cashDepositWithdrawal) {
//		CLOSESTOPPAYMENTSIOPKREQ req = new CLOSESTOPPAYMENTSIOPKREQ();
//		CLOSESTOPPAYMENTSIOPKREQ.FCUBSBODY body = new CLOSESTOPPAYMENTSIOPKREQ.FCUBSBODY();
//		StopPaymentsCloseIOType iotype = new StopPaymentsCloseIOType();
//		// CashDepositWithdrawalModel cashDepositWithdrawal=(CashDepositWithdrawalModel)
//		// cashDepositService.fetchByTransId(transactionId).getBody();
//		/*
//		 * iotype.setMODNO(BigDecimal.valueOf(accountInfoModel.getModificationNo()));
//		 * iotype.setMAKER(null); iotype.setMAKERSTAMP(null);
//		 * iotype.setSTOPPAYMENTNO(null);
//		 */
//
//		body.setCatmsStopPaymentsIO(null);
//
//		req.setFCUBSHEADER(createHeaderAccService());
//		req.setFCUBSBODY(body);
//
//		return req;
//	}
//
//
////CreateCheckBookFS	
//
//	public CREATECHECKBOOKFSFSREQ createCheckBookFS(CashDepositWithdrawalModel cashDepositWithdrawal) {
////	transactionId=12837l;,
//		CREATECHECKBOOKFSFSREQ req = new CREATECHECKBOOKFSFSREQ();
//		CREATECHECKBOOKFSFSREQ.FCUBSBODY reqbody = new CREATECHECKBOOKFSFSREQ.FCUBSBODY();
//		CheckBookFullType iotype = new CheckBookFullType();
//
//		// CashDepositWithdrawalModel cashDepositWithdrawal=(CashDepositWithdrawalModel)
//		// cashDepositService.fetchByTransId(transactionId).getBody();
//
//		//
//		iotype.setACCOUNT(cashDepositWithdrawal.getAccountNumber().toString());
//		iotype.setCHBKTYPE(cashDepositWithdrawal.getAccountType());
//		iotype.setAUTHSTAT(cashDepositWithdrawal.getAuthStatus());
//		iotype.setTXNSTAT("status");
//		/*
//		 * iotype.setCHECKERSTAMP(null); iotype.setCHECKER(null);
//		 * iotype.setAPPLYCHARGE(null); iotype.setChargeMain(null);
//		 * iotype.setCHECKLEAVES(null); iotype.setDELIVERYADD1(null);
//		 * iotype.setDELIVERYADD2(null); iotype.setDELIVERYADD3(null);
//		 * iotype.setDELIVERYADD4(null); iotype.setDELIVERYMODE(null);
//		 * iotype.setEventMaster(null); iotype.setISSUEDATE(null);
//		 * iotype.setLANGCODE(null); iotype.setMAKER(null); iotype.setMAKERSTAMP(null);
//		 * iotype.setMODNO(null); iotype.setORDERDATE(null);
//		 * iotype.setORDERDETAILS(null); iotype.setREQUESTMODE(null);
//		 * iotype.setREQUESTSTATUS(null); iotype.setINCLFORCHKBOOKPRINTING(null);
//		 */
//
//		reqbody.setChqBkDetailsFull(iotype);
//
//		req.setFCUBSHEADER(createHeaderAccService());
//		req.setFCUBSBODY(reqbody);
//
//		return req;
//
//	}
////CreateAcClassTfrFS
//
//	public CREATEACCLASSTFRFSFSREQ createAcClassTfrFS(CashDepositWithdrawalModel cashDepositWithdrawal,
//			AccountInfoModel accountInfoModel) throws RecordNotFoundException {
//		CREATEACCLASSTFRFSFSREQ req = new CREATEACCLASSTFRFSFSREQ();
//		CREATEACCLASSTFRFSFSREQ.FCUBSBODY body = new CREATEACCLASSTFRFSFSREQ.FCUBSBODY();
//		CustAccTfrFullType iotype = new CustAccTfrFullType();
//
//		// CashDepositWithdrawalModel cashDepositWithdrawal=(CashDepositWithdrawalModel)
//		// cashDepositService.fetchByTransId(transactionId).getBody();
//		// AccountInfoModel accountInfoModel = (AccountInfoModel)
//		// icustAccountServiceImpl.getAccountObj(accountId).getBody();
//
//		iotype.setACC(cashDepositWithdrawal.getAccountNumber().toString());
//		iotype.setACCLS(accountInfoModel.getLastTransactions().toString());
//		iotype.setACCSTAT(accountInfoModel.getStatus());
//		iotype.setTXNSTAT("status");
//		iotype.setAUTHSTAT(cashDepositWithdrawal.getAuthStatus());
//		iotype.setBRN(cashDepositWithdrawal.getAccountBranch());
//		/*
//		 * iotype.setACSTMTCYCLE(null); iotype.setACSTMTCYCLE2(null);
//		 * iotype.setACSTMTCYCLE3(null); iotype.setACSTMTCYCLE3(null);
//		 * iotype.setACSTMTDAY(null); iotype.setACSTMTDAY2(null);
//		 * iotype.setACSTMTDAY3(null); iotype.setACSTMTTYPE(null);
//		 * iotype.setACSTMTTYPE2(null); iotype.setACSTMTTYPE3(null);
//		 * iotype.setALLWBKPERENTRY(null); iotype.setATM(null);
//		 * iotype.setATMCUSTACNO(null); iotype.setATMDLYAMTLMT(null);
//		 * iotype.setATMDLYLMTCNT(null); iotype.setAUTOPROVREQD(null);
//		 * iotype.setAUTOREORDERCHKLVL(null); iotype.setAUTOREORDERCHKLVS(null);
//		 * iotype.setAUTOREORDERCHKR(null); iotype.setAUTOSTATCHANGE(null);
//		 * iotype.setCCY(null); iotype.setCHECKER(null); iotype.setCHECKERSTAMP(null);
//		 * iotype.setCHECKNAME1(null); iotype.setCHECKNAME2(null);
//		 * iotype.setCHQBOOK(null); iotype.setCONSREQD(null); iotype.setCRCBLINE(null);
//		 * iotype.setCRGL(null); iotype.setCRHOLINE(null); iotype.setDORMPRM(null);
//		 * iotype.setDRCBLINE(null); iotype.setDRGL(null); iotype.setDRHOLINE(null);
//		 * iotype.setEFFECTIVEDATE(null); iotype.setEXCLSAMEDAYRVRTRNSFMSTMT(null);
//		 * iotype.setEXPCATEG(null); iotype.setIctmAcc(null);
//		 * iotype.setLODGEBKFAC(null); iotype.setMAKER(null);
//		 * iotype.setMAKERSTAMP(null); iotype.setMINREQBAL(null); iotype.setMis(null);
//		 * iotype.setMODNO(null); iotype.setNEXTLIQDCYCLE(null);
//		 * iotype.setOFFLINELIMIT(null); iotype.setOLDACCLASS(null);
//		 * iotype.setPASSBOOK(null); iotype.setPROCESSEDSTAT(null);
//		 * iotype.setPROVCCYTYPE(null); iotype.setREFREQ(null); iotype.setREGDAPP(null);
//		 * iotype.setREGDPER(null); iotype.setREMARKS(null); iotype.setSWEEPMODE(null);
//		 * iotype.setTempCharge(null); iotype.setTempConsol(null);
//		 * iotype.setTempStatus(null); iotype.setTRACKRECEIVABLE(null);
//		 */
//
//		body.setMainFull(iotype);
//
//		req.setFCUBSHEADER(createHeaderAccService());
//		req.setFCUBSBODY(body);
//
//		return req;
//	}
//
////CreateAcClassTfrIO
//
//	public CREATEACCLASSTFRIOPKREQ createAcClassTfrIO(CashDepositWithdrawalModel cashDepositWithdrawal,
//			AccountInfoModel accountInfoModel) throws RecordNotFoundException {
//		CREATEACCLASSTFRIOPKREQ req = new CREATEACCLASSTFRIOPKREQ();
//		CREATEACCLASSTFRIOPKREQ.FCUBSBODY body = new CREATEACCLASSTFRIOPKREQ.FCUBSBODY();
//		CustAccTfrCreateIOType iotype = new CustAccTfrCreateIOType();
//
//		// CashDepositWithdrawalModel cashDepositWithdrawal=(CashDepositWithdrawalModel)
//		// cashDepositService.fetchByTransId(transactionId).getBody();
//		// AccountInfoModel accountInfoModel = (AccountInfoModel)
//		// icustAccountServiceImpl.getAccountObj(accountId).getBody();
//
//		iotype.setACC(cashDepositWithdrawal.getAccountNumber().toString());
//		iotype.setACCLS(accountInfoModel.getLastTransactions().toString());
//		iotype.setBRN(cashDepositWithdrawal.getAccountBranch());
//		/*
//		 * iotype.setACSTMTCYCLE(null); iotype.setACSTMTCYCLE2(null);
//		 * iotype.setACSTMTCYCLE3(null); iotype.setACSTMTCYCLE3(null);
//		 * iotype.setACSTMTDAY(null); iotype.setACSTMTDAY2(null);
//		 * iotype.setACSTMTDAY3(null); iotype.setACSTMTTYPE(null);
//		 * iotype.setACSTMTTYPE2(null); iotype.setACSTMTTYPE3(null);
//		 * iotype.setALLWBKPERENTRY(null); iotype.setATM(null);
//		 * iotype.setATMCUSTACNO(null); iotype.setATMDLYAMTLMT(null);
//		 * iotype.setATMDLYLMTCNT(null); iotype.setAUTOPROVREQD(null);
//		 * iotype.setAUTOREORDERCHKLVL(null); iotype.setAUTOREORDERCHKLVS(null);
//		 * iotype.setAUTOREORDERCHKR(null); iotype.setAUTOSTATCHANGE(null);
//		 * iotype.setCHECKNAME1(null); iotype.setCHECKNAME2(null);
//		 * iotype.setCHQBOOK(null); iotype.setCONSREQD(null); iotype.setCRCBLINE(null);
//		 * iotype.setCRHOLINE(null); iotype.setDORMPRM(null); iotype.setDRCBLINE(null);
//		 * iotype.setDRHOLINE(null); iotype.setEFFECTIVEDATE(null);
//		 * iotype.setEXCLSAMEDAYRVRTRNSFMSTMT(null); iotype.setEXPCATEG(null);
//		 * iotype.setIctmAcc(null); iotype.setLODGEBKFAC(null);
//		 * iotype.setMINREQBAL(null); iotype.setMis(null);
//		 * iotype.setNEXTLIQDCYCLE(null); iotype.setOFFLINELIMIT(null);
//		 * iotype.setPASSBOOK(null); iotype.setPROVCCYTYPE(null);
//		 * iotype.setREFREQ(null); iotype.setREGDAPP(null); iotype.setREGDPER(null);
//		 * iotype.setREMARKS(null); iotype.setSWEEPMODE(null);
//		 * iotype.setTRACKRECEIVABLE(null);
//		 */
//
//		body.setMainIO(iotype);
//
//		req.setFCUBSHEADER(createHeaderAccService());
//		req.setFCUBSBODY(body);
//
//		return req;
//	}
////CreateCheckBookIO
//
//	public CREATECHECKBOOKIOPKREQ createCheckBookIO(CashDepositWithdrawalModel cashDepositWithdrawal) {
//		CREATECHECKBOOKIOPKREQ req = new CREATECHECKBOOKIOPKREQ();
//
//		CREATECHECKBOOKIOPKREQ.FCUBSBODY body = new CREATECHECKBOOKIOPKREQ.FCUBSBODY();
//		CheckBookCreateIOType iotype = new CheckBookCreateIOType();
//
//		// CashDepositWithdrawalModel cashDepositWithdrawal=(CashDepositWithdrawalModel)
//		// cashDepositService.fetchByTransId(transactionId).getBody();
//
//		iotype.setACCOUNT(cashDepositWithdrawal.getAccountNumber().toString());
//		/*
//		 * iotype.setAPPLYCHARGE(null); iotype.setCHECKLEAVES(null);
//		 * iotype.setDELIVERYADD1(null); iotype.setDELIVERYADD2(null);
//		 * iotype.setDELIVERYADD3(null); iotype.setDELIVERYADD4(null);
//		 * iotype.setDELIVERYMODE(null); iotype.setINCLFORCHKBOOKPRINTING(null);
//		 * iotype.setLANGCODE(null); iotype.setORDERDATE(null);
//		 * iotype.setORDERDETAILS(null); iotype.setREQUESTSTATUS(null);
//		 * iotype.setCHBKTYPE(null); iotype.setChargeMain(null);
//		 * iotype.setISSUEDATE(null); iotype.setEventMaster(null);
//		 * iotype.setAPPLYCHARGE(null);
//		 */
//
//		body.setChqBkDetailsIO(iotype);
//
//		req.setFCUBSHEADER(createHeaderAccService());
//		req.setFCUBSBODY(body);
//
//		return req;
//
//	}
//
////CreateCustAccFS
//
//public ResponseEntity<?> createCustAccFSTest(IcustAccount req) {
//
//	  HttpHeaders headers = new HttpHeaders();
//	    Map<String, String> headerMap = new HashMap<>();
//		headerMap.put("Content-Type", "application/json");
//
//    headers.setContentType(MediaType.APPLICATION_JSON);
//
//	ResponseEntity<?> response = (ResponseEntity<?>) flexCubeCient.call(propertyConfiguration.getWsUrl()+"/createCustAccFS",
//			headerMap, req, HttpMethod.POST);
//
//    
//    return response;
//
//}
//
//public ResponseEntity<?> createCustAccFS(IcustAccount data) {
//	FCUBSHEADERType header=createHeaderAccService();
//	header.setMODULEID("ST");
//	header.setOPERATION("CreateCustAcc");
//	header.setSOURCEOPERATION("CreateCustAcc");
//	header.setFUNCTIONID("STDCUSAC");
//	header.setACTION("NEW");
//
//	CREATECUSTACCFSFSREQ req = new CREATECUSTACCFSFSREQ();
//
//	CREATECUSTACCFSFSREQ.FCUBSBODY body = new CREATECUSTACCFSFSREQ.FCUBSBODY();
//
//	CustAccFullType iotype = new CustAccFullType();
//	iotype.setACC(data.getAmount().toString());
//	iotype.setAccclose(null);
//	iotype.setAcccrdrlmtsMain(null);
//	iotype.setACCLS("SAVIN");
////iotype.setAccmaintinstr(null);
//	try {
//		java.util.Date date;
//		// date=new Date(data.getCreatedTime());
//		date = new java.util.Date();
//		iotype.setACCOPENDT(timestampToXmlGregorianCalendar(date));
//		iotype.setSTATSINCE(timestampToXmlGregorianCalendar(date));
//	} catch (Exception e) {
//		e.printStackTrace();
//	}
//	iotype.setACCOUNTAUTOCLOSED("N");
//	iotype.setAccstatusMain(null);
//	iotype.setAccSvcacsig(null);
//	iotype.setACCTYPE(data.getAccountType());
//	iotype.setACSTMTCYCLE("A");
//	iotype.setACSTMTCYCLE2(null);
//	iotype.setACSTMTCYCLE3(null);
//	iotype.setACSTMTCYCLE3(null);
//	iotype.setACSTMTDAY(new BigDecimal(12));
//	iotype.setACSTMTDAY2(null);
//	iotype.setACSTMTDAY3(null);
//	iotype.setACSTMTTYPE3("N");
//	iotype.setACSTMTTYPEP("D");
//	iotype.setACSTMTTYPS("N");
//
//	iotype.setADESC(null);
//	iotype.setALTACC("000000240285");
//	iotype.setAmountDates(null);
//	iotype.setAuthbicdetailsMain(null);
//
//	iotype.setProvisionMain(null);
//	CustAccountMISFullType camt = new CustAccountMISFullType();
////	MISDETAILSREQType value = new MISDETAILSREQType();
////	value.setPOOLCD("POOL1");
////	camt.setMisdetails(value);
//	AccmaintinstrType mstr = new AccmaintinstrType();
//
//	iotype.setCustAcc(null);
//	iotype.setAUTHSTAT(null);
//	iotype.setAUTOCHEQUEBOOKREQ("N");
//	iotype.setAUTODEBITCARDREQUEST("N");
//	iotype.setAUTODEPBAL(null);
//	iotype.setBRN(data.getAccountBranch());
//	iotype.setCHECKER(null);
//	iotype.setCCY(data.getAccountCurrency());
//	iotype.setLOC("IN");
//	iotype.setCHECKERSTAMP(null);
//	iotype.setCHQBOOK("N");
//	iotype.setCLRBNKCD(null);
//	
//	iotype.setCOUNTRYCODE("IN");
//	iotype.setCRLMREVDT(null);
//	iotype.setCRLMSTDT(null);
//	iotype.setCRSSTSTREQD("N");
//	iotype.setCRTXNLMT(null);
//	iotype.setCustAcc(null);
//	iotype.setCustAccCard(null);
//	iotype.setCustAccCheck(null);
//	iotype.setCustaccIcccspcn(null);
//	iotype.setCustaccIcchspcn(null);
//	iotype.setCustaccIccinstr(null);
//	iotype.setCustaccIccintpo(null);
//	iotype.setCustaccSicdiary(null);
//	iotype.setCustaccStccusbl(null);
//	iotype.setCUSTNAME("Reliance Mart");
//	iotype.setCUSTNO(data.getCustomerId());
//	iotype.setCustomerAcc(null);
//
//	iotype.setDAYLIGHTLIMIT(new BigDecimal(0));
//	iotype.setDFLTWAIVER("N");
//	iotype.setDoctypeRemarks(null);
//	iotype.setESCROWACCOUNT(null);
//	iotype.setESCROWBRNCODE(null);
//	iotype.setESCROWPERCENTAGE(null);
//	iotype.setESCROWTRN("N");
//	iotype.setExtsysWsMaster(null);
//	iotype.setFLGEXCLRVRTRANS("Y");
//	iotype.setGENSTMTMV(null);
//	iotype.setGENSTMTMV2(null);
//	iotype.setGENSTMTMV3(null);
//	
//	iotype.setIntdetails(null);
//	iotype.setInterimDetails(null);
//	iotype.setINTERMEDIARYREQUIRED("N");
//	iotype.setJointholdersMain(null);
//
//	iotype.setLOC("IN");
//	iotype.setMaster(null);
//	iotype.setMAKER(null);
//	iotype.setMAKERSTAMP(null);
//	iotype.setMASTERACC(null);
//	iotype.setMEDIA("MAIL");
//	iotype.setMINREQBAL(null);
//	iotype.setMODNO(null);
//	iotype.setMT110RECONREQD(null);
//	iotype.setNETREQ(null);
//	iotype.setNOM1(null);
//	iotype.setNOM2(null);
//	iotype.setNoticepref(null);
//	iotype.setNSFBLKSTAT(null);
//	iotype.setOFFLINELIM(null);
//	iotype.setOPMODE(null);
//	iotype.setPASSBOOKNUMBER(null);
//	iotype.setPASSBOOKSTATUS(null);
//	iotype.setPAYINOPTION(null);
//	iotype.setPRDLST("D");
//	iotype.setPrdtxn(null);
//	iotype.setPREVSTMTBAL(null);
//	iotype.setPREVSTMTBAL2(null);
//	iotype.setPREVSTMTBAL3(null);
//	iotype.setPREVSTMTDT(null);
//	iotype.setPREVSTMTDT2(null);
//	iotype.setPREVSTMTDT3(null);
//	iotype.setPREVSTMTNO(null);
//	iotype.setPREVSTMTNO2(null);
//	iotype.setPREVSTMTNO3(null);
//	iotype.setPRIVATECUSTOMER("N");
//	iotype.setPROJACC("N");
//	iotype.setProvisionMain(null);
//	iotype.setREGCCAVL(null);
//	iotype.setREGDAPP("N");
//	iotype.setREGDENDT(null);
//	iotype.setREGDPER("N");
//	iotype.setREGDSTDT(null);
//	iotype.setREPLCUSTSIG("Y");
//	iotype.setSDREFNO(null);
//	
//	iotype.setSPCONDLST("N");
//	iotype.setSPCONDTXN("N");
//	iotype.setStatement(null);
//	iotype.setSTMTAC(null);
//
//	iotype.setSWPTYPE(new BigDecimal(1));
//	iotype.setCCY(data.getAccountCurrency());
//	iotype.setTddetails(null);
//	iotype.setTddetails(null);
//	iotype.setATMCUSTACNO(null);
//	iotype.setATM(null);
//	iotype.setATMBRN(null);
//	iotype.setATMDCNTLIM(null);
//	iotype.setATMDLIM(null);
//
//	iotype.setTodRenew(null);
//	iotype.setTRKREC("Y");
//	iotype.setTXNLST("D");
//	iotype.setTXNSTAT(null);
//	
//	iotype.setAcccrdrlmtsMain(null);
//	body.setCustAccountFull(iotype);
//
//	req.setFCUBSBODY(body);
//	req.setFCUBSHEADER(header);
//	
//	  ResponseEntity<?> res=  accServiceImpl.createCustAccFS(req);
//	  FCUBSBODY res1=(CREATECUSTACCFSFSRES.FCUBSBODY) res.getBody();
//
//	    System.out.println("new resp"+res1.getCustAccountFull().getACC());
//	    
//	return null;
//}
//
//
////CreateCustAccIO
//
//	public CREATECUSTACCIOPKREQ createCustAccIO(CashDepositWithdrawalModel cashDepositWithdrawal) {
//		
//		FCUBSHEADERType header=createHeaderAccService();
//		header.setMODULEID("ST");
//		header.setOPERATION("CreateCustAcc");
//		header.setSOURCEOPERATION("CreateCustAcc");
//		header.setFUNCTIONID("STDCUSAC");
//		header.setACTION("NEW");
//		CREATECUSTACCIOPKREQ req = new CREATECUSTACCIOPKREQ();
//		CREATECUSTACCIOPKREQ.FCUBSBODY body = new CREATECUSTACCIOPKREQ.FCUBSBODY();
//		CustAccCreateIOType iotype = new CustAccCreateIOType();
//
//		// CashDepositWithdrawalModel cashDepositWithdrawal=(CashDepositWithdrawalModel)
//		// cashDepositService.fetchByTransId(transactionId).getBody();
//
//		AccountInfoModel accountInfoModel = new AccountInfoModel();
//		IcCountryModel icCountryModel = new IcCountryModel();
//		CustomerInfoModel customerInfoModel = new CustomerInfoModel();
//		iotype.setACCTYPE(cashDepositWithdrawal.getAccountType());
//		iotype.setBRN(cashDepositWithdrawal.getAccountBranch());
//		/*
//		 * iotype.setCOUNTRYCODE(icCountryModel.getCountryCode()); iotype.setACC(null);
//		 * iotype.setAccclose(null); iotype.setACCLS(null);
//		 * iotype.setAccmaintinstr(null); iotype.setACCOPENDT(null);
//		 * iotype.setAccSvcacsig(null); iotype.setACSTMTCYCLE(null);
//		 * iotype.setACSTMTCYCLE2(null); iotype.setACSTMTCYCLE3(null);
//		 * iotype.setACSTMTCYCLE3(null); iotype.setACSTMTDAY(null);
//		 * iotype.setACSTMTDAY2(null); iotype.setACSTMTDAY3(null);
//		 * iotype.setACSTMTTYPE3(null); iotype.setACSTMTTYPEP(null);
//		 * iotype.setACSTMTTYPS(null); iotype.setADDR1(null); iotype.setADDR2(null);
//		 * iotype.setADDR3(null); iotype.setADESC(null); iotype.setALTACC(null);
//		 * iotype.setAmountDates(null); iotype.setAUTOCHEQUEBOOKREQ(null);
//		 * iotype.setAUTODEBITCARDREQUEST(null); iotype.setAUTODEPBAL(null);
//		 * iotype.setCHQBOOK(null); iotype.setCLRBNKCD(null); iotype.setCRLMREVDT(null);
//		 * iotype.setCRLMSTDT(null); iotype.setCRSSTSTREQD(null);
//		 * iotype.setCRTXNLMT(null); iotype.setCustAcc(null);
//		 * iotype.setCustAccCard(null); iotype.setCustAccCheck(null);
//		 * iotype.setCustaccIcccspcn(null); iotype.setCustaccIcchspcn(null);
//		 * iotype.setCustaccIccinstr(null); iotype.setCustaccIccintpo(null);
//		 * iotype.setCustaccSicdiary(null); iotype.setCustaccStccusbl(null);
//		 * iotype.setCUSTNO(null); iotype.setCustomerAcc(null);
//		 * iotype.setCustomerAcc1(null); iotype.setDAYLIGHTLIMIT(null);
//		 * iotype.setDFLTWAIVER(null); iotype.setDoctypeRemarks(null);
//		 * iotype.setESCROWACCOUNT(null); iotype.setESCROWBRNCODE(null);
//		 * iotype.setESCROWPERCENTAGE(null); iotype.setESCROWTRN(null);
//		 * iotype.setExtsysWsMaster(null); iotype.setFLGEXCLRVRTRANS(null);
//		 * iotype.setGENSTMTMV(null); iotype.setGENSTMTMV2(null);
//		 * iotype.setGENSTMTMV3(null); iotype.setIBANACC(null);
//		 * iotype.setIBANBNKCD(null); iotype.setIntdetails(null);
//		 * iotype.setInterimDetails(null); iotype.setINTERMEDIARYREQUIRED(null);
//		 * iotype.setLinkedentities(null); iotype.setLMTCCY(null); iotype.setLOC(null);
//		 * iotype.setMaster(null); iotype.setMASTERACC(null); iotype.setMEDIA(null);
//		 * iotype.setMINREQBAL(null); iotype.setMT110RECONREQD(null);
//		 * iotype.setNETREQ(null); iotype.setNOM1(null); iotype.setNOM2(null);
//		 * iotype.setNoticepref(null); iotype.setOFFLINELIM(null);
//		 * iotype.setOPMODE(null); iotype.setPAYINOPTION(null); iotype.setPRDLST(null);
//		 * iotype.setPROJACC(null); iotype.setREGCCAVL(null); iotype.setREGDAPP(null);
//		 * iotype.setREGDPER(null); iotype.setREPLCUSTSIG(null);
//		 * iotype.setSODNOTP(null); iotype.setSPCONDLST(null);
//		 * iotype.setSPCONDTXN(null); iotype.setSTMTAC(null);
//		 * iotype.setSttmsCustAccount(null); iotype.setSttmsDebit(null);
//		 * iotype.setSUBLIMIT(null); iotype.setSWEEPIN(null); iotype.setSWEEPOUT(null);
//		 * iotype.setSWPTYPE(null); iotype.setCCY(null); iotype.setTddetails(null);
//		 * iotype.setTddetails(null); iotype.setATMCUSTACNO(null); iotype.setATM(null);
//		 * iotype.setATMDCNTLIM(null); iotype.setATMDLIM(null);
//		 * iotype.setTODLIMENDT(null); iotype.setTODLIMIT(null);
//		 * iotype.setTODLIMSTDT(null); iotype.setTodRenew(null); iotype.setTRKREC(null);
//		 * iotype.setTXNLST(null); iotype.setUNCOLFUNDLIMIT(null);
//		 */
//
//		body.setCustAccountIO(iotype);
//
//		req.setFCUBSHEADER(header);
//		req.setFCUBSBODY(body);
//		 ResponseEntity<?> res=  accServiceImpl.createCustAccIO(req);
//		  com.ws.api.accservice.CREATECUSTACCIOPKRES.FCUBSBODY res1=(CREATECUSTACCIOPKRES.FCUBSBODY) res.getBody();
//
//		    System.out.println("new resp"+res1.getCustAccountIO().getACC());
//		return req;
//	}
////CreateStopPaymentsFS
//
//	public CREATESTOPPAYMENTSFSFSREQ createStopPaymentsFS(CashDepositWithdrawalModel cashDepositWithdrawal) {
//		CREATESTOPPAYMENTSFSFSREQ req = new CREATESTOPPAYMENTSFSFSREQ();
//		CREATESTOPPAYMENTSFSFSREQ.FCUBSBODY body = new CREATESTOPPAYMENTSFSFSREQ.FCUBSBODY();
//		StopPaymentsFullType iotype = new StopPaymentsFullType();
//		// CashDepositWithdrawalModel cashDepositWithdrawal=(CashDepositWithdrawalModel)
//		// cashDepositService.fetchByTransId(transactionId).getBody();
//		iotype.setSTARTCHECKNO(cashDepositWithdrawal.getChequeNumber());
//		/*
//		 * iotype.setAPPLYCHARGE(null); iotype.setCHECKER(null);
//		 * iotype.setChargeMain(null); iotype.setEFFECTIVEDATE(null);
//		 * iotype.setEventMaster(null); iotype.setAPPLYCHARGE(null);
//		 * iotype.setAMOUNT(null); iotype.setAUTHSTAT(null);
//		 * iotype.setCHECKERSTAMP(null); iotype.setCONFIRMED(null);
//		 * iotype.setENDCHECKNO(null); iotype.setEXPIRYDATE(null);
//		 * iotype.setMAKER(null); iotype.setMAKERSTAMP(null); iotype.setMODNO(null);
//		 * iotype.setRELETEDREFERENCE(null); iotype.setREMARKS(null);
//		 * iotype.setSTOPPAYMENTNO(null); iotype.setSTOPPAYMENTTYPE(null);
//		 * iotype.setTXNSTAT(null);
//		 */
//
//		body.setCatmsStopPaymentsFull(iotype);
//		req.setFCUBSHEADER(createHeaderAccService());
//		req.setFCUBSBODY(body);
//
//		return req;
//	}
////CreateStopPaymentsIO
//
//	public CREATESTOPPAYMENTSIOPKREQ createStopPaymentsIO(CashDepositWithdrawalModel cashDepositWithdrawal) {
//		CREATESTOPPAYMENTSIOPKREQ req = new CREATESTOPPAYMENTSIOPKREQ();
//		CREATESTOPPAYMENTSIOPKREQ.FCUBSBODY body = new CREATESTOPPAYMENTSIOPKREQ.FCUBSBODY();
//		StopPaymentsCreateIOType iotype = new StopPaymentsCreateIOType();
//		// CashDepositWithdrawalModel cashDepositWithdrawal=(CashDepositWithdrawalModel)
//		// cashDepositService.fetchByTransId(transactionId).getBody();
//		iotype.setACCNUMBER(cashDepositWithdrawal.getAccountNumber().toString());
//		iotype.setSTARTCHECKNO(cashDepositWithdrawal.getChequeNumber());
//		/*
//		 * iotype.setAPPLYCHARGE(null); iotype.setChargeMain(null);
//		 * iotype.setEFFECTIVEDATE(null); iotype.setEventMaster(null);
//		 * iotype.setAPPLYCHARGE(null); iotype.setAMOUNT(null);
//		 * iotype.setCONFIRMED(null); iotype.setENDCHECKNO(null);
//		 * iotype.setEXPIRYDATE(null); iotype.setRELETEDREFERENCE(null);
//		 * iotype.setREMARKS(null); iotype.setSTOPPAYMENTNO(null);
//		 * iotype.setSTOPPAYMENTTYPE(null);
//		 */
//
//		body.setCatmsStopPaymentsIO(iotype);
//		req.setFCUBSHEADER(createHeaderAccService());
//		req.setFCUBSBODY(body);
//		return req;
//	}
////CreateTDCustAccFS
//
//	public CREATETDCUSTACCFSFSREQ createTDCustAccFS(CashDepositWithdrawalModel cashDepositWithdrawal,
//			AccountInfoModel accountInfoModel) {
//		CREATETDCUSTACCFSFSREQ req = new CREATETDCUSTACCFSFSREQ();
//		CREATETDCUSTACCFSFSREQ.FCUBSBODY body = new CREATETDCUSTACCFSFSREQ.FCUBSBODY();
//		TDCustAccFullType iotype = new TDCustAccFullType();
//		// CashDepositWithdrawalModel cashDepositWithdrawal=(CashDepositWithdrawalModel)
//		// cashDepositService.fetchByTransId(transactionId).getBody();
//		// AccountInfoModel accountInfoModel = new AccountInfoModel();
//		IcCountryModel icCountryModel = new IcCountryModel();
//		CustomerInfoModel customerInfoModel = new CustomerInfoModel();
//		iotype.setACCTYPE(cashDepositWithdrawal.getAccountType());
//		iotype.setCOUNTRY(icCountryModel.getCountryName());
//		iotype.setCOUNTRYCODE(icCountryModel.getCountryCode());
//		iotype.setBRN(cashDepositWithdrawal.getAccountBranch());
//		iotype.setAUTHSTAT(cashDepositWithdrawal.getAuthStatus());
//		/*
//		 * iotype.setAccclose(null); iotype.setAcccrdrlmtsMain(null);
//		 * iotype.setACCLS(null); iotype.setAccmaintinstr(null);
//		 * iotype.setACCOPENDT(null); iotype.setACCOUNTAUTOCLOSED(null);
//		 * iotype.setAccstatusMain(null); iotype.setAccSvcacsig(null);
//		 * iotype.setACSTMTCYCLE(null); iotype.setACSTMTCYCLE2(null);
//		 * iotype.setACSTMTCYCLE3(null); iotype.setACSTMTCYCLE3(null);
//		 * iotype.setACSTMTDAY(null); iotype.setACSTMTDAY2(null);
//		 * iotype.setACSTMTDAY3(null); iotype.setACSTMTTYPE3(null);
//		 * iotype.setACSTMTTYPEP(null); iotype.setACSTMTTYPS(null);
//		 * iotype.setADDR1(null); iotype.setADDR2(null); iotype.setADDR3(null);
//		 * iotype.setADESC(null); iotype.setALTACC(null); iotype.setAmountDates(null);
//		 * iotype.setAuthbicdetailsMain(null); iotype.setAUTOCHEQUEBOOKREQ(null);
//		 * iotype.setAUTODEBITCARDREQUEST(null); iotype.setAUTODEPBAL(null);
//		 * 
//		 * iotype.setCHECKER(null); iotype.setCHECKERSTAMP(null);
//		 * iotype.setCHQADTE(null); iotype.setCHQINSTNO(null);
//		 * iotype.setCLEARINGTYPE(null); iotype.setCLRBNKCD(null);
//		 * 
//		 * iotype.setCRLMREVDT(null); iotype.setCRLMSTDT(null);
//		 * iotype.setCRSSTSTREQD(null); iotype.setCRTXNLMT(null);
//		 * iotype.setCustAcc(null); iotype.setCustAccCard(null);
//		 * iotype.setCustAccCheck(null); iotype.setCustaccIcccspcn(null);
//		 * iotype.setCustaccIcchspcn(null); iotype.setCustaccIccinstr(null);
//		 * iotype.setCustaccIccintpo(null); iotype.setCustaccSicdiary(null);
//		 * iotype.setCustaccStccusbl(null); iotype.setCUSTNAME(null);
//		 * iotype.setCUSTNO(null); iotype.setCustomerAcc(null);
//		 * iotype.setCustomerAcc1(null); iotype.setDAYLIGHTLIMIT(null);
//		 * iotype.setDFLTWAIVER(null); iotype.setDoctypeRemarks(null);
//		 * iotype.setDRAWEEACCOUNT(null); iotype.setESCROWACCOUNT(null);
//		 * iotype.setESCROWBRNCODE(null); iotype.setESCROWPERCENTAGE(null);
//		 * iotype.setESCROWTRN(null); iotype.setExtsysWsMaster(null);
//		 * iotype.setFLGEXCLRVRTRANS(null); iotype.setGENSTMTMV(null);
//		 * iotype.setGENSTMTMV2(null); iotype.setGENSTMTMV3(null);
//		 * iotype.setIBANACC(null); iotype.setIBANBNKCD(null);
//		 * iotype.setIntdetails(null); iotype.setInterimDetails(null);
//		 * iotype.setINTERMEDIARYREQUIRED(null); iotype.setJointholdersMain(null);
//		 * iotype.setLinkedentities(null); iotype.setLMTCCY(null); iotype.setLOC(null);
//		 * iotype.setMaster(null); iotype.setMAKER(null); iotype.setMAKERSTAMP(null);
//		 * iotype.setMASTERACC(null); iotype.setMEDIA(null); iotype.setMINREQBL(null);
//		 * iotype.setMODNO(null); iotype.setMT110RECONREQD(null);
//		 * iotype.setNETREQ(null); iotype.setNOM1(null); iotype.setNOM2(null);
//		 * iotype.setNoticepref(null); iotype.setNSFBLKSTAT(null);
//		 * iotype.setOFFLINELIM(null); iotype.setOPMODE(null);
//		 * iotype.setPASSBOOKNUMBER(null); iotype.setPASSBOOKSTATUS(null);
//		 * iotype.setPAYINBY(null); iotype.setPRDLST(null); iotype.setPrdtxn(null);
//		 * iotype.setPREVSTMTBAL(null); iotype.setPREVSTMTBAL2(null);
//		 * iotype.setPREVSTMTBAL3(null); iotype.setPREVSTMTDT(null);
//		 * iotype.setPREVSTMTDT2(null); iotype.setPREVSTMTDT3(null);
//		 * iotype.setPREVSTMTNO(null); iotype.setPREVSTMTNO2(null);
//		 * iotype.setPREVSTMTNO3(null); iotype.setPRIVATECUSTOMER(null);
//		 * iotype.setPROJACC(null); iotype.setProvisionMain(null);
//		 * iotype.setREGCCAVL(null); iotype.setREGDAPP(null); iotype.setREGDENDT(null);
//		 * iotype.setREGDPER(null); iotype.setREGDSTDT(null);
//		 * iotype.setREPLCUSTSIG(null); iotype.setROUTINGNO(null);
//		 * iotype.setSDREFNO(null); iotype.setSODNOTP(null); iotype.setSPCONDLST(null);
//		 * iotype.setSPCONDTXN(null); iotype.setStatement(null); iotype.setSTMTAC(null);
//		 * iotype.setSttmsCustAccount(null); iotype.setSttmsDebit(null);
//		 * iotype.setSUBLIMIT(null); iotype.setSWEEPIN(null); iotype.setSWEEPOUT(null);
//		 * iotype.setSWPTYPE(null); iotype.setTDCCY(null); iotype.setTddetails(null);
//		 * iotype.setTddetailsprn(null); iotype.setTERMACNO(null);
//		 * iotype.setTODLIMENDT(null); iotype.setTODLIMIT(null);
//		 * iotype.setTODLIMSTDT(null); iotype.setTodRenew(null); iotype.setTRKREC(null);
//		 * iotype.setTXNLST(null); iotype.setTXNSTAT(null);
//		 * iotype.setUNCOLFUNDLIMIT(null);
//		 */
//
//		body.setCustAccountFull(iotype);
//
//		req.setFCUBSHEADER(createHeaderAccService());
//		req.setFCUBSBODY(body);
//
//		return req;
//	}
////CreateTDCustAccIO
//
//	public CREATETDCUSTACCIOPKREQ createTDCustAccIO(CashDepositWithdrawalModel cashDepositWithdrawal,
//			IcCountryModel icCountryModel) {
//		CREATETDCUSTACCIOPKREQ req = new CREATETDCUSTACCIOPKREQ();
//		CREATETDCUSTACCIOPKREQ.FCUBSBODY body = new CREATETDCUSTACCIOPKREQ.FCUBSBODY();
//		TDCustAccCreateIOType iotype = new TDCustAccCreateIOType();
//		// CashDepositWithdrawalModel cashDepositWithdrawal=(CashDepositWithdrawalModel)
//		// cashDepositService.fetchByTransId(transactionId).getBody();
//		// IcCountryModel icCountryModel = new IcCountryModel();
//		iotype.setACCTYPE(cashDepositWithdrawal.getAccountType());
//		iotype.setBRN(cashDepositWithdrawal.getAccountBranch());
//		iotype.setCOUNTRYCODE(icCountryModel.getCountryCode());
//		/*
//		 * iotype.setAccclose(null); iotype.setACCLS(null);
//		 * iotype.setAccmaintinstr(null); iotype.setACCOPENDT(null);
//		 * iotype.setAccSvcacsig(null);
//		 * 
//		 * iotype.setACSTMTCYCLE(null); iotype.setACSTMTCYCLE2(null);
//		 * iotype.setACSTMTCYCLE3(null); iotype.setACSTMTCYCLE3(null);
//		 * iotype.setACSTMTDAY(null); iotype.setACSTMTDAY2(null);
//		 * iotype.setACSTMTDAY3(null); iotype.setACSTMTTYPE3(null);
//		 * iotype.setACSTMTTYPEP(null); iotype.setACSTMTTYPS(null);
//		 * iotype.setADDR1(null); iotype.setADDR2(null); iotype.setADDR3(null);
//		 * iotype.setADESC(null); iotype.setALTACC(null); iotype.setAmountDates(null);
//		 * iotype.setAUTOCHEQUEBOOKREQ(null); iotype.setAUTODEBITCARDREQUEST(null);
//		 * 
//		 * iotype.setCHQADTE(null); iotype.setCHQINSTNO(null);
//		 * iotype.setCLEARINGTYPE(null); iotype.setCLRBNKCD(null);
//		 * 
//		 * iotype.setCRLMREVDT(null); iotype.setCRLMSTDT(null);
//		 * iotype.setCRSSTSTREQD(null); iotype.setCRTXNLMT(null);
//		 * iotype.setCustAcc(null); iotype.setCustAccCard(null);
//		 * iotype.setCustAccCheck(null); iotype.setCustaccIcccspcn(null);
//		 * iotype.setCustaccIcchspcn(null); iotype.setCustaccIccinstr(null);
//		 * iotype.setCustaccIccintpo(null); iotype.setCustaccSicdiary(null);
//		 * iotype.setCustaccStccusbl(null); iotype.setCUSTNO(null);
//		 * iotype.setCustomerAcc(null); iotype.setCustomerAcc1(null);
//		 * iotype.setDAYLIGHTLIMIT(null); iotype.setDFLTWAIVER(null);
//		 * iotype.setDoctypeRemarks(null); iotype.setDRAWEEACCOUNT(null);
//		 * iotype.setESCROWACCOUNT(null); iotype.setESCROWBRNCODE(null);
//		 * iotype.setESCROWPERCENTAGE(null); iotype.setESCROWTRN(null);
//		 * iotype.setExtsysWsMaster(null); iotype.setFLGEXCLRVRTRANS(null);
//		 * iotype.setGENSTMTMV(null); iotype.setGENSTMTMV2(null);
//		 * iotype.setGENSTMTMV3(null); iotype.setIBANACC(null);
//		 * iotype.setIBANBNKCD(null); iotype.setIntdetails(null);
//		 * iotype.setInterimDetails(null); iotype.setINTERMEDIARYREQUIRED(null);
//		 * iotype.setLinkedentities(null); iotype.setLMTCCY(null); iotype.setLOC(null);
//		 * iotype.setMaster(null); iotype.setMEDIA(null);
//		 * iotype.setMT110RECONREQD(null); iotype.setNETREQ(null); iotype.setNOM1(null);
//		 * iotype.setNOM2(null); iotype.setNoticepref(null); iotype.setOFFLINELIM(null);
//		 * iotype.setOPMODE(null); iotype.setPAYINBY(null); iotype.setPRDLST(null);
//		 * iotype.setPROJACC(null); iotype.setREGCCAVL(null); iotype.setREGDAPP(null);
//		 * iotype.setREGDPER(null); iotype.setREPLCUSTSIG(null);
//		 * iotype.setROUTINGNO(null); iotype.setSODNOTP(null);
//		 * iotype.setSPCONDLST(null); iotype.setSPCONDTXN(null); iotype.setSTMTAC(null);
//		 * iotype.setSttmsCustAccount(null); iotype.setSttmsDebit(null);
//		 * iotype.setSUBLIMIT(null); iotype.setSWEEPIN(null); iotype.setSWEEPOUT(null);
//		 * iotype.setTDCCY(null); iotype.setTddetails(null);
//		 * iotype.setTddetailsprn(null); iotype.setTERMACNO(null);
//		 * iotype.setTODLIMENDT(null); iotype.setTODLIMIT(null);
//		 * iotype.setTODLIMSTDT(null); iotype.setTodRenew(null); iotype.setTRKREC(null);
//		 * iotype.setTXNLST(null); iotype.setUNCOLFUNDLIMIT(null);
//		 */
//
//		body.setCustAccountIO(iotype);
//
//		req.setFCUBSHEADER(createHeaderAccService());
//		req.setFCUBSBODY(body);
//
//		return req;
//	}
////CreateTDSimFS
//
//	public CREATETDSIMFSFSREQ createTDSimFS(CashDepositWithdrawalModel cashDepositWithdrawal,
//			AccountInfoModel accountInfoModel) {
//		CREATETDSIMFSFSREQ req = new CREATETDSIMFSFSREQ();
//		CREATETDSIMFSFSREQ.FCUBSBODY body = new CREATETDSIMFSFSREQ.FCUBSBODY();
//		CustAccType iotype = new CustAccType();
//		// CashDepositWithdrawalModel cashDepositWithdrawal=(CashDepositWithdrawalModel)
//		// cashDepositService.fetchByTransId(transactionId).getBody();
//		// AccountInfoModel accountInfoModel = new AccountInfoModel();
//		iotype.setACC(cashDepositWithdrawal.getAccountNumber().toString());
//		iotype.setACCLS(accountInfoModel.getLastTransactions().toString());
//		iotype.setBRN(cashDepositWithdrawal.getAccountBranch());
//		/*
//		 * iotype.setACCOPENDT(null); iotype.setACCSTAT(null);
//		 * iotype.setACCTYPE(cashDepositWithdrawal.getAccountType());
//		 * iotype.setADESC(null); iotype.setALTACC(null); iotype.setAUTODEPBAL(null);
//		 * iotype.setCCY(null); iotype.setCLRBNKCD(null); iotype.setCUSTNAME(null);
//		 * iotype.setCUSTNO(null); iotype.setIntdetails(null);
//		 * iotype.setMASTERACC(null); iotype.setMINREQBAL(null); iotype.setPRDLST(null);
//		 * iotype.setRECORDSTAT(null); iotype.setSPCONDLST(null);
//		 * iotype.setSPCONDTXN(null); iotype.setSTATSINCE(null);
//		 * iotype.setSWPTYPE(null); iotype.setTddetails(null); iotype.setTXNLST(null);
//		 */
//
//		body.setCustAccountFull(iotype);
//
//		req.setFCUBSHEADER(createHeaderAccService());
//		req.setFCUBSBODY(body);
//
//		return req;
//	}
////CreateTDSimIO
//
//	public CREATETDSIMIOPKREQ createTDSimIO(CashDepositWithdrawalModel cashDepositWithdrawal,
//			AccountInfoModel accountInfoModel) throws RecordNotFoundException {
//		CREATETDSIMIOPKREQ req = new CREATETDSIMIOPKREQ();
//		CREATETDSIMIOPKREQ.FCUBSBODY body = new CREATETDSIMIOPKREQ.FCUBSBODY();
//		CustAccTypeIO4 iotype = new CustAccTypeIO4();
//		// CashDepositWithdrawalModel cashDepositWithdrawal=(CashDepositWithdrawalModel)
//		// cashDepositService.fetchByTransId(transactionId).getBody();
//		// AccountInfoModel accountInfoModel = (AccountInfoModel)
//		// icustAccountServiceImpl.getAccountObj(accountId).getBody();
//		iotype.setACC(cashDepositWithdrawal.getAccountNumber().toString());
//		iotype.setACCLS(accountInfoModel.getLastTransactions().toString());
//		iotype.setBRN(cashDepositWithdrawal.getAccountBranch());
//		/*
//		 * iotype.setACSTMTCYCLE(null); iotype.setACSTMTCYCLE2(null);
//		 * iotype.setACSTMTCYCLE3(null); iotype.setACSTMTCYCLE3(null);
//		 * iotype.setACSTMTDAY(null); iotype.setACSTMTDAY2(null);
//		 * iotype.setACSTMTDAY3(null); iotype.setACSTMTTYPE(null);
//		 * iotype.setACSTMTTYPE2(null); iotype.setACSTMTTYPE3(null);
//		 * iotype.setALLWBKPERENTRY(null); iotype.setATM(null); iotype.setCLRACNO(null);
//		 * iotype.setATMDLIM(null); iotype.setAUTOPROVREQ(null);
//		 * iotype.setAUTOREORDERCHKLVL(null); iotype.setAUTOREORDERCHKLVS(null);
//		 * iotype.setAUTOSTATCHANGE(null); iotype.setCHKNAME1(null);
//		 * iotype.setCHKNAME2(null); iotype.setCHQBOOK(null); iotype.setMT210REQD(null);
//		 * iotype.setDORMPRM(null); iotype.setEXPCATEG(null); iotype.setATMACC(null);
//		 * iotype.setLODGEBKFAC(null); iotype.setMINREQBAL(null);
//		 * iotype.setOFFLINELIM(null); iotype.setPASSBOOK(null);
//		 * iotype.setPROVCCYTYPE(null); iotype.setREFREQ(null); iotype.setREGDAPP(null);
//		 * iotype.setREGDPER(null); iotype.setUNCOLFUNDLIMIT(null);
//		 * iotype.setSWPTYPE(null); iotype.setXREF(null);
//		 */
//
//		body.setCustAccountIO(iotype);
//
//		req.setFCUBSHEADER(createHeaderAccService());
//		req.setFCUBSBODY(body);
//
//		return req;
//	}
//
////DeleteAcClassTfrFS
//
//	public DELETEACCLASSTFRFSFSREQ deleteAcClassTfrFS(CashDepositWithdrawalModel cashDepositWithdrawal,
//			AccountInfoModel accountInfoModel) throws RecordNotFoundException {
//		DELETEACCLASSTFRFSFSREQ req = new DELETEACCLASSTFRFSFSREQ();
//		DELETEACCLASSTFRFSFSREQ.FCUBSBODY body = new DELETEACCLASSTFRFSFSREQ.FCUBSBODY();
//		CustAccTfrFullType iotype = new CustAccTfrFullType();
//
//		// CashDepositWithdrawalModel cashDepositWithdrawal=(CashDepositWithdrawalModel)
//		// cashDepositService.fetchByTransId(transactionId).getBody();
//		// AccountInfoModel accountInfoModel = (AccountInfoModel)
//		// icustAccountServiceImpl.getAccountObj(accountId).getBody();
//
//		iotype.setACC(cashDepositWithdrawal.getAccountNumber().toString());
//		iotype.setACCLS(accountInfoModel.getLastTransactions().toString());
//		iotype.setBRN(cashDepositWithdrawal.getAccountBranch());
//		/*
//		 * iotype.setACSTMTCYCLE(null); iotype.setACSTMTCYCLE2(null);
//		 * iotype.setACSTMTCYCLE3(null); iotype.setACSTMTCYCLE3(null);
//		 * iotype.setACSTMTDAY(null); iotype.setACSTMTDAY2(null);
//		 * iotype.setACSTMTDAY3(null); iotype.setACSTMTTYPE(null);
//		 * iotype.setACSTMTTYPE2(null); iotype.setACSTMTTYPE3(null);
//		 * iotype.setALLWBKPERENTRY(null); iotype.setATM(null);
//		 * iotype.setATMCUSTACNO(null); iotype.setATMDLYAMTLMT(null);
//		 * iotype.setATMDLYLMTCNT(null); iotype.setAUTOPROVREQD(null);
//		 * iotype.setAUTOREORDERCHKLVL(null); iotype.setAUTOREORDERCHKLVS(null);
//		 * iotype.setAUTOREORDERCHKR(null); iotype.setAUTOSTATCHANGE(null);
//		 * iotype.setCHECKNAME1(null); iotype.setCHECKNAME2(null);
//		 * iotype.setCHQBOOK(null); iotype.setCONSREQD(null); iotype.setCRCBLINE(null);
//		 * iotype.setCRHOLINE(null); iotype.setDORMPRM(null); iotype.setDRCBLINE(null);
//		 * iotype.setDRHOLINE(null); iotype.setEFFECTIVEDATE(null);
//		 * iotype.setEXCLSAMEDAYRVRTRNSFMSTMT(null); iotype.setEXPCATEG(null);
//		 * iotype.setIctmAcc(null); iotype.setLODGEBKFAC(null);
//		 * iotype.setMINREQBAL(null); iotype.setMis(null);
//		 * iotype.setNEXTLIQDCYCLE(null); iotype.setOFFLINELIMIT(null);
//		 * iotype.setPASSBOOK(null); iotype.setPROVCCYTYPE(null);
//		 * iotype.setREFREQ(null); iotype.setREGDAPP(null); iotype.setREGDPER(null);
//		 * iotype.setREMARKS(null); iotype.setSWEEPMODE(null);
//		 * iotype.setTRACKRECEIVABLE(null);
//		 */
//
//		body.setMainFull(iotype);
//
//		req.setFCUBSHEADER(createHeaderAccService());
//		req.setFCUBSBODY(body);
//
//		return req;
//
//	}
////DeleteAcClassTfrIO
//
//	public DELETEACCLASSTFRIOPKREQ deleteAcClassTfrIO(CashDepositWithdrawalModel cashDepositWithdrawal,
//			AccountInfoModel accountInfoModel) throws RecordNotFoundException {
//		DELETEACCLASSTFRIOPKREQ req = new DELETEACCLASSTFRIOPKREQ();
//		DELETEACCLASSTFRIOPKREQ.FCUBSBODY body = new DELETEACCLASSTFRIOPKREQ.FCUBSBODY();
//		CustAccTfrDeleteIOType iotype = new CustAccTfrDeleteIOType();
//		// CashDepositWithdrawalModel cashDepositWithdrawal=(CashDepositWithdrawalModel)
//		// cashDepositService.fetchByTransId(transactionId).getBody();
//		// AccountInfoModel accountInfoModel = (AccountInfoModel)
//		// icustAccountServiceImpl.getAccountObj(accountId).getBody();
//
//		iotype.setACC(cashDepositWithdrawal.getAccountNumber().toString());
//		iotype.setACCLS(accountInfoModel.getLastTransactions().toString());
//		iotype.setBRN(accountInfoModel.getAccountBranch());
//
//		body.setMainIO(iotype);
//
//		req.setFCUBSHEADER(createHeaderAccService());
//		req.setFCUBSBODY(body);
//
//		return req;
//	}
////DeleteCheckBookFS
//
//	public DELETECHECKBOOKFSFSREQ deleteCheckBookFS(CashDepositWithdrawalModel cashDepositWithdrawal,
//			AccountInfoModel accountInfoModel) throws RecordNotFoundException {
//		DELETECHECKBOOKFSFSREQ req = new DELETECHECKBOOKFSFSREQ();
//		DELETECHECKBOOKFSFSREQ.FCUBSBODY body = new DELETECHECKBOOKFSFSREQ.FCUBSBODY();
//		CheckBookFullType iotype = new CheckBookFullType();
//		// CashDepositWithdrawalModel cashDepositWithdrawal=(CashDepositWithdrawalModel)
//		// cashDepositService.fetchByTransId(transactionId).getBody();
//		// AccountInfoModel accountInfoModel = (AccountInfoModel)
//		// icustAccountServiceImpl.getAccountObj(accountId).getBody();
//
//		iotype.setACCOUNT(cashDepositWithdrawal.getAccountNumber().toString());
//		iotype.setAUTHSTAT(cashDepositWithdrawal.getAuthStatus());
//		iotype.setMODNO(BigDecimal.valueOf(accountInfoModel.getModificationNo()));
//		/*
//		 * iotype.setTXNSTAT(cashDepositWithdrawal.getTransactionStatus().toString());
//		 * iotype.setAPPLYCHARGE(null); iotype.setCHECKLEAVES(null);
//		 * iotype.setDELIVERYADD1(null); iotype.setDELIVERYADD2(null);
//		 * iotype.setDELIVERYADD3(null); iotype.setDELIVERYADD4(null);
//		 * iotype.setDELIVERYMODE(null); iotype.setINCLFORCHKBOOKPRINTING(null);
//		 * iotype.setLANGCODE(null); iotype.setORDERDATE(null);
//		 * iotype.setORDERDETAILS(null); iotype.setREQUESTMODE(null);
//		 * iotype.setREQUESTSTATUS(null); iotype.setCHBKTYPE(null);
//		 * iotype.setChargeMain(null); iotype.setCHECKER(null);
//		 * iotype.setCHECKERSTAMP(null); iotype.setISSUEDATE(null);
//		 * iotype.setEventMaster(null); iotype.setMAKER(null);
//		 * iotype.setMAKERSTAMP(null); iotype.setMODNO(null);
//		 * iotype.setAPPLYCHARGE(null);
//		 */
//
//		body.setChqBkDetailsFull(iotype);
//
//		req.setFCUBSHEADER(createHeaderAccService());
//		req.setFCUBSBODY(body);
//
//		return req;
//	}
////DeleteCheckBookIO
//
//	public DELETECHECKBOOKIOPKREQ deleteCheckBookIO(CashDepositWithdrawalModel cashDepositWithdrawal) {
//		DELETECHECKBOOKIOPKREQ req = new DELETECHECKBOOKIOPKREQ();
//		DELETECHECKBOOKIOPKREQ.FCUBSBODY body = new DELETECHECKBOOKIOPKREQ.FCUBSBODY();
//		CheckBookDeleteIOType iotype = new CheckBookDeleteIOType();
//		// CashDepositWithdrawalModel cashDepositWithdrawal=(CashDepositWithdrawalModel)
//		// cashDepositService.fetchByTransId(transactionId).getBody();
//
//		iotype.setACCOUNT(cashDepositWithdrawal.getAccountNumber().toString());
//
//		body.setChqBkDetailsIO(iotype);
//
//		req.setFCUBSHEADER(createHeaderAccService());
//		req.setFCUBSBODY(body);
//
//		return req;
//	}
////DeleteCustAccFS
//
//	public DELETECUSTACCFSFSREQ deleteCustAccFS(CashDepositWithdrawalModel cashDepositWithdrawal,
//			IcCountryModel icCountryModel) throws RecordNotFoundException {
//		DELETECUSTACCFSFSREQ req = new DELETECUSTACCFSFSREQ();
//		DELETECUSTACCFSFSREQ.FCUBSBODY body = new DELETECUSTACCFSFSREQ.FCUBSBODY();
//		CustAccFullType iotype = new CustAccFullType();
////	CashDepositWithdrawalModel cashDepositWithdrawal=(CashDepositWithdrawalModel) cashDepositService.fetchByTransId(transactionId).getBody();
////	IcCountryModel icCountryModel = new IcCountryModel();
//
//		iotype.setACCTYPE(cashDepositWithdrawal.getAccountType());
//		iotype.setAUTHSTAT(cashDepositWithdrawal.getAuthStatus());
//		iotype.setBRN(cashDepositWithdrawal.getAccountBranch());
//		iotype.setCOUNTRYCODE(icCountryModel.getCountryCode());
//		/*
//		 * iotype.setACC(null); iotype.setAccclose(null);
//		 * iotype.setAcccrdrlmtsMain(null); iotype.setACCLS(null);
//		 * iotype.setAccmaintinstr(null); iotype.setACCOPENDT(null);
//		 * iotype.setACCOUNTAUTOCLOSED(null); iotype.setAccstatusMain(null);
//		 * iotype.setAccSvcacsig(null);
//		 * 
//		 * iotype.setACSTMTCYCLE(null); iotype.setACSTMTCYCLE2(null);
//		 * iotype.setACSTMTCYCLE3(null); iotype.setACSTMTCYCLE3(null);
//		 * iotype.setACSTMTDAY(null); iotype.setACSTMTDAY2(null);
//		 * iotype.setACSTMTDAY3(null); iotype.setACSTMTTYPE3(null);
//		 * iotype.setACSTMTTYPEP(null); iotype.setACSTMTTYPS(null);
//		 * iotype.setADDR1(null); iotype.setADDR2(null); iotype.setADDR3(null);
//		 * iotype.setADESC(null); iotype.setALTACC(null); iotype.setAmountDates(null);
//		 * iotype.setAuthbicdetailsMain(null);
//		 * 
//		 * iotype.setAUTOCHEQUEBOOKREQ(null); iotype.setAUTODEBITCARDREQUEST(null);
//		 * iotype.setAUTODEPBAL(null);
//		 * 
//		 * iotype.setCHECKER(null); iotype.setCHECKERSTAMP(null);
//		 * iotype.setCHQBOOK(null); iotype.setCLRBNKCD(null);
//		 * 
//		 * iotype.setCRLMREVDT(null); iotype.setCRLMSTDT(null);
//		 * iotype.setCRSSTSTREQD(null); iotype.setCRTXNLMT(null);
//		 * iotype.setCustAcc(null); iotype.setCustAccCard(null);
//		 * iotype.setCustAccCheck(null); iotype.setCustaccIcccspcn(null);
//		 * iotype.setCustaccIcchspcn(null); iotype.setCustaccIccinstr(null);
//		 * iotype.setCustaccIccintpo(null); iotype.setCustaccSicdiary(null);
//		 * iotype.setCustaccStccusbl(null); iotype.setCUSTNAME(null);
//		 * iotype.setCUSTNO(null); iotype.setCustomerAcc(null);
//		 * iotype.setCustomerAcc1(null); iotype.setDAYLIGHTLIMIT(null);
//		 * iotype.setDFLTWAIVER(null); iotype.setDoctypeRemarks(null);
//		 * iotype.setESCROWACCOUNT(null); iotype.setESCROWBRNCODE(null);
//		 * iotype.setESCROWPERCENTAGE(null); iotype.setESCROWTRN(null);
//		 * iotype.setExtsysWsMaster(null); iotype.setFLGEXCLRVRTRANS(null);
//		 * iotype.setGENSTMTMV(null); iotype.setGENSTMTMV2(null);
//		 * iotype.setGENSTMTMV3(null); iotype.setIBANACC(null);
//		 * iotype.setIBANBNKCD(null); iotype.setIntdetails(null);
//		 * iotype.setInterimDetails(null); iotype.setINTERMEDIARYREQUIRED(null);
//		 * iotype.setJointholdersMain(null); iotype.setLinkedentities(null);
//		 * iotype.setLMTCCY(null); iotype.setLOC(null); iotype.setMaster(null);
//		 * iotype.setMAKER(null); iotype.setMAKERSTAMP(null); iotype.setMASTERACC(null);
//		 * iotype.setMEDIA(null); iotype.setMINREQBAL(null); iotype.setMODNO(null);
//		 * iotype.setMT110RECONREQD(null); iotype.setNETREQ(null); iotype.setNOM1(null);
//		 * iotype.setNOM2(null); iotype.setNoticepref(null); iotype.setNSFBLKSTAT(null);
//		 * iotype.setOFFLINELIM(null); iotype.setOPMODE(null);
//		 * iotype.setPASSBOOKNUMBER(null); iotype.setPASSBOOKSTATUS(null);
//		 * iotype.setPAYINOPTION(null); iotype.setPRDLST(null); iotype.setPrdtxn(null);
//		 * iotype.setPREVSTMTBAL(null); iotype.setPREVSTMTBAL2(null);
//		 * iotype.setPREVSTMTBAL3(null); iotype.setPREVSTMTDT(null);
//		 * iotype.setPREVSTMTDT2(null); iotype.setPREVSTMTDT3(null);
//		 * iotype.setPREVSTMTNO(null); iotype.setPREVSTMTNO2(null);
//		 * iotype.setPREVSTMTNO3(null); iotype.setPRIVATECUSTOMER(null);
//		 * iotype.setPROJACC(null); iotype.setProvisionMain(null);
//		 * iotype.setREGCCAVL(null); iotype.setREGDAPP(null); iotype.setREGDENDT(null);
//		 * iotype.setREGDPER(null); iotype.setREGDSTDT(null);
//		 * iotype.setREPLCUSTSIG(null); iotype.setSDREFNO(null);
//		 * iotype.setSODNOTP(null); iotype.setSPCONDLST(null);
//		 * iotype.setSPCONDTXN(null); iotype.setStatement(null); iotype.setSTMTAC(null);
//		 * iotype.setSttmsCustAccount(null); iotype.setSttmsDebit(null);
//		 * iotype.setSUBLIMIT(null); iotype.setSWEEPIN(null); iotype.setSWEEPOUT(null);
//		 * iotype.setSWPTYPE(null); iotype.setLMTCCY(null); iotype.setTddetails(null);
//		 * iotype.setTddetails(null); iotype.setATMCUSTACNO(null);
//		 * iotype.setTODLIMENDT(null); iotype.setTODLIMIT(null);
//		 * iotype.setTODLIMSTDT(null); iotype.setTodRenew(null); iotype.setTRKREC(null);
//		 * iotype.setTXNLST(null); iotype.setTXNSTAT(null);
//		 * iotype.setUNCOLFUNDLIMIT(null);
//		 */
//
//		body.setCustAccountFull(iotype);
//
//		req.setFCUBSHEADER(createHeaderAccService());
//		req.setFCUBSBODY(body);
//
//		return req;
//	}
////DeleteCustAccIO
//
//	public DELETECUSTACCIOPKREQ deleteCustAccIO(CashDepositWithdrawalModel cashDepositWithdrawal) {
//		DELETECUSTACCIOPKREQ req = new DELETECUSTACCIOPKREQ();
//		DELETECUSTACCIOPKREQ.FCUBSBODY body = new DELETECUSTACCIOPKREQ.FCUBSBODY();
//		CustAccDeleteIOType iotype = new CustAccDeleteIOType();
//		// CashDepositWithdrawalModel cashDepositWithdrawal=(CashDepositWithdrawalModel)
//		// cashDepositService.fetchByTransId(transactionId).getBody();
//		iotype.setACC(cashDepositWithdrawal.getAccountNumber().toString());
//		iotype.setBRN(cashDepositWithdrawal.getAccountBranch());
//
//		body.setCustAccountIO(iotype);
//
//		req.setFCUBSHEADER(createHeaderAccService());
//		req.setFCUBSBODY(body);
//
//		return req;
//	}
//
////DeleteStopPaymentsFS
//
//	public DELETESTOPPAYMENTSFSFSREQ deleteStopPaymentsFS(CashDepositWithdrawalModel cashDepositWithdrawal,
//			AccountInfoModel accountInfoModel) throws RecordNotFoundException {
//		DELETESTOPPAYMENTSFSFSREQ req = new DELETESTOPPAYMENTSFSFSREQ();
//		DELETESTOPPAYMENTSFSFSREQ.FCUBSBODY body = new DELETESTOPPAYMENTSFSFSREQ.FCUBSBODY();
//		StopPaymentsFullType iotype = new StopPaymentsFullType();
//		// CashDepositWithdrawalModel cashDepositWithdrawal=(CashDepositWithdrawalModel)
//		// cashDepositService.fetchByTransId(transactionId).getBody();
//		// AccountInfoModel accountInfoModel = (AccountInfoModel)
//		// icustAccountServiceImpl.getAccountObj(accountId).getBody();
//
//		iotype.setACCNUMBER(cashDepositWithdrawal.getAccountNumber().toString());
//		iotype.setAUTHSTAT(cashDepositWithdrawal.getAuthStatus());
//		iotype.setENDCHECKNO(cashDepositWithdrawal.getChequeNumber());
//		iotype.setMODNO(BigDecimal.valueOf(accountInfoModel.getModificationNo()));
//		/*
//		 * iotype.setTXNSTAT(cashDepositWithdrawal.getTransactionStatus().toString());
//		 * iotype.setAPPLYCHARGE(null); iotype.setCONFIRMED(null);
//		 * iotype.setEventMaster(null); iotype.setADVFTREQDFLG(null);
//		 * iotype.setChargeMain(null); iotype.setCHECKER(null);
//		 * iotype.setCHECKERSTAMP(null); iotype.setEFFECTIVEDATE(null);
//		 * iotype.setEventMaster(null); iotype.setMAKER(null);
//		 * iotype.setMAKERSTAMP(null); iotype.setMODNO(null);
//		 * iotype.setAPPLYCHARGE(null); iotype.setEXPIRYDATE(null);
//		 * iotype.setRELETEDREFERENCE(null); iotype.setREMARKS(null);
//		 * iotype.setSTARTCHECKNO(null); iotype.setSTOPPAYMENTNO(null);
//		 * iotype.setSTOPPAYMENTTYPE(null);
//		 */
//
//		body.setCatmsStopPaymentsFull(iotype);
//
//		req.setFCUBSHEADER(createHeaderAccService());
//		req.setFCUBSBODY(body);
//
//		return req;
//	}
////DeleteStopPaymentsIO
//
//	public DELETESTOPPAYMENTSIOPKREQ deleteStopPaymentsIO(CashDepositWithdrawalModel cashDepositWithdrawal) {
//		DELETESTOPPAYMENTSIOPKREQ req = new DELETESTOPPAYMENTSIOPKREQ();
//		DELETESTOPPAYMENTSIOPKREQ.FCUBSBODY body = new DELETESTOPPAYMENTSIOPKREQ.FCUBSBODY();
//		StopPaymentsDeleteIOType iotype = new StopPaymentsDeleteIOType();
//		// CashDepositWithdrawalModel cashDepositWithdrawal=(CashDepositWithdrawalModel)
//		// cashDepositService.fetchByTransId(transactionId).getBody();
//
//		iotype.setSTOPPAYMENTNO(null);
//		body.setCatmsStopPaymentsIO(iotype);
//
//		req.setFCUBSHEADER(createHeaderAccService());
//		req.setFCUBSBODY(body);
//
//		return req;
//	}
////DeleteTDCustAccFS
//
//	public DELETETDCUSTACCFSFSREQ deleteTDCustAccFS(CashDepositWithdrawalModel cashDepositWithdrawal,
//			IcCountryModel icCountryModel) throws RecordNotFoundException {
//		DELETETDCUSTACCFSFSREQ req = new DELETETDCUSTACCFSFSREQ();
//		DELETETDCUSTACCFSFSREQ.FCUBSBODY body = new DELETETDCUSTACCFSFSREQ.FCUBSBODY();
//		TDCustAccFullType iotype = new TDCustAccFullType();
//		// CashDepositWithdrawalModel cashDepositWithdrawal=(CashDepositWithdrawalModel)
//		// cashDepositService.fetchByTransId(transactionId).getBody();
//		// IcCountryModel icCountryModel = new IcCountryModel();
//
//		iotype.setACCTYPE(cashDepositWithdrawal.getAccountType());
//		iotype.setAUTHSTAT(cashDepositWithdrawal.getAuthStatus());
//		iotype.setBRN(cashDepositWithdrawal.getAccountBranch());
//		iotype.setCOUNTRY(icCountryModel.getCountryName());
//		iotype.setCOUNTRYCODE(icCountryModel.getCountryCode());
//		/*
//		 * iotype.setAccclose(null); iotype.setAcccrdrlmtsMain(null);
//		 * iotype.setACCLS(null); iotype.setAccmaintinstr(null);
//		 * iotype.setACCOPENDT(null); iotype.setACCOUNTAUTOCLOSED(null);
//		 * iotype.setAccstatusMain(null); iotype.setAccSvcacsig(null);
//		 * 
//		 * iotype.setACSTMTCYCLE(null); iotype.setACSTMTCYCLE2(null);
//		 * iotype.setACSTMTCYCLE3(null); iotype.setACSTMTCYCLE3(null);
//		 * iotype.setACSTMTDAY(null); iotype.setACSTMTDAY2(null);
//		 * iotype.setACSTMTDAY3(null); iotype.setACSTMTTYPE3(null);
//		 * iotype.setACSTMTTYPEP(null); iotype.setACSTMTTYPS(null);
//		 * iotype.setADDR1(null); iotype.setADDR2(null); iotype.setADDR3(null);
//		 * iotype.setADESC(null); iotype.setALTACC(null); iotype.setAmountDates(null);
//		 * iotype.setAuthbicdetailsMain(null);
//		 * 
//		 * iotype.setAUTOCHEQUEBOOKREQ(null); iotype.setAUTODEBITCARDREQUEST(null);
//		 * iotype.setAUTODEPBAL(null);
//		 * 
//		 * iotype.setCHECKER(null); iotype.setCHECKERSTAMP(null);
//		 * iotype.setCHQADTE(null); iotype.setCHQINSTNO(null);
//		 * iotype.setCLEARINGTYPE(null); iotype.setCLRBNKCD(null);
//		 * 
//		 * iotype.setCRLMREVDT(null); iotype.setCRLMSTDT(null);
//		 * iotype.setCRSSTSTREQD(null); iotype.setCRTXNLMT(null);
//		 * iotype.setCustAcc(null); iotype.setCustAccCard(null);
//		 * iotype.setCustAccCheck(null); iotype.setCustaccIcccspcn(null);
//		 * iotype.setCustaccIcchspcn(null); iotype.setCustaccIccinstr(null);
//		 * iotype.setCustaccIccintpo(null); iotype.setCustaccSicdiary(null);
//		 * iotype.setCustaccStccusbl(null); iotype.setCUSTNAME(null);
//		 * iotype.setCUSTNO(null); iotype.setCustomerAcc(null);
//		 * iotype.setCustomerAcc1(null); iotype.setDAYLIGHTLIMIT(null);
//		 * iotype.setDFLTWAIVER(null); iotype.setDoctypeRemarks(null);
//		 * iotype.setDRAWEEACCOUNT(null); iotype.setESCROWACCOUNT(null);
//		 * iotype.setESCROWBRNCODE(null); iotype.setESCROWPERCENTAGE(null);
//		 * iotype.setESCROWTRN(null); iotype.setExtsysWsMaster(null);
//		 * iotype.setFLGEXCLRVRTRANS(null); iotype.setGENSTMTMV(null);
//		 * iotype.setGENSTMTMV2(null); iotype.setGENSTMTMV3(null);
//		 * iotype.setIBANACC(null); iotype.setIBANBNKCD(null);
//		 * iotype.setIntdetails(null); iotype.setInterimDetails(null);
//		 * iotype.setINTERMEDIARYREQUIRED(null); iotype.setJointholdersMain(null);
//		 * iotype.setLinkedentities(null); iotype.setLMTCCY(null); iotype.setLOC(null);
//		 * iotype.setMaster(null); iotype.setMAKER(null); iotype.setMAKERSTAMP(null);
//		 * iotype.setMASTERACC(null); iotype.setMEDIA(null); iotype.setMINREQBL(null);
//		 * iotype.setMODNO(null); iotype.setMT110RECONREQD(null);
//		 * iotype.setNETREQ(null); iotype.setNOM1(null); iotype.setNOM2(null);
//		 * iotype.setNoticepref(null); iotype.setNSFBLKSTAT(null);
//		 * iotype.setOFFLINELIM(null); iotype.setOPMODE(null);
//		 * iotype.setPASSBOOKNUMBER(null); iotype.setPASSBOOKSTATUS(null);
//		 * iotype.setPAYINBY(null); iotype.setPRDLST(null); iotype.setPrdtxn(null);
//		 * iotype.setPREVSTMTBAL(null); iotype.setPREVSTMTBAL2(null);
//		 * iotype.setPREVSTMTBAL3(null); iotype.setPREVSTMTDT(null);
//		 * iotype.setPREVSTMTDT2(null); iotype.setPREVSTMTDT3(null);
//		 * iotype.setPREVSTMTNO(null); iotype.setPREVSTMTNO2(null);
//		 * iotype.setPREVSTMTNO3(null); iotype.setPRIVATECUSTOMER(null);
//		 * iotype.setPROJACC(null); iotype.setProvisionMain(null);
//		 * iotype.setREGCCAVL(null); iotype.setREGDAPP(null); iotype.setREGDENDT(null);
//		 * iotype.setREGDPER(null); iotype.setREGDSTDT(null);
//		 * iotype.setREPLCUSTSIG(null); iotype.setROUTINGNO(null);
//		 * iotype.setSDREFNO(null); iotype.setSODNOTP(null); iotype.setSPCONDLST(null);
//		 * iotype.setSPCONDTXN(null); iotype.setStatement(null); iotype.setSTMTAC(null);
//		 * iotype.setSttmsCustAccount(null); iotype.setSttmsDebit(null);
//		 * iotype.setSUBLIMIT(null); iotype.setSWEEPIN(null); iotype.setSWEEPOUT(null);
//		 * iotype.setSWPTYPE(null); iotype.setTDCCY(null); iotype.setTddetails(null);
//		 * iotype.setTddetailsprn(null); iotype.setTERMACNO(null);
//		 * iotype.setTODLIMENDT(null); iotype.setTODLIMIT(null);
//		 * iotype.setTODLIMSTDT(null); iotype.setTodRenew(null); iotype.setTRKREC(null);
//		 * iotype.setTXNLST(null); iotype.setTXNSTAT(null);
//		 * iotype.setUNCOLFUNDLIMIT(null);
//		 */
//
//		body.setCustAccountFull(iotype);
//
//		req.setFCUBSHEADER(createHeaderAccService());
//		req.setFCUBSBODY(body);
//
//		return req;
//	}
////DeleteTDCustAccIO
//
//	public DELETETDCUSTACCIOPKREQ deleteTDCustAccIO(CashDepositWithdrawalModel cashDepositWithdrawal) {
//		DELETETDCUSTACCIOPKREQ req = new DELETETDCUSTACCIOPKREQ();
//		DELETETDCUSTACCIOPKREQ.FCUBSBODY body = new DELETETDCUSTACCIOPKREQ.FCUBSBODY();
//		TDCustAccDeleteIOType iotype = new TDCustAccDeleteIOType();
//		// CashDepositWithdrawalModel cashDepositWithdrawal=(CashDepositWithdrawalModel)
//		// cashDepositService.fetchByTransId(transactionId).getBody();
//
//		iotype.setBRN(cashDepositWithdrawal.getAccountBranch());
////	iotype.setTERMACNO(null);;
//		body.setCustAccountIO(iotype);
//
//		req.setFCUBSHEADER(createHeaderAccService());
//		req.setFCUBSBODY(body);
//
//		return req;
//	}
//
////ModifyAcClassTfrFS
//
//	public MODIFYACCLASSTFRFSFSREQ modifyAcClassTfrFS(Long transactionId, Long accountId)
//			throws RecordNotFoundException {
//		MODIFYACCLASSTFRFSFSREQ req = new MODIFYACCLASSTFRFSFSREQ();
//		MODIFYACCLASSTFRFSFSREQ.FCUBSBODY body = new MODIFYACCLASSTFRFSFSREQ.FCUBSBODY();
//		CustAccTfrFullType iotype = new CustAccTfrFullType();
//		CashDepositWithdrawalModel cashDepositWithdrawal = (CashDepositWithdrawalModel) cashDepositService
//				.fetchByTransId(transactionId).getBody();
//		AccountInfoModel accountInfoModel = (AccountInfoModel) icustAccountServiceImpl.getAccountObj(accountId)
//				.getBody();
//
//		iotype.setACC(cashDepositWithdrawal.getAccountNumber().toString());
//		iotype.setACCLS(accountInfoModel.getLastTransactions().toString());
//		iotype.setBRN(cashDepositWithdrawal.getAccountBranch());
//		/*
//		 * iotype.setACSTMTCYCLE(null); iotype.setACSTMTCYCLE2(null);
//		 * iotype.setACSTMTCYCLE3(null); iotype.setACSTMTCYCLE3(null);
//		 * iotype.setACSTMTDAY(null); iotype.setACSTMTDAY2(null);
//		 * iotype.setACSTMTDAY3(null); iotype.setACSTMTTYPE(null);
//		 * iotype.setACSTMTTYPE2(null); iotype.setACSTMTTYPE3(null);
//		 * iotype.setALLWBKPERENTRY(null); iotype.setATM(null);
//		 * iotype.setATMCUSTACNO(null); iotype.setATMDLYAMTLMT(null);
//		 * iotype.setATMDLYLMTCNT(null); iotype.setAUTOPROVREQD(null);
//		 * iotype.setAUTOREORDERCHKLVL(null); iotype.setAUTOREORDERCHKLVS(null);
//		 * iotype.setAUTOREORDERCHKR(null); iotype.setAUTOSTATCHANGE(null);
//		 * iotype.setCHECKNAME1(null); iotype.setCHECKNAME2(null);
//		 * iotype.setCHQBOOK(null); iotype.setCONSREQD(null); iotype.setCRCBLINE(null);
//		 * iotype.setCRHOLINE(null); iotype.setDORMPRM(null); iotype.setDRCBLINE(null);
//		 * iotype.setDRHOLINE(null); iotype.setEFFECTIVEDATE(null);
//		 * iotype.setEXCLSAMEDAYRVRTRNSFMSTMT(null); iotype.setEXPCATEG(null);
//		 * iotype.setIctmAcc(null); iotype.setLODGEBKFAC(null);
//		 * iotype.setMINREQBAL(null); iotype.setMis(null);
//		 * iotype.setNEXTLIQDCYCLE(null); iotype.setOFFLINELIMIT(null);
//		 * iotype.setPASSBOOK(null); iotype.setPROVCCYTYPE(null);
//		 * iotype.setREFREQ(null); iotype.setREGDAPP(null); iotype.setREGDPER(null);
//		 * iotype.setREMARKS(null); iotype.setSWEEPMODE(null);
//		 * iotype.setTRACKRECEIVABLE(null);
//		 */
//
//		body.setMainFull(iotype);
//
//		req.setFCUBSHEADER(createHeaderAccService());
//		req.setFCUBSBODY(body);
//
//		return req;
//	}
////ModifyAcClassTfrIO
//
//	public MODIFYACCLASSTFRIOPKREQ modifyAcClassTfrIO(CashDepositWithdrawalModel cashDepositWithdrawal,
//			AccountInfoModel accountInfoModel) throws RecordNotFoundException {
//		MODIFYACCLASSTFRIOPKREQ req = new MODIFYACCLASSTFRIOPKREQ();
//		MODIFYACCLASSTFRIOPKREQ.FCUBSBODY body = new MODIFYACCLASSTFRIOPKREQ.FCUBSBODY();
//		CustAccTfrModifyIOType iotype = new CustAccTfrModifyIOType();
//		// CashDepositWithdrawalModel cashDepositWithdrawal=(CashDepositWithdrawalModel)
//		// cashDepositService.fetchByTransId(transactionId).getBody();
//		// AccountInfoModel accountInfoModel = (AccountInfoModel)
//		// icustAccountServiceImpl.getAccountObj(accountId).getBody();
//
//		iotype.setACC(cashDepositWithdrawal.getAccountNumber().toString());
//		iotype.setACCLS(accountInfoModel.getLastTransactions().toString());
//		iotype.setBRN(cashDepositWithdrawal.getAccountBranch());
//		/*
//		 * iotype.setACSTMTCYCLE(null); iotype.setACSTMTCYCLE2(null);
//		 * iotype.setACSTMTCYCLE3(null); iotype.setACSTMTCYCLE3(null);
//		 * iotype.setACSTMTDAY(null); iotype.setACSTMTDAY2(null);
//		 * iotype.setACSTMTDAY3(null); iotype.setACSTMTTYPE(null);
//		 * iotype.setACSTMTTYPE2(null); iotype.setACSTMTTYPE3(null);
//		 * iotype.setALLWBKPERENTRY(null); iotype.setATM(null);
//		 * iotype.setAUTOPROVREQD(null); iotype.setAUTOREORDERCHKLVL(null);
//		 * iotype.setAUTOREORDERCHKLVS(null); iotype.setAUTOREORDERCHKR(null);
//		 * iotype.setAUTOSTATCHANGE(null); iotype.setCHQBOOK(null);
//		 * iotype.setCONSREQD(null); iotype.setCRCBLINE(null); iotype.setCRHOLINE(null);
//		 * iotype.setDORMPRM(null); iotype.setDRCBLINE(null); iotype.setDRHOLINE(null);
//		 * iotype.setEFFECTIVEDATE(null); iotype.setEXCLSAMEDAYRVRTRNSFMSTMT(null);
//		 * iotype.setEXPCATEG(null); iotype.setIctmAcc(null);
//		 * iotype.setLODGEBKFAC(null); iotype.setMINREQBAL(null); iotype.setMis(null);
//		 * iotype.setNEXTLIQDCYCLE(null); iotype.setOFFLINELIMIT(null);
//		 * iotype.setPASSBOOK(null); iotype.setPROVCCYTYPE(null);
//		 * iotype.setREFREQ(null); iotype.setREGDAPP(null); iotype.setREGDPER(null);
//		 * iotype.setREMARKS(null); iotype.setSWEEPMODE(null);
//		 * iotype.setTRACKRECEIVABLE(null);
//		 */
//
//		body.setMainIO(iotype);
//
//		req.setFCUBSHEADER(createHeaderAccService());
//		req.setFCUBSBODY(body);
//
//		return req;
//	}
////ModifyCheckBookFS
//
//	public MODIFYCHECKBOOKFSFSREQ modifyCheckBookFS(CashDepositWithdrawalModel cashDepositWithdrawal,
//			AccountInfoModel accountInfoModel) throws RecordNotFoundException {
//		MODIFYCHECKBOOKFSFSREQ req = new MODIFYCHECKBOOKFSFSREQ();
//		MODIFYCHECKBOOKFSFSREQ.FCUBSBODY body = new MODIFYCHECKBOOKFSFSREQ.FCUBSBODY();
//		CheckBookFullType iotype = new CheckBookFullType();
//		// CashDepositWithdrawalModel cashDepositWithdrawal=(CashDepositWithdrawalModel)
//		// cashDepositService.fetchByTransId(transactionId).getBody();
//		// AccountInfoModel accountInfoModel = (AccountInfoModel)
//		// icustAccountServiceImpl.getAccountObj(accountId).getBody();
//
//		iotype.setACCOUNT(cashDepositWithdrawal.getAccountNumber().toString());
//		iotype.setAUTHSTAT(cashDepositWithdrawal.getAuthStatus());
//		iotype.setMODNO(BigDecimal.valueOf(accountInfoModel.getModificationNo()));
//		/*
//		 * iotype.setTXNSTAT(cashDepositWithdrawal.getTransactionStatus().toString());
//		 * iotype.setAPPLYCHARGE(null); iotype.setCHECKLEAVES(null);
//		 * iotype.setDELIVERYADD1(null); iotype.setDELIVERYADD2(null);
//		 * iotype.setDELIVERYADD3(null); iotype.setDELIVERYADD4(null);
//		 * iotype.setDELIVERYMODE(null); iotype.setINCLFORCHKBOOKPRINTING(null);
//		 * iotype.setLANGCODE(null); iotype.setORDERDATE(null);
//		 * iotype.setORDERDETAILS(null); iotype.setREQUESTMODE(null);
//		 * iotype.setREQUESTSTATUS(null); iotype.setCHBKTYPE(null);
//		 * iotype.setChargeMain(null); iotype.setCHECKER(null);
//		 * iotype.setCHECKERSTAMP(null); iotype.setISSUEDATE(null);
//		 * iotype.setEventMaster(null); iotype.setMAKER(null);
//		 * iotype.setMAKERSTAMP(null); iotype.setMODNO(null);
//		 */
//
//		body.setChqBkDetailsFull(iotype);
//
//		req.setFCUBSHEADER(createHeaderAccService());
//		req.setFCUBSBODY(body);
//
//		return req;
//	}
////ModifyCheckBookIO
//
//	public MODIFYCHECKBOOKIOPKREQ modifyCheckBookIO(CashDepositWithdrawalModel cashDepositWithdrawal)
//			throws RecordNotFoundException {
//		MODIFYCHECKBOOKIOPKREQ req = new MODIFYCHECKBOOKIOPKREQ();
//		MODIFYCHECKBOOKIOPKREQ.FCUBSBODY body = new MODIFYCHECKBOOKIOPKREQ.FCUBSBODY();
//		CheckBookModifyIOType iotype = new CheckBookModifyIOType();
//		// CashDepositWithdrawalModel cashDepositWithdrawal=(CashDepositWithdrawalModel)
//		// cashDepositService.fetchByTransId(transactionId).getBody();
//		// AccountInfoModel accountInfoModel = (AccountInfoModel)
//		// icustAccountServiceImpl.getAccountObj(accountId).getBody();
//
//		iotype.setACCOUNT(cashDepositWithdrawal.getAccountNumber().toString());
//		/*
//		 * iotype.setAPPLYCHARGE(null); iotype.setORDERDETAILS(null);
//		 * iotype.setREQUESTSTATUS(null); iotype.setChargeMain(null);
//		 * iotype.setEventMaster(null); iotype.setMAKER(null);
//		 * iotype.setMAKERSTAMP(null);
//		 */
//
//		body.setChqBkDetailsIO(iotype);
//
//		req.setFCUBSHEADER(createHeaderAccService());
//		req.setFCUBSBODY(body);
//
//		return req;
//	}
//
////ModifyCustAccFS
//
//	public MODIFYCUSTACCFSFSREQ modifyCustAccFS(CashDepositWithdrawalModel cashDepositWithdrawal,
//			IcCountryModel icCountryModel) throws RecordNotFoundException {
//		MODIFYCUSTACCFSFSREQ req = new MODIFYCUSTACCFSFSREQ();
//		MODIFYCUSTACCFSFSREQ.FCUBSBODY body = new MODIFYCUSTACCFSFSREQ.FCUBSBODY();
//		CustAccFullType iotype = new CustAccFullType();
//		// CashDepositWithdrawalModel cashDepositWithdrawal=(CashDepositWithdrawalModel)
//		// cashDepositService.fetchByTransId(transactionId).getBody();
//		// AccountInfoModel accountInfoModel = (AccountInfoModel)
//		// icustAccountServiceImpl.getAccountObj(accountId).getBody();
//
//		// IcCountryModel icCountryModel = new IcCountryModel();
//		// CustomerInfoModel customerInfoModel=new CustomerInfoModel();
//		iotype.setACCTYPE(cashDepositWithdrawal.getAccountType());
//		iotype.setCOUNTRYCODE(icCountryModel.getCountryCode());
//		iotype.setBRN(cashDepositWithdrawal.getAccountBranch());
//		iotype.setAUTHSTAT(cashDepositWithdrawal.getAuthStatus());
//		/*
//		 * iotype.setACC(null); iotype.setAccclose(null);
//		 * iotype.setAcccrdrlmtsMain(null); iotype.setACCLS(null);
//		 * iotype.setAccmaintinstr(null); iotype.setACCOPENDT(null);
//		 * iotype.setACCOUNTAUTOCLOSED(null); iotype.setAccstatusMain(null);
//		 * iotype.setAccSvcacsig(null);
//		 * 
//		 * iotype.setACSTMTCYCLE(null); iotype.setACSTMTCYCLE2(null);
//		 * iotype.setACSTMTCYCLE3(null); iotype.setACSTMTCYCLE3(null);
//		 * iotype.setACSTMTDAY(null); iotype.setACSTMTDAY2(null);
//		 * iotype.setACSTMTDAY3(null); iotype.setACSTMTTYPE3(null);
//		 * iotype.setACSTMTTYPEP(null); iotype.setACSTMTTYPS(null);
//		 * iotype.setADDR1(null); iotype.setADDR2(null); iotype.setADDR3(null);
//		 * iotype.setADESC(null); iotype.setALTACC(null); iotype.setAmountDates(null);
//		 * iotype.setAuthbicdetailsMain(null);
//		 * 
//		 * iotype.setAUTOCHEQUEBOOKREQ(null); iotype.setAUTODEBITCARDREQUEST(null);
//		 * iotype.setAUTODEPBAL(null); iotype.setCHECKER(null);
//		 * iotype.setCHECKERSTAMP(null); iotype.setCHQBOOK(null);
//		 * iotype.setCLRBNKCD(null);
//		 * 
//		 * iotype.setCRLMREVDT(null); iotype.setCRLMSTDT(null);
//		 * iotype.setCRSSTSTREQD(null); iotype.setCRTXNLMT(null);
//		 * iotype.setCustAcc(null); iotype.setCustAccCard(null);
//		 * iotype.setCustAccCheck(null); iotype.setCustaccIcccspcn(null);
//		 * iotype.setCustaccIcchspcn(null); iotype.setCustaccIccinstr(null);
//		 * iotype.setCustaccIccintpo(null); iotype.setCustaccSicdiary(null);
//		 * iotype.setCustaccStccusbl(null); iotype.setCUSTNAME(null);
//		 * iotype.setCUSTNO(null); iotype.setCustomerAcc(null);
//		 * iotype.setCustomerAcc1(null); iotype.setDAYLIGHTLIMIT(null);
//		 * iotype.setDFLTWAIVER(null); iotype.setDoctypeRemarks(null);
//		 * iotype.setESCROWACCOUNT(null); iotype.setESCROWBRNCODE(null);
//		 * iotype.setESCROWPERCENTAGE(null); iotype.setESCROWTRN(null);
//		 * iotype.setExtsysWsMaster(null); iotype.setFLGEXCLRVRTRANS(null);
//		 * iotype.setGENSTMTMV(null); iotype.setGENSTMTMV2(null);
//		 * iotype.setGENSTMTMV3(null); iotype.setIBANACC(null);
//		 * iotype.setIBANBNKCD(null); iotype.setIntdetails(null);
//		 * iotype.setInterimDetails(null); iotype.setINTERMEDIARYREQUIRED(null);
//		 * iotype.setJointholdersMain(null); iotype.setLinkedentities(null);
//		 * iotype.setLMTCCY(null); iotype.setLOC(null); iotype.setMaster(null);
//		 * iotype.setMAKER(null); iotype.setMAKERSTAMP(null); iotype.setMASTERACC(null);
//		 * iotype.setMEDIA(null); iotype.setMINREQBAL(null); iotype.setMODNO(null);
//		 * iotype.setMT110RECONREQD(null); iotype.setNETREQ(null); iotype.setNOM1(null);
//		 * iotype.setNOM2(null); iotype.setNoticepref(null); iotype.setNSFBLKSTAT(null);
//		 * iotype.setOFFLINELIM(null); iotype.setOPMODE(null);
//		 * iotype.setPASSBOOKNUMBER(null); iotype.setPASSBOOKSTATUS(null);
//		 * iotype.setPAYINOPTION(null); iotype.setPRDLST(null); iotype.setPrdtxn(null);
//		 * iotype.setPREVSTMTBAL(null); iotype.setPREVSTMTBAL2(null);
//		 * iotype.setPREVSTMTBAL3(null); iotype.setPREVSTMTDT(null);
//		 * iotype.setPREVSTMTDT2(null); iotype.setPREVSTMTDT3(null);
//		 * iotype.setPREVSTMTNO(null); iotype.setPREVSTMTNO2(null);
//		 * iotype.setPREVSTMTNO3(null); iotype.setPRIVATECUSTOMER(null);
//		 * iotype.setPROJACC(null); iotype.setProvisionMain(null);
//		 * iotype.setREGCCAVL(null); iotype.setREGDAPP(null); iotype.setREGDENDT(null);
//		 * iotype.setREGDPER(null); iotype.setREGDSTDT(null);
//		 * iotype.setREPLCUSTSIG(null); iotype.setSDREFNO(null);
//		 * iotype.setSODNOTP(null); iotype.setSPCONDLST(null);
//		 * iotype.setSPCONDTXN(null); iotype.setStatement(null); iotype.setSTMTAC(null);
//		 * iotype.setSttmsCustAccount(null); iotype.setSttmsDebit(null);
//		 * iotype.setSUBLIMIT(null); iotype.setSWEEPIN(null); iotype.setSWEEPOUT(null);
//		 * iotype.setSWPTYPE(null); iotype.setCCY(null); iotype.setTddetails(null);
//		 * iotype.setTddetails(null); iotype.setATMCUSTACNO(null); iotype.setATM(null);
//		 * iotype.setATMBRN(null); iotype.setATMDCNTLIM(null); iotype.setATMDLIM(null);
//		 * iotype.setTODLIMENDT(null); iotype.setTODLIMIT(null);
//		 * iotype.setTODLIMSTDT(null); iotype.setTodRenew(null); iotype.setTRKREC(null);
//		 * iotype.setTXNLST(null); iotype.setTXNSTAT(null);
//		 * iotype.setUNCOLFUNDLIMIT(null);
//		 */
//
//		body.setCustAccountFull(iotype);
//
//		req.setFCUBSHEADER(createHeaderAccService());
//		req.setFCUBSBODY(body);
//
//		return req;
//	}
////ModifyCustAccIO
//
//	public MODIFYCUSTACCIOPKREQ modifyCustAccIO(CashDepositWithdrawalModel cashDepositWithdrawal,
//			IcCountryModel icCountryModel) {
//		MODIFYCUSTACCIOPKREQ req = new MODIFYCUSTACCIOPKREQ();
//		MODIFYCUSTACCIOPKREQ.FCUBSBODY body = new MODIFYCUSTACCIOPKREQ.FCUBSBODY();
//		CustAccModifyIOType iotype = new CustAccModifyIOType();
//		// CashDepositWithdrawalModel cashDepositWithdrawal=(CashDepositWithdrawalModel)
//		// cashDepositService.fetchByTransId(transactionId).getBody();
//
//		// IcCountryModel icCountryModel = new IcCountryModel();
//		CustomerInfoModel customerInfoModel = new CustomerInfoModel();
//		iotype.setACCTYPE(cashDepositWithdrawal.getAccountType());
//		iotype.setBRN(cashDepositWithdrawal.getAccountBranch());
//		iotype.setCOUNTRYCODE(icCountryModel.getCountryCode());
//		/*
//		 * iotype.setACC(null); iotype.setAccclose(null); iotype.setACCTYP(null);
//		 * iotype.setAccmaintinstr(null); iotype.setAccSvcacsig(null);
//		 * 
//		 * iotype.setACSTMTCYCLE(null); iotype.setACSTMTCYCLE2(null);
//		 * iotype.setACSTMTCYCLE3(null); iotype.setACSTMTCYCLE3(null);
//		 * iotype.setACSTMTDAY(null); iotype.setACSTMTDAY2(null);
//		 * iotype.setACSTMTDAY3(null); iotype.setACSTMTTYPE3(null);
//		 * iotype.setACSTMTTYPEP(null); iotype.setACSTMTTYPS(null);
//		 * iotype.setADDR1(null); iotype.setADDR2(null); iotype.setADDR3(null);
//		 * iotype.setADESC(null); iotype.setALTACC(null); iotype.setAUTOPROVREQ(null);
//		 * iotype.setAUTODEPBAL(null);
//		 * 
//		 * iotype.setCHQBOOK(null); iotype.setCLRBNKCD(null);
//		 * 
//		 * iotype.setCRLMREVDT(null); iotype.setCRLMSTDT(null);
//		 * iotype.setCRSSTSTREQD(null); iotype.setCRTXNLMT(null);
//		 * iotype.setCustAcc(null); iotype.setCustAccCard(null);
//		 * iotype.setCustAccCheck(null); iotype.setCustaccIcccspcn(null);
//		 * iotype.setCustaccIcchspcn(null); iotype.setCustaccIccinstr(null);
//		 * iotype.setCustaccIccintpo(null); iotype.setCustaccSicdiary(null);
//		 * iotype.setCustaccStccusbl(null); iotype.setCustAcc(null);
//		 * iotype.setCUSTNO(null); iotype.setCustomerAcc(null);
//		 * iotype.setCustomerAcc1(null); iotype.setDAYLIGHTLIMIT(null);
//		 * iotype.setDoctypeRemarks(null); iotype.setESCROWACCOUNT(null);
//		 * iotype.setESCROWBRNCODE(null); iotype.setESCROWPERCENTAGE(null);
//		 * iotype.setESCROWTRN(null); iotype.setExtsysWsMaster(null);
//		 * iotype.setFLGEXCLRVRTRANS(null); iotype.setGENSTMTMV(null);
//		 * iotype.setGENSTMTMV2(null); iotype.setGENSTMTMV3(null);
//		 * iotype.setIBANACC(null); iotype.setIBANBNKCD(null);
//		 * iotype.setIntdetails(null); iotype.setInterimDetails(null);
//		 * iotype.setINTERMEDIARYREQUIRED(null); iotype.setLinkedentities(null);
//		 * iotype.setLMTCCY(null); iotype.setLOC(null); iotype.setMaster(null);
//		 * iotype.setMAKER(null); iotype.setMAKERSTAMP(null); iotype.setMASTERACC(null);
//		 * iotype.setMEDIA(null); iotype.setMINREQBAL(null); iotype.setCLRACNO(null);
//		 * iotype.setMT110RECONREQD(null); iotype.setNETREQ(null); iotype.setNOM1(null);
//		 * iotype.setNOM2(null); iotype.setOFFLINELIM(null); iotype.setPASSBOOK(null);
//		 * iotype.setPAYINOPTION(null); iotype.setPRDLST(null);
//		 * iotype.setSPCONDTXN(null); iotype.setPREVSTMTBAL(null);
//		 * iotype.setPREVSTMTBAL2(null); iotype.setPREVSTMTBAL3(null);
//		 * iotype.setPREVSTMTDT(null); iotype.setPREVSTMTDT2(null);
//		 * iotype.setPREVSTMTDT3(null); iotype.setPREVSTMTNO(null);
//		 * iotype.setPREVSTMTNO2(null); iotype.setPREVSTMTNO3(null);
//		 * iotype.setREGCCAVL(null); iotype.setREGDAPP(null); iotype.setREGDENDT(null);
//		 * iotype.setREGDPER(null); iotype.setREGDSTDT(null);
//		 * iotype.setREPLCUSTSIG(null); iotype.setSODNOTP(null);
//		 * iotype.setSPCONDLST(null); iotype.setSPCONDTXN(null); iotype.setSTMTAC(null);
//		 * iotype.setSttmsCustAccount(null); iotype.setSttmsDebit(null);
//		 * iotype.setSUBLIMIT(null); iotype.setSWEEPIN(null); iotype.setSWEEPOUT(null);
//		 * iotype.setSWPTYPE(null); iotype.setTddetails(null);
//		 * iotype.setTddetails(null); iotype.setATMCUSTACNO(null); iotype.setATM(null);
//		 * iotype.setATMBRN(null); iotype.setATMDCNTLIM(null); iotype.setATMDLIM(null);
//		 * iotype.setTODLIMENDT(null); iotype.setTODLIMIT(null);
//		 * iotype.setTODLIMSTDT(null); iotype.setTodRenew(null); iotype.setTRKREC(null);
//		 * iotype.setTXNLST(null); iotype.setUNCOLFUNDLIMIT(null);
//		 */
//
//		body.setCustAccountIO(iotype);
//
//		req.setFCUBSHEADER(createHeaderAccService());
//		req.setFCUBSBODY(body);
//
//		return req;
//	}
////ModifyStopPaymentsFS
//
//	public MODIFYSTOPPAYMENTSFSFSREQ modifyStopPaymentsFS(CashDepositWithdrawalModel cashDepositWithdrawal,
//			AccountInfoModel accountInfoModel) throws RecordNotFoundException {
//		MODIFYSTOPPAYMENTSFSFSREQ req = new MODIFYSTOPPAYMENTSFSFSREQ();
//		MODIFYSTOPPAYMENTSFSFSREQ.FCUBSBODY body = new MODIFYSTOPPAYMENTSFSFSREQ.FCUBSBODY();
//		StopPaymentsFullType iotype = new StopPaymentsFullType();
//		// CashDepositWithdrawalModel cashDepositWithdrawal=(CashDepositWithdrawalModel)
//		// cashDepositService.fetchByTransId(transactionId).getBody();
//		// AccountInfoModel accountInfoModel = (AccountInfoModel)
//		// icustAccountServiceImpl.getAccountObj(accountId).getBody();
//
//		iotype.setACCNUMBER(cashDepositWithdrawal.getAccountNumber().toString());
//		iotype.setAUTHSTAT(cashDepositWithdrawal.getAuthStatus());
//		iotype.setMODNO(BigDecimal.valueOf(accountInfoModel.getModificationNo()));
//		/*
//		 * iotype.setTXNSTAT(cashDepositWithdrawal.getTransactionStatus().toString());
//		 * iotype.setAPPLYCHARGE(null); iotype.setCHECKER(null);
//		 * iotype.setChargeMain(null); iotype.setCHECKER(null);
//		 * iotype.setCHECKERSTAMP(null); iotype.setEFFECTIVEDATE(null);
//		 * iotype.setEventMaster(null); iotype.setMAKER(null);
//		 * iotype.setMAKERSTAMP(null); iotype.setMODNO(null);
//		 * iotype.setAPPLYCHARGE(null); iotype.setADVFTREQDFLG(null);
//		 * iotype.setCONFIRMED(null); iotype.setENDCHECKNO(null);
//		 * iotype.setSTARTCHECKNO(null); iotype.setEXPIRYDATE(null);
//		 * iotype.setSTOPPAYMENTNO(null); iotype.setSTOPPAYMENTTYPE(null);
//		 */
//
//		body.setCatmsStopPaymentsFull(iotype);
//
//		req.setFCUBSHEADER(createHeaderAccService());
//		req.setFCUBSBODY(body);
//
//		return req;
//	}
////ModifyStopPaymentsIO
//
//	public MODIFYSTOPPAYMENTSIOPKREQ modifyStopPaymentsIO(CashDepositWithdrawalModel cashDepositWithdrawal) {
//		MODIFYSTOPPAYMENTSIOPKREQ req = new MODIFYSTOPPAYMENTSIOPKREQ();
//		MODIFYSTOPPAYMENTSIOPKREQ.FCUBSBODY body = new MODIFYSTOPPAYMENTSIOPKREQ.FCUBSBODY();
//		StopPaymentsModifyIOType iotype = new StopPaymentsModifyIOType();
//		// CashDepositWithdrawalModel cashDepositWithdrawal=(CashDepositWithdrawalModel)
//		// cashDepositService.fetchByTransId(transactionId).getBody();
//
//		/*
//		 * iotype.setChargeMain(null); iotype.setEventMaster(null);
//		 * iotype.setMAKER(null); iotype.setMAKERSTAMP(null);
//		 * iotype.setSTOPPAYMENTNO(null);
//		 */
//
//		body.setCatmsStopPaymentsIO(iotype);
//
//		req.setFCUBSHEADER(createHeaderAccService());
//		req.setFCUBSBODY(body);
//
//		return req;
//	}
////ModifyTDCustAccFS
//
//	public MODIFYTDCUSTACCFSFSREQ modifyTDCustAccFS(CashDepositWithdrawalModel cashDepositWithdrawal,
//			IcCountryModel icCountryModel) throws RecordNotFoundException {
//		MODIFYTDCUSTACCFSFSREQ req = new MODIFYTDCUSTACCFSFSREQ();
//		MODIFYTDCUSTACCFSFSREQ.FCUBSBODY body = new MODIFYTDCUSTACCFSFSREQ.FCUBSBODY();
//		TDCustAccFullType iotype = new TDCustAccFullType();
//		// CashDepositWithdrawalModel cashDepositWithdrawal=(CashDepositWithdrawalModel)
//		// cashDepositService.fetchByTransId(transactionId).getBody();
//		// AccountInfoModel accountInfoModel = (AccountInfoModel)
//		// icustAccountServiceImpl.getAccountObj(accountId).getBody();
//
//		// IcCountryModel icCountryModel = new IcCountryModel();
//		// CustomerInfoModel customerInfoModel=new CustomerInfoModel();
//		iotype.setACCTYPE(cashDepositWithdrawal.getAccountType());
//		iotype.setAUTHSTAT(cashDepositWithdrawal.getAuthStatus());
//		iotype.setBRN(cashDepositWithdrawal.getAccountBranch());
//		iotype.setCOUNTRY(icCountryModel.getCountryName());
//		iotype.setCOUNTRYCODE(icCountryModel.getCountryCode());
//		/*
//		 * iotype.setAccclose(null); iotype.setAcccrdrlmtsMain(null);
//		 * iotype.setACCLS(null); iotype.setAccmaintinstr(null);
//		 * iotype.setACCOPENDT(null); iotype.setACCOUNTAUTOCLOSED(null);
//		 * iotype.setAccstatusMain(null); iotype.setAccSvcacsig(null);
//		 * 
//		 * iotype.setACSTMTCYCLE(null); iotype.setACSTMTCYCLE2(null);
//		 * iotype.setACSTMTCYCLE3(null); iotype.setACSTMTCYCLE3(null);
//		 * iotype.setACSTMTDAY(null); iotype.setACSTMTDAY2(null);
//		 * iotype.setACSTMTDAY3(null); iotype.setACSTMTTYPE3(null);
//		 * iotype.setACSTMTTYPEP(null); iotype.setACSTMTTYPS(null);
//		 * iotype.setADDR1(null); iotype.setADDR2(null); iotype.setADDR3(null);
//		 * iotype.setADESC(null); iotype.setALTACC(null); iotype.setAmountDates(null);
//		 * iotype.setAuthbicdetailsMain(null);
//		 * 
//		 * iotype.setAUTOCHEQUEBOOKREQ(null); iotype.setAUTODEBITCARDREQUEST(null);
//		 * iotype.setAUTODEPBAL(null);
//		 * 
//		 * iotype.setCHECKER(null); iotype.setCHECKERSTAMP(null);
//		 * iotype.setCLRBNKCD(null);
//		 * 
//		 * iotype.setCRLMREVDT(null); iotype.setCRLMSTDT(null);
//		 * iotype.setCRSSTSTREQD(null); iotype.setCRTXNLMT(null);
//		 * iotype.setCustAcc(null); iotype.setCustAccCard(null);
//		 * iotype.setCustAccCheck(null); iotype.setCustaccIcccspcn(null);
//		 * iotype.setCustaccIcchspcn(null); iotype.setCustaccIccinstr(null);
//		 * iotype.setCustaccIccintpo(null); iotype.setCustaccSicdiary(null);
//		 * iotype.setCustaccStccusbl(null); iotype.setCUSTNAME(null);
//		 * iotype.setCUSTNO(null); iotype.setCustomerAcc(null);
//		 * iotype.setCustomerAcc1(null); iotype.setDAYLIGHTLIMIT(null);
//		 * iotype.setDFLTWAIVER(null); iotype.setDoctypeRemarks(null);
//		 * iotype.setESCROWACCOUNT(null); iotype.setESCROWBRNCODE(null);
//		 * iotype.setESCROWPERCENTAGE(null); iotype.setESCROWTRN(null);
//		 * iotype.setExtsysWsMaster(null); iotype.setFLGEXCLRVRTRANS(null);
//		 * iotype.setGENSTMTMV(null); iotype.setGENSTMTMV2(null);
//		 * iotype.setGENSTMTMV3(null); iotype.setIBANACC(null);
//		 * iotype.setIBANBNKCD(null); iotype.setIntdetails(null);
//		 * iotype.setInterimDetails(null); iotype.setINTERMEDIARYREQUIRED(null);
//		 * iotype.setJointholdersMain(null); iotype.setLinkedentities(null);
//		 * iotype.setLMTCCY(null); iotype.setLOC(null); iotype.setMaster(null);
//		 * iotype.setMAKER(null); iotype.setMAKERSTAMP(null); iotype.setMASTERACC(null);
//		 * iotype.setMEDIA(null); iotype.setMODNO(null); iotype.setMT110RECONREQD(null);
//		 * iotype.setNETREQ(null); iotype.setNOM1(null); iotype.setNOM2(null);
//		 * iotype.setNoticepref(null); iotype.setNSFBLKSTAT(null);
//		 * iotype.setOFFLINELIM(null); iotype.setOPMODE(null);
//		 * iotype.setPASSBOOKNUMBER(null); iotype.setPASSBOOKSTATUS(null);
//		 * iotype.setPRDLST(null); iotype.setPrdtxn(null); iotype.setPREVSTMTBAL(null);
//		 * iotype.setPREVSTMTBAL2(null); iotype.setPREVSTMTBAL3(null);
//		 * iotype.setPREVSTMTDT(null); iotype.setPREVSTMTDT2(null);
//		 * iotype.setPREVSTMTDT3(null); iotype.setPREVSTMTNO(null);
//		 * iotype.setPREVSTMTNO2(null); iotype.setPREVSTMTNO3(null);
//		 * iotype.setPRIVATECUSTOMER(null); iotype.setPROJACC(null);
//		 * iotype.setProvisionMain(null); iotype.setREGCCAVL(null);
//		 * iotype.setREGDAPP(null); iotype.setREGDENDT(null); iotype.setREGDPER(null);
//		 * iotype.setREGDSTDT(null); iotype.setREPLCUSTSIG(null);
//		 * iotype.setSDREFNO(null); iotype.setSODNOTP(null); iotype.setSPCONDLST(null);
//		 * iotype.setSPCONDTXN(null); iotype.setStatement(null); iotype.setSTMTAC(null);
//		 * iotype.setSttmsCustAccount(null); iotype.setSttmsDebit(null);
//		 * iotype.setSUBLIMIT(null); iotype.setSWEEPIN(null); iotype.setSWEEPOUT(null);
//		 * iotype.setSWPTYPE(null); iotype.setTddetails(null);
//		 * iotype.setTddetails(null); iotype.setTODLIMENDT(null);
//		 * iotype.setTODLIMIT(null); iotype.setTODLIMSTDT(null);
//		 * iotype.setTodRenew(null); iotype.setTRKREC(null); iotype.setTXNLST(null);
//		 * iotype.setTXNSTAT(null); iotype.setUNCOLFUNDLIMIT(null);
//		 */
//
//		body.setCustAccountFull(iotype);
//
//		req.setFCUBSHEADER(createHeaderAccService());
//		req.setFCUBSBODY(body);
//
//		return req;
//	}
////ModifyTDCustAccIO
//
//	public MODIFYTDCUSTACCIOPKREQ modifyTDCustAccIO(CashDepositWithdrawalModel cashDepositWithdrawal,
//			IcCountryModel icCountryModel) {
//		MODIFYTDCUSTACCIOPKREQ req = new MODIFYTDCUSTACCIOPKREQ();
//		MODIFYTDCUSTACCIOPKREQ.FCUBSBODY body = new MODIFYTDCUSTACCIOPKREQ.FCUBSBODY();
//		TDCustAccModifyIOType iotype = new TDCustAccModifyIOType();
//		// CashDepositWithdrawalModel cashDepositWithdrawal=(CashDepositWithdrawalModel)
//		// cashDepositService.fetchByTransId(transactionId).getBody();
//
//		// IcCountryModel icCountryModel = new IcCountryModel();
//		// CustomerInfoModel customerInfoModel=new CustomerInfoModel();
//		iotype.setCOUNTRY(icCountryModel.getCountryName());
//		iotype.setCOUNTRYCODE(icCountryModel.getCountryCode());
//		iotype.setBRN(cashDepositWithdrawal.getAccountBranch());
//		iotype.setACCTYPE(cashDepositWithdrawal.getAccountType());
//		/*
//		 * iotype.setAccclose(null); iotype.setAccmaintinstr(null);
//		 * iotype.setACCOPENINGAMT(null); iotype.setAccSvcacsig(null);
//		 * iotype.setACSTMTCYCLE(null); iotype.setACSTMTCYCLE2(null);
//		 * iotype.setACSTMTCYCLE3(null); iotype.setACSTMTCYCLE3(null);
//		 * iotype.setACSTMTDAY(null); iotype.setACSTMTDAY2(null);
//		 * iotype.setACSTMTDAY3(null); iotype.setACSTMTTYPE3(null);
//		 * iotype.setACSTMTTYPEP(null); iotype.setACSTMTTYPS(null);
//		 * iotype.setADDR1(null); iotype.setADDR2(null); iotype.setADDR3(null);
//		 * iotype.setADESC(null); iotype.setALTACC(null); iotype.setAUTODEPBAL(null);
//		 * iotype.setCHQBOOK(null); iotype.setCLRBNKCD(null); iotype.setCRLMREVDT(null);
//		 * iotype.setCRLMSTDT(null); iotype.setCRSSTSTREQD(null);
//		 * iotype.setCRTXNLMT(null); iotype.setCustAcc(null);
//		 * iotype.setCustAccCard(null); iotype.setCustAccCheck(null);
//		 * iotype.setCustaccIcccspcn(null); iotype.setCustaccIcchspcn(null);
//		 * iotype.setCustaccIccinstr(null); iotype.setCustaccIccintpo(null);
//		 * iotype.setCustaccSicdiary(null); iotype.setCustaccStccusbl(null);
//		 * iotype.setCUSTNO(null); iotype.setCustomerAcc(null);
//		 * iotype.setCustomerAcc1(null); iotype.setDAYLIGHTLIMIT(null);
//		 * iotype.setDoctypeRemarks(null); iotype.setESCROWACCOUNT(null);
//		 * iotype.setESCROWBRNCODE(null); iotype.setESCROWPERCENTAGE(null);
//		 * iotype.setESCROWTRN(null); iotype.setExtsysWsMaster(null);
//		 * iotype.setFLGEXCLRVRTRANS(null); iotype.setGENSTMTMV(null);
//		 * iotype.setGENSTMTMV2(null); iotype.setGENSTMTMV3(null);
//		 * iotype.setIBANACC(null); iotype.setIBANBNKCD(null);
//		 * iotype.setIntdetails(null); iotype.setInterimDetails(null);
//		 * iotype.setINTERMEDIARYREQUIRED(null); iotype.setLinkedentities(null);
//		 * iotype.setLMTCCY(null); iotype.setLOC(null); iotype.setMaster(null);
//		 * iotype.setMAKER(null); iotype.setMAKERSTAMP(null); iotype.setMASTERACC(null);
//		 * iotype.setMEDIA(null); iotype.setMINREQBL(null); iotype.setMOD9RQD(null);
//		 * iotype.setMT110RECONREQD(null); iotype.setNETREQ(null); iotype.setNOM1(null);
//		 * iotype.setNOM2(null); iotype.setOFFLINELIM(null); iotype.setPASSBOOK(null);
//		 * iotype.setPAYINOPTION(null); iotype.setPRDLST(null);
//		 * iotype.setPREVSTMTBAL(null); iotype.setPREVSTMTBAL2(null);
//		 * iotype.setPREVSTMTBAL3(null); iotype.setPREVSTMTDT(null);
//		 * iotype.setPREVSTMTDT2(null); iotype.setPREVSTMTDT3(null);
//		 * iotype.setPREVSTMTNO(null); iotype.setPREVSTMTNO2(null);
//		 * iotype.setPREVSTMTNO3(null); iotype.setREGCCAVL(null);
//		 * iotype.setREGDAPP(null); iotype.setREGDENDT(null); iotype.setREGDPER(null);
//		 * iotype.setREGDSTDT(null); iotype.setREPLCUSTSIG(null);
//		 * iotype.setSODNOTP(null); iotype.setSPCONDLST(null);
//		 * iotype.setSPCONDTXN(null); iotype.setSTMTAC(null);
//		 * iotype.setSttmsCustAccount(null); iotype.setSttmsDebit(null);
//		 * iotype.setSUBLIMIT(null); iotype.setSWEEPIN(null); iotype.setSWEEPOUT(null);
//		 * iotype.setSWPTYPE(null); iotype.setTddetails(null);
//		 * iotype.setTddetails(null); iotype.setATM(null); iotype.setATMBRN(null);
//		 * iotype.setATMDCNTLIM(null); iotype.setATMDLIM(null);
//		 * iotype.setTODLIMENDT(null); iotype.setTODLIMIT(null);
//		 * iotype.setTODLIMSTDT(null); iotype.setTodRenew(null); iotype.setTRKREC(null);
//		 * iotype.setTXNLST(null); iotype.setUNCOLFUNDLIMIT(null);
//		 */
//
//		body.setCustAccountIO(null);
//
//		req.setFCUBSHEADER(createHeaderAccService());
//		req.setFCUBSBODY(body);
//
//		return req;
//	}
//
////QueryAccBalIO
//
//
//	public QUERYACCBALIOFSREQ queryAccBalIO(IcustAccount icustAccount) {
//		
//		com.ws.api.accservice.FCUBSHEADERType header= createHeaderAccService();
//		header.setOPERATION("QueryAccount");
//		header.setSOURCEOPERATION("QueryAccount");
//		//header.setFUNCTIONID("STDCIF");
//		header.setMODULEID("ST");
//		
//	//	header.setACTION("NEW");
//		
//		QUERYACCBALIOFSREQ req = new QUERYACCBALIOFSREQ();
//		QUERYACCBALIOFSREQ.FCUBSBODY body = new QUERYACCBALIOFSREQ.FCUBSBODY();
//		AccBalReqType iotype = new AccBalReqType();
//		
//		ACCBAL accbal = new ACCBAL();
//		accbal.setBRANCHCODE(icustAccount.getAccountBranch());
//		accbal.setCUSTACNO(icustAccount.getAccountId().toString());
//		
//		iotype.setACCBAL(accbal);
//		body.setACCBalance(iotype);
//
//		req.setFCUBSHEADER(createHeaderAccService());
//		req.setFCUBSBODY(body);
//		  ResponseEntity<?> res=  accServiceImpl.queryAccBalIO(req);
//		  com.ws.api.accservice.QUERYACCBALIOFSRES.FCUBSBODY res1=(QUERYACCBALIOFSRES.FCUBSBODY) res.getBody();
//		  System.out.println(res1.getACCBalance().getACCBAL());
//		return req;
//	}
////QueryAcClassTfrIO
//
//	public QUERYACCLASSTFRIOFSREQ queryAcClassTfrIO(CashDepositWithdrawalModel cashDepositWithdrawal) {
//		QUERYACCLASSTFRIOFSREQ req = new QUERYACCLASSTFRIOFSREQ();
//		QUERYACCLASSTFRIOFSREQ.FCUBSBODY body = new QUERYACCLASSTFRIOFSREQ.FCUBSBODY();
//		CustAccTfrQueryIOType iotype = new CustAccTfrQueryIOType();
//		// CashDepositWithdrawalModel cashDepositWithdrawal=(CashDepositWithdrawalModel)
//		// cashDepositService.fetchByTransId(transactionId).getBody();
//		iotype.setACC(cashDepositWithdrawal.getAccountNumber().toString());
////	iotype.setACCLS(null);
//		iotype.setBRN(cashDepositWithdrawal.getAccountBranch());
//		body.setMainIO(iotype);
//
//		req.setFCUBSHEADER(createHeaderAccService());
//		req.setFCUBSBODY(body);
//
//		return req;
//	}
////QueryAccSummIO
//
//	public QUERYACCSUMMIOFSREQ queryAccSummIO(CashDepositWithdrawalModel cashDepositWithdrawal) {
//		QUERYACCSUMMIOFSREQ req = new QUERYACCSUMMIOFSREQ();
//		QUERYACCSUMMIOFSREQ.FCUBSBODY body = new QUERYACCSUMMIOFSREQ.FCUBSBODY();
//		QueryAccSummQueryIOType iotype = new QueryAccSummQueryIOType();
//		// CashDepositWithdrawalModel cashDepositWithdrawal=(CashDepositWithdrawalModel)
//		// cashDepositService.fetchByTransId(transactionId).getBody();
////	iotype.setCUSTNO(null);
//		body.setStvwAccountSumaryIO(iotype);
//
//		req.setFCUBSHEADER(createHeaderAccService());
//		req.setFCUBSBODY(body);
//
//		return req;
//	}
////QueryCheckBookIO
//
//	public QUERYCHECKBOOKIOFSREQ queryCheckBookIO(CashDepositWithdrawalModel cashDepositWithdrawal) {
//		QUERYCHECKBOOKIOFSREQ req = new QUERYCHECKBOOKIOFSREQ();
//		QUERYCHECKBOOKIOFSREQ.FCUBSBODY body = new QUERYCHECKBOOKIOFSREQ.FCUBSBODY();
//		CheckBookQueryIOType iotype = new CheckBookQueryIOType();
//		// CashDepositWithdrawalModel cashDepositWithdrawal=(CashDepositWithdrawalModel)
//		// cashDepositService.fetchByTransId(transactionId).getBody();
//		iotype.setACCOUNT(cashDepositWithdrawal.getAccountType());
//
//		body.setChqBkDetailsIO(iotype);
//
//		req.setFCUBSHEADER(createHeaderAccService());
//		req.setFCUBSBODY(body);
//
//		return req;
//	}
////QueryCustAccIO
//
//	public QUERYCUSTACCIOFSREQ queryCustAccIO(CashDepositWithdrawalModel cashDepositWithdrawal) {
//		QUERYCUSTACCIOFSREQ req = new QUERYCUSTACCIOFSREQ();
//		QUERYCUSTACCIOFSREQ.FCUBSBODY body = new QUERYCUSTACCIOFSREQ.FCUBSBODY();
//		CustAccQueryIOType iotype = new CustAccQueryIOType();
//		// CashDepositWithdrawalModel cashDepositWithdrawal=(CashDepositWithdrawalModel)
//		// cashDepositService.fetchByTransId(transactionId).getBody();
//		iotype.setACC(cashDepositWithdrawal.getAccountNumber().toString());
//		iotype.setBRN(cashDepositWithdrawal.getAccountBranch());
//		// iotype.setCRSSTSTREQD(null);
//		body.setCustAccountIO(iotype);
//
//		req.setFCUBSHEADER(createHeaderAccService());
//		req.setFCUBSBODY(body);
//
//		return req;
//	}
//
////QueryGenAdviceIO
//
//	public QUERYGENADVICEIOFSREQ queryGenAdviceIO(CashDepositWithdrawalModel cashDepositWithdrawal) {
//		QUERYGENADVICEIOFSREQ req = new QUERYGENADVICEIOFSREQ();
//		QUERYGENADVICEIOFSREQ.FCUBSBODY body = new QUERYGENADVICEIOFSREQ.FCUBSBODY();
//		StdgnadvPKType iotype = new StdgnadvPKType();
//		// CashDepositWithdrawalModel cashDepositWithdrawal=(CashDepositWithdrawalModel)
//		// cashDepositService.fetchByTransId(transactionId).getBody();
////	iotype.setDCN(null);
//		body.setCUSTACCOUNTDLYMSGOUTIO(iotype);
//		req.setFCUBSHEADER(createHeaderAccService());
//		req.setFCUBSBODY(body);
//
//		return req;
//	}
////QueryStopPaymentsIO
//
//	public QUERYSTOPPAYMENTSIOFSREQ queryStopPaymentsIO(CashDepositWithdrawalModel cashDepositWithdrawal) {
//		QUERYSTOPPAYMENTSIOFSREQ req = new QUERYSTOPPAYMENTSIOFSREQ();
//		QUERYSTOPPAYMENTSIOFSREQ.FCUBSBODY body = new QUERYSTOPPAYMENTSIOFSREQ.FCUBSBODY();
//		StopPaymentsQueryIOType iotype = new StopPaymentsQueryIOType();
//		// CashDepositWithdrawalModel cashDepositWithdrawal=(CashDepositWithdrawalModel)
//		// cashDepositService.fetchByTransId(transactionId).getBody();
//		// iotype.setSTOPPAYMENTNO(null);
//		body.setCatmsStopPaymentsIO(iotype);
//
//		req.setFCUBSHEADER(createHeaderAccService());
//		req.setFCUBSBODY(body);
//
//		return req;
//	}
////QueryTDCustAccIO
//
//	public QUERYTDCUSTACCIOFSREQ queryTDCustAccIO(CashDepositWithdrawalModel cashDepositWithdrawal) {
//		QUERYTDCUSTACCIOFSREQ req = new QUERYTDCUSTACCIOFSREQ();
//		QUERYTDCUSTACCIOFSREQ.FCUBSBODY body = new QUERYTDCUSTACCIOFSREQ.FCUBSBODY();
//		TDCustAccQueryIOType iotype = new TDCustAccQueryIOType();
//		// CashDepositWithdrawalModel cashDepositWithdrawal=(CashDepositWithdrawalModel)
//		// cashDepositService.fetchByTransId(transactionId).getBody();
//		iotype.setBRN(cashDepositWithdrawal.getAccountBranch());
//		// iotype.setCRSSTSTREQD(null);
//		// iotype.setTERMACNO(null);
//		body.setCustAccountIO(iotype);
//
//		req.setFCUBSHEADER(createHeaderAccService());
//		req.setFCUBSBODY(body);
//
//		return req;
//	}
////ReopenCheckBookFS
//
//	public REOPENCHECKBOOKFSFSREQ reopenCheckBookFS(CashDepositWithdrawalModel cashDepositWithdrawal) {
//		REOPENCHECKBOOKFSFSREQ req = new REOPENCHECKBOOKFSFSREQ();
//		REOPENCHECKBOOKFSFSREQ.FCUBSBODY body = new REOPENCHECKBOOKFSFSREQ.FCUBSBODY();
//		CheckBookFullType iotype = new CheckBookFullType();
//		// CashDepositWithdrawalModel cashDepositWithdrawal=(CashDepositWithdrawalModel)
//		// cashDepositService.fetchByTransId(transactionId).getBody();
//		iotype.setACCOUNT(cashDepositWithdrawal.getAccountNumber().toString());
//		iotype.setCHBKTYPE(cashDepositWithdrawal.getAccountType());
//		iotype.setAUTHSTAT(cashDepositWithdrawal.getAuthStatus());
//		/*
//		 * iotype.setTXNSTAT(cashDepositWithdrawal.getTransactionStatus().toString());
//		 * iotype.setCHECKERSTAMP(null); iotype.setCHECKER(null);
//		 * iotype.setAPPLYCHARGE(null); iotype.setChargeMain(null);
//		 * iotype.setCHECKLEAVES(null); iotype.setDELIVERYADD1(null);
//		 * iotype.setDELIVERYADD2(null); iotype.setDELIVERYADD3(null);
//		 * iotype.setDELIVERYADD4(null); iotype.setDELIVERYMODE(null);
//		 * iotype.setEventMaster(null); iotype.setISSUEDATE(null);
//		 * iotype.setLANGCODE(null); iotype.setMAKER(null); iotype.setMAKERSTAMP(null);
//		 * iotype.setMODNO(null); iotype.setORDERDATE(null);
//		 * iotype.setORDERDETAILS(null); iotype.setREQUESTMODE(null);
//		 * iotype.setREQUESTSTATUS(null); iotype.setINCLFORCHKBOOKPRINTING(null);
//		 */
//
//		body.setChqBkDetailsFull(iotype);
//
//		req.setFCUBSHEADER(createHeaderAccService());
//		req.setFCUBSBODY(body);
//
//		return req;
//
//	}
////ReopenCheckBookIO
//
//	public REOPENCHECKBOOKIOPKREQ reopenCheckBookIO(CashDepositWithdrawalModel cashDepositWithdrawal) {
//		REOPENCHECKBOOKIOPKREQ req = new REOPENCHECKBOOKIOPKREQ();
//		REOPENCHECKBOOKIOPKREQ.FCUBSBODY body = new REOPENCHECKBOOKIOPKREQ.FCUBSBODY();
//		CheckBookReopenIOType iotype = new CheckBookReopenIOType();
//		// CashDepositWithdrawalModel cashDepositWithdrawal=(CashDepositWithdrawalModel)
//		// cashDepositService.fetchByTransId(transactionId).getBody();
//		iotype.setACCOUNT(cashDepositWithdrawal.getAccountNumber().toString());
//		// iotype.setMAKER(null);
//		// iotype.setMAKERSTAMP(null);
//		// iotype.setMODNO(null);
//
//		body.setChqBkDetailsIO(iotype);
//
//		req.setFCUBSHEADER(createHeaderAccService());
//		req.setFCUBSBODY(body);
//
//		return req;
//	}
////ReopenCustAccFS
//
//	public REOPENCUSTACCFSFSREQ reopenCustAccFS(CashDepositWithdrawalModel cashDepositWithdrawal) {
//		REOPENCUSTACCFSFSREQ req = new REOPENCUSTACCFSFSREQ();
//		REOPENCUSTACCFSFSREQ.FCUBSBODY body = new REOPENCUSTACCFSFSREQ.FCUBSBODY();
//		CustAccFullType iotype = new CustAccFullType();
//		// CashDepositWithdrawalModel cashDepositWithdrawal=(CashDepositWithdrawalModel)
//		// cashDepositService.fetchByTransId(transactionId).getBody();
//
////	IcCountryModel icCountryModel = new IcCountryModel();
////	CustomerInfoModel customerInfoModel=new CustomerInfoModel();
//		iotype.setACCTYPE(cashDepositWithdrawal.getAccountType());
//		iotype.setAUTHSTAT(cashDepositWithdrawal.getAuthStatus());
//		iotype.setBRN(cashDepositWithdrawal.getAccountBranch());
//		/*
//		 * iotype.setCOUNTRY(icCountryModel.getCountryName());
//		 * iotype.setCOUNTRYCODE(icCountryModel.getCountryCode()); iotype.setACC(null);
//		 * iotype.setAccclose(null); iotype.setAcccrdrlmtsMain(null);
//		 * iotype.setACCLS(null); iotype.setAccmaintinstr(null);
//		 * iotype.setACCOPENDT(null); iotype.setACCOUNTAUTOCLOSED(null);
//		 * iotype.setAccstatusMain(null); iotype.setAccSvcacsig(null);
//		 * iotype.setACSTMTCYCLE(null); iotype.setACSTMTCYCLE2(null);
//		 * iotype.setACSTMTCYCLE3(null); iotype.setACSTMTCYCLE3(null);
//		 * iotype.setACSTMTDAY(null); iotype.setACSTMTDAY2(null);
//		 * iotype.setACSTMTDAY3(null); iotype.setACSTMTTYPE3(null);
//		 * iotype.setACSTMTTYPEP(null); iotype.setACSTMTTYPS(null);
//		 * iotype.setADDR1(null); iotype.setADDR2(null); iotype.setADDR3(null);
//		 * iotype.setADESC(null); iotype.setALTACC(null); iotype.setAmountDates(null);
//		 * iotype.setAuthbicdetailsMain(null); iotype.setAUTOCHEQUEBOOKREQ(null);
//		 * iotype.setAUTODEBITCARDREQUEST(null); iotype.setAUTODEPBAL(null);
//		 * iotype.setCHECKER(null); iotype.setCHECKERSTAMP(null);
//		 * iotype.setCHQBOOK(null); iotype.setCLRBNKCD(null); iotype.setCRLMREVDT(null);
//		 * iotype.setCRLMSTDT(null); iotype.setCRSSTSTREQD(null);
//		 * iotype.setCRTXNLMT(null); iotype.setCustAcc(null);
//		 * iotype.setCustAccCard(null); iotype.setCustAccCheck(null);
//		 * iotype.setCustaccIcccspcn(null); iotype.setCustaccIcchspcn(null);
//		 * iotype.setCustaccIccinstr(null); iotype.setCustaccIccintpo(null);
//		 * iotype.setCustaccSicdiary(null); iotype.setCustaccStccusbl(null);
//		 * iotype.setCUSTNAME(null); iotype.setCUSTNO(null);
//		 * iotype.setCustomerAcc(null); iotype.setCustomerAcc1(null);
//		 * iotype.setDAYLIGHTLIMIT(null); iotype.setDFLTWAIVER(null);
//		 * iotype.setDoctypeRemarks(null); iotype.setESCROWACCOUNT(null);
//		 * iotype.setESCROWBRNCODE(null); iotype.setESCROWPERCENTAGE(null);
//		 * iotype.setESCROWTRN(null); iotype.setExtsysWsMaster(null);
//		 * iotype.setFLGEXCLRVRTRANS(null); iotype.setGENSTMTMV(null);
//		 * iotype.setGENSTMTMV2(null); iotype.setGENSTMTMV3(null);
//		 * iotype.setIBANACC(null); iotype.setIBANBNKCD(null);
//		 * iotype.setIntdetails(null); iotype.setInterimDetails(null);
//		 * iotype.setINTERMEDIARYREQUIRED(null); iotype.setJointholdersMain(null);
//		 * iotype.setLinkedentities(null); iotype.setLMTCCY(null); iotype.setLOC(null);
//		 * iotype.setMaster(null); iotype.setMAKER(null); iotype.setMAKERSTAMP(null);
//		 * iotype.setMASTERACC(null); iotype.setMEDIA(null); iotype.setMINREQBAL(null);
//		 * iotype.setMODNO(null); iotype.setMT110RECONREQD(null);
//		 * iotype.setNETREQ(null); iotype.setNOM1(null); iotype.setNOM2(null);
//		 * iotype.setNoticepref(null); iotype.setNSFBLKSTAT(null);
//		 * iotype.setOFFLINELIM(null); iotype.setOPMODE(null);
//		 * iotype.setPASSBOOKNUMBER(null); iotype.setPASSBOOKSTATUS(null);
//		 * iotype.setPAYINOPTION(null); iotype.setPRDLST(null); iotype.setPrdtxn(null);
//		 * iotype.setPREVSTMTBAL(null); iotype.setPREVSTMTBAL2(null);
//		 * iotype.setPREVSTMTBAL3(null); iotype.setPREVSTMTDT(null);
//		 * iotype.setPREVSTMTDT2(null); iotype.setPREVSTMTDT3(null);
//		 * iotype.setPREVSTMTNO(null); iotype.setPREVSTMTNO2(null);
//		 * iotype.setPREVSTMTNO3(null); iotype.setPRIVATECUSTOMER(null);
//		 * iotype.setPROJACC(null); iotype.setProvisionMain(null);
//		 * iotype.setREGCCAVL(null); iotype.setREGDAPP(null); iotype.setREGDENDT(null);
//		 * iotype.setREGDPER(null); iotype.setREGDSTDT(null);
//		 * iotype.setREPLCUSTSIG(null); iotype.setSDREFNO(null);
//		 * iotype.setSODNOTP(null); iotype.setSPCONDLST(null);
//		 * iotype.setSPCONDTXN(null); iotype.setStatement(null); iotype.setSTMTAC(null);
//		 * iotype.setSttmsCustAccount(null); iotype.setSttmsDebit(null);
//		 * iotype.setSUBLIMIT(null); iotype.setSWEEPIN(null); iotype.setSWEEPOUT(null);
//		 * iotype.setSWPTYPE(null); iotype.setCCY(null); iotype.setTddetails(null);
//		 * iotype.setTddetails(null); iotype.setATMCUSTACNO(null); iotype.setATM(null);
//		 * iotype.setATMBRN(null); iotype.setATMDCNTLIM(null); iotype.setATMDLIM(null);
//		 * iotype.setTODLIMENDT(null); iotype.setTODLIMIT(null);
//		 * iotype.setTODLIMSTDT(null); iotype.setTodRenew(null); iotype.setTRKREC(null);
//		 * iotype.setTXNLST(null); iotype.setTXNSTAT(null);
//		 * iotype.setUNCOLFUNDLIMIT(null);
//		 */
//
//		body.setCustAccountFull(iotype);
//
//		req.setFCUBSHEADER(createHeaderAccService());
//		req.setFCUBSBODY(body);
//
//		return req;
//	}
////ReopenCustAccIO
//
//	public REOPENCUSTACCIOPKREQ reopenCustAccIO(CashDepositWithdrawalModel cashDepositWithdrawal) {
//		REOPENCUSTACCIOPKREQ req = new REOPENCUSTACCIOPKREQ();
//		REOPENCUSTACCIOPKREQ.FCUBSBODY body = new REOPENCUSTACCIOPKREQ.FCUBSBODY();
//		CustAccReopenIOType iotype = new CustAccReopenIOType();
//		// CashDepositWithdrawalModel cashDepositWithdrawal=(CashDepositWithdrawalModel)
//		// cashDepositService.fetchByTransId(transactionId).getBody();
//		iotype.setACC(cashDepositWithdrawal.getAccountNumber().toString());
//		iotype.setBRN(cashDepositWithdrawal.getAccountBranch());
//		// iotype.setMAKER(null);
//		// iotype.setMAKERSTAMP(null);
//		// iotype.setMODNO(null);
//
//		body.setCustAccountIO(iotype);
//
//		req.setFCUBSHEADER(createHeaderAccService());
//		req.setFCUBSBODY(body);
//
//		return req;
//	}
//
//}
