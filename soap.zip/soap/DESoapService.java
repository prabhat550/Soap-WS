//package com.rumango.soap;
//
//import java.math.BigDecimal;
//import java.util.HashMap;
//import java.util.Map;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpHeaders;
//import org.springframework.http.HttpMethod;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.MediaType;
//import org.springframework.http.ResponseEntity;
//import org.springframework.stereotype.Service;
//import com.ws.api.accservice.QUERYACCBALIOFSRES;
//import com.ws.api.client.DESevicesImpl;
//import com.ws.api.deservice.CREATEDEMULTIOFFSETFSFSREQ;
//import com.ws.api.deservice.CREATEDEMULTIOFFSETFSFSRES;
//import com.ws.api.deservice.CREATEDEMULTIOFFSETFSFSRES.FCUBSBODY;
//import com.ws.api.deservice.DEBatchBrowserQueryIOType;
//import com.ws.api.deservice.DEMultiOffsetFullType;
//import com.ws.api.deservice.FCUBSHEADERType;
//import com.ws.api.deservice.QUERYDEBATCHBROWSERIOFSREQ;
//import com.ws.api.deservice.QUERYDEBRANCHRESTIOFSREQ;
//import com.ws.api.deservice.QUERYDEMULTIOFFSETIOFSREQ;
//import com.ws.api.deservice.QUERYMJRNLBOOKIOFSREQ;
//import com.ws.api.deservice.QUERYMJRNLTEMPLATEIOFSREQ;
//import com.ws.api.deservice.QUERYSINGLEJRNLIOFSREQ;
//import com.ws.api.deservice.QUERYTELLERIOFSREQ;
//import com.ws.api.deservice.REOPENDEBRANCHRESTFSFSREQ;
//import com.ws.api.deservice.REOPENDEBRANCHRESTIOPKREQ;
//import com.ws.api.util.SoapPasswordService;
//
//@Service
//public class DESoapService {
////	
////	@Autowired
////	FlexCubeCient flexCubeCient;
//
//	@Autowired
//	PropertyConfiguration propertyConfiguration;
//
//	DESevicesImpl dESevicesImpl = new DESevicesImpl();
//	SoapPasswordService soapPasswordService = new SoapPasswordService();
//
//	FCUBSHEADERType getHeader() {
//		String messageId = "RMQA" + String.format("%08d", soapPasswordService.getSecureRandom().nextInt(100000000));
//		com.ws.api.deservice.FCUBSHEADERType header1 = new com.ws.api.deservice.FCUBSHEADERType();
//		com.ws.api.deservice.UBSCOMPType ubsType = com.ws.api.deservice.UBSCOMPType.fromValue("FCUBS");
//		header1.setUBSCOMP(ubsType);
//		header1.setSOURCE("FCAT");
//		header1.setMSGID(messageId);
//		header1.setCORRELID(messageId);
//		header1.setUSERID("ADMINUSER1");
//		header1.setPASSWORD(soapPasswordService.encryptPassword(messageId));
//		header1.setBRANCH("000");
//		header1.setSERVICE("FCUBSDEService");
//		header1.setMODULEID("DE");
//		return header1;
//	}
//
//	public ResponseEntity<?> CreateDEMultiOffsetFS(CashDepositWithdrawalModel model) {
//
//		FCUBSHEADERType header = getHeader();
//		header.setACTION("NEW");
//		header.setFUNCTIONID("DEDMJONL");
//		header.setSERVICE("FCUBSDEService");
//		header.setOPERATION("CreateDEMultiOffset");
//
//		CREATEDEMULTIOFFSETFSFSREQ req = new CREATEDEMULTIOFFSETFSFSREQ();
//		CREATEDEMULTIOFFSETFSFSREQ.FCUBSBODY body = new CREATEDEMULTIOFFSETFSFSREQ.FCUBSBODY();
//
//		DEMultiOffsetFullType data = new DEMultiOffsetFullType();
//
//		data.setAccSVCSIGVR(null);
//		data.setAUTHSTAT(model.getAuthStatus());
//		data.setDEACCNO(model.getAccountNumber().toString());
//		data.setDEADDLTEXT(null);
//		data.setDEAMOUNT(new BigDecimal(model.getTotalAmount()));
//		data.setDEAUTHORIZEDBY(null);
//		data.setDEBATCHDESC(null);
//		data.setDEBATCHNUMBER(null);
//		data.setDECCYCD(null);
//		data.setDECURRNO(null);
//		data.setDEDATETIME(null);
//		data.setDEDESCRIPTION(null);
//		data.setDEDRCR(null);
//		data.setDEEXCHRATE(new BigDecimal(model.getExchangeRate()));
//		data.setDEFUNDID(null);
//		data.setDEINSTRUMENTNUMBER(null);
//		data.setDELCYAMOUNT(null);
//		data.setDEMAIN(null);
//		data.setDEMAKERDATETIME(null);
//		data.setDEOFFSET(null);
//		data.setDEREFNO(null);
//		data.setDETEMPLID(null);
//		data.setDETOTOFFSETAMT(null);
//		data.setDEVALUEDATE(null);
//		data.setDevwsBatchMaster1(null);
//		data.setMAKERID(model.getTellerId().toString());
//		data.setMisdetails(null);
//
//		body.setMultioffsetmasterFull(data);
//		req.setFCUBSBODY(body);
//		req.setFCUBSHEADER(header);
//		ResponseEntity<?> res = dESevicesImpl.createDEMultiOffsetFS(req);
//		FCUBSBODY res1 = (CREATEDEMULTIOFFSETFSFSRES.FCUBSBODY) res.getBody();
//		System.out.println(res1.getMultioffsetmasterFull().getDEAMOUNT());
//
//		return null;
//	}
//
//	public ResponseEntity<?> queryDEBatchBrowserIO(QUERYDEBATCHBROWSERIOFSREQ req) {
//
//		FCUBSHEADERType header = getHeader();
//		header.setACTION("NEW");
//		header.setFUNCTIONID("DEDMJONL");
//		header.setSERVICE("FCUBSDEService");
//		header.setOPERATION("CreateDEMultiOffset");
//
//		DEBatchBrowserQueryIOType value = new DEBatchBrowserQueryIOType();
//		value.setDEBATCHNUMBER(null);
//		value.setDEBRN(null);
//		QUERYDEBATCHBROWSERIOFSREQ flexreq = new QUERYDEBATCHBROWSERIOFSREQ();
//		QUERYDEBATCHBROWSERIOFSREQ.FCUBSBODY body = new QUERYDEBATCHBROWSERIOFSREQ.FCUBSBODY();
//		body.setBatchBrowserIO(value);
//		flexreq.setFCUBSHEADER(header);
//		flexreq.setFCUBSBODY(body);
//		ResponseEntity<?> res = dESevicesImpl.queryDEBatchBrowserIO(req);
//		FCUBSBODY res1 = (CREATEDEMULTIOFFSETFSFSRES.FCUBSBODY) res.getBody();
//		if (res1.getFCUBSERRORRESP() != null) {
//			String errorcode = res1.getFCUBSERRORRESP().get(0).getERROR().get(0).getECODE();
//			String errordesc = res1.getFCUBSERRORRESP().get(0).getERROR().get(0).getEDESC();
//			return ResponseEntity.status(HttpStatus.OK).body("Errorcode" + errorcode + "Errordesc" + errordesc);
//		}
//		return ResponseEntity.status(HttpStatus.OK).body(res1);
//	}
//
//	public ResponseEntity<?> queryDEBranchRestIO(QUERYDEBRANCHRESTIOFSREQ req) {
//		FCUBSHEADERType header = getHeader();
//		header.setACTION("NEW");
//		header.setFUNCTIONID("DEDMJONL");
//		header.setSERVICE("FCUBSDEService");
//		header.setOPERATION("CreateDEMultiOffset");
//
//		DEBatchBrowserQueryIOType value = new DEBatchBrowserQueryIOType();
//		value.setDEBATCHNUMBER(null);
//		value.setDEBRN(null);
//		QUERYDEBATCHBROWSERIOFSREQ flexreq = new QUERYDEBATCHBROWSERIOFSREQ();
//		QUERYDEBATCHBROWSERIOFSREQ.FCUBSBODY body = new QUERYDEBATCHBROWSERIOFSREQ.FCUBSBODY();
//		body.setBatchBrowserIO(value);
//		flexreq.setFCUBSHEADER(header);
//		flexreq.setFCUBSBODY(body);
//		ResponseEntity<?> res = dESevicesImpl.queryDEBranchRestIO(req);
//		FCUBSBODY res1 = (CREATEDEMULTIOFFSETFSFSRES.FCUBSBODY) res.getBody();
//		if (res1.getFCUBSERRORRESP() != null) {
//			String errorcode = res1.getFCUBSERRORRESP().get(0).getERROR().get(0).getECODE();
//			String errordesc = res1.getFCUBSERRORRESP().get(0).getERROR().get(0).getEDESC();
//			return ResponseEntity.status(HttpStatus.OK).body("Errorcode" + errorcode + "Errordesc" + errordesc);
//		}
//		return ResponseEntity.status(HttpStatus.OK).body(res1);
//	}
//
//	public ResponseEntity<?> queryDEMultiOffsetIO(QUERYDEMULTIOFFSETIOFSREQ req) {
//		FCUBSHEADERType header = getHeader();
//		header.setACTION("NEW");
//		header.setFUNCTIONID("DEDMJONL");
//		header.setSERVICE("FCUBSDEService");
//		header.setOPERATION("CreateDEMultiOffset");
//
//		DEBatchBrowserQueryIOType value = new DEBatchBrowserQueryIOType();
//		value.setDEBATCHNUMBER(null);
//		value.setDEBRN(null);
//		QUERYDEBATCHBROWSERIOFSREQ flexreq = new QUERYDEBATCHBROWSERIOFSREQ();
//		QUERYDEBATCHBROWSERIOFSREQ.FCUBSBODY body = new QUERYDEBATCHBROWSERIOFSREQ.FCUBSBODY();
//		body.setBatchBrowserIO(value);
//		flexreq.setFCUBSHEADER(header);
//		flexreq.setFCUBSBODY(body);
//		ResponseEntity<?> res = dESevicesImpl.queryDEMultiOffsetIO(req);
//		FCUBSBODY res1 = (CREATEDEMULTIOFFSETFSFSRES.FCUBSBODY) res.getBody();
//		if (res1.getFCUBSERRORRESP() != null) {
//			String errorcode = res1.getFCUBSERRORRESP().get(0).getERROR().get(0).getECODE();
//			String errordesc = res1.getFCUBSERRORRESP().get(0).getERROR().get(0).getEDESC();
//			return ResponseEntity.status(HttpStatus.OK).body("Errorcode" + errorcode + "Errordesc" + errordesc);
//		}
//		return ResponseEntity.status(HttpStatus.OK).body(res1);
//	}
//
//	public ResponseEntity<?> queryMjrnlbookIO(QUERYMJRNLBOOKIOFSREQ req) {
//		FCUBSHEADERType header = getHeader();
//		header.setACTION("NEW");
//		header.setFUNCTIONID("DEDMJONL");
//		header.setSERVICE("FCUBSDEService");
//		header.setOPERATION("CreateDEMultiOffset");
//
//		DEBatchBrowserQueryIOType value = new DEBatchBrowserQueryIOType();
//		value.setDEBATCHNUMBER(null);
//		value.setDEBRN(null);
//		QUERYDEBATCHBROWSERIOFSREQ flexreq = new QUERYDEBATCHBROWSERIOFSREQ();
//		QUERYDEBATCHBROWSERIOFSREQ.FCUBSBODY body = new QUERYDEBATCHBROWSERIOFSREQ.FCUBSBODY();
//		body.setBatchBrowserIO(value);
//		flexreq.setFCUBSHEADER(header);
//		flexreq.setFCUBSBODY(body);
//		ResponseEntity<?> res = dESevicesImpl.queryMjrnlbookIO(req);
//		FCUBSBODY res1 = (CREATEDEMULTIOFFSETFSFSRES.FCUBSBODY) res.getBody();
//		if (res1.getFCUBSERRORRESP() != null) {
//			String errorcode = res1.getFCUBSERRORRESP().get(0).getERROR().get(0).getECODE();
//			String errordesc = res1.getFCUBSERRORRESP().get(0).getERROR().get(0).getEDESC();
//			return ResponseEntity.status(HttpStatus.OK).body("Errorcode" + errorcode + "Errordesc" + errordesc);
//		}
//		return ResponseEntity.status(HttpStatus.OK).body(res1);
//	}
//
//	public ResponseEntity<?> queryMjrnlTemplateIO(QUERYMJRNLTEMPLATEIOFSREQ req) {
//		FCUBSHEADERType header = getHeader();
//		header.setACTION("NEW");
//		header.setFUNCTIONID("DEDMJONL");
//		header.setSERVICE("FCUBSDEService");
//		header.setOPERATION("CreateDEMultiOffset");
//
//		DEBatchBrowserQueryIOType value = new DEBatchBrowserQueryIOType();
//		value.setDEBATCHNUMBER(null);
//		value.setDEBRN(null);
//		QUERYDEBATCHBROWSERIOFSREQ flexreq = new QUERYDEBATCHBROWSERIOFSREQ();
//		QUERYDEBATCHBROWSERIOFSREQ.FCUBSBODY body = new QUERYDEBATCHBROWSERIOFSREQ.FCUBSBODY();
//		body.setBatchBrowserIO(value);
//		flexreq.setFCUBSHEADER(header);
//		flexreq.setFCUBSBODY(body);
//		ResponseEntity<?> res = dESevicesImpl.queryMjrnlTemplateIO(req);
//		FCUBSBODY res1 = (CREATEDEMULTIOFFSETFSFSRES.FCUBSBODY) res.getBody();
//		if (res1.getFCUBSERRORRESP() != null) {
//			String errorcode = res1.getFCUBSERRORRESP().get(0).getERROR().get(0).getECODE();
//			String errordesc = res1.getFCUBSERRORRESP().get(0).getERROR().get(0).getEDESC();
//			return ResponseEntity.status(HttpStatus.OK).body("Errorcode" + errorcode + "Errordesc" + errordesc);
//		}
//		return ResponseEntity.status(HttpStatus.OK).body(res1);
//		}
//	
//
//	public ResponseEntity<?> querySingleJrnlIO(QUERYSINGLEJRNLIOFSREQ req) {
//		FCUBSHEADERType header = getHeader();
//		header.setACTION("NEW");
//		header.setFUNCTIONID("DEDMJONL");
//		header.setSERVICE("FCUBSDEService");
//		header.setOPERATION("CreateDEMultiOffset");
//
//		DEBatchBrowserQueryIOType value = new DEBatchBrowserQueryIOType();
//		value.setDEBATCHNUMBER(null);
//		value.setDEBRN(null);
//		QUERYDEBATCHBROWSERIOFSREQ flexreq = new QUERYDEBATCHBROWSERIOFSREQ();
//		QUERYDEBATCHBROWSERIOFSREQ.FCUBSBODY body = new QUERYDEBATCHBROWSERIOFSREQ.FCUBSBODY();
//		body.setBatchBrowserIO(value);
//		flexreq.setFCUBSHEADER(header);
//		flexreq.setFCUBSBODY(body);
//		ResponseEntity<?> res = dESevicesImpl.querySingleJrnlIO(req);
//		FCUBSBODY res1 = (CREATEDEMULTIOFFSETFSFSRES.FCUBSBODY) res.getBody();
//		if (res1.getFCUBSERRORRESP() != null) {
//			String errorcode = res1.getFCUBSERRORRESP().get(0).getERROR().get(0).getECODE();
//			String errordesc = res1.getFCUBSERRORRESP().get(0).getERROR().get(0).getEDESC();
//			return ResponseEntity.status(HttpStatus.OK).body("Errorcode" + errorcode + "Errordesc" + errordesc);
//		}
//		return ResponseEntity.status(HttpStatus.OK).body(res1);
//	}
//
//	public ResponseEntity<?> queryTellerIO(QUERYTELLERIOFSREQ req) {
//		FCUBSHEADERType header = getHeader();
//		header.setACTION("NEW");
//		header.setFUNCTIONID("DEDMJONL");
//		header.setSERVICE("FCUBSDEService");
//		header.setOPERATION("CreateDEMultiOffset");
//
//		DEBatchBrowserQueryIOType value = new DEBatchBrowserQueryIOType();
//		value.setDEBATCHNUMBER(null);
//		value.setDEBRN(null);
//		QUERYDEBATCHBROWSERIOFSREQ flexreq = new QUERYDEBATCHBROWSERIOFSREQ();
//		QUERYDEBATCHBROWSERIOFSREQ.FCUBSBODY body = new QUERYDEBATCHBROWSERIOFSREQ.FCUBSBODY();
//		body.setBatchBrowserIO(value);
//		flexreq.setFCUBSHEADER(header);
//		flexreq.setFCUBSBODY(body);
//		ResponseEntity<?> res = dESevicesImpl.queryTellerIO(req);
//		FCUBSBODY res1 = (CREATEDEMULTIOFFSETFSFSRES.FCUBSBODY) res.getBody();
//		if (res1.getFCUBSERRORRESP() != null) {
//			String errorcode = res1.getFCUBSERRORRESP().get(0).getERROR().get(0).getECODE();
//			String errordesc = res1.getFCUBSERRORRESP().get(0).getERROR().get(0).getEDESC();
//			return ResponseEntity.status(HttpStatus.OK).body("Errorcode" + errorcode + "Errordesc" + errordesc);
//		}
//		return ResponseEntity.status(HttpStatus.OK).body(res1);
//	}
//
//	public ResponseEntity<?> reopenDEBranchRestFS(REOPENDEBRANCHRESTFSFSREQ req) {
//		FCUBSHEADERType header = getHeader();
//		header.setACTION("NEW");
//		header.setFUNCTIONID("DEDMJONL");
//		header.setSERVICE("FCUBSDEService");
//		header.setOPERATION("CreateDEMultiOffset");
//
//		DEBatchBrowserQueryIOType value = new DEBatchBrowserQueryIOType();
//		value.setDEBATCHNUMBER(null);
//		value.setDEBRN(null);
//		QUERYDEBATCHBROWSERIOFSREQ flexreq = new QUERYDEBATCHBROWSERIOFSREQ();
//		QUERYDEBATCHBROWSERIOFSREQ.FCUBSBODY body = new QUERYDEBATCHBROWSERIOFSREQ.FCUBSBODY();
//		body.setBatchBrowserIO(value);
//		flexreq.setFCUBSHEADER(header);
//		flexreq.setFCUBSBODY(body);
//		ResponseEntity<?> res = dESevicesImpl.reopenDEBranchRestFS(req);
//		FCUBSBODY res1 = (CREATEDEMULTIOFFSETFSFSRES.FCUBSBODY) res.getBody();
//		if (res1.getFCUBSERRORRESP() != null) {
//			String errorcode = res1.getFCUBSERRORRESP().get(0).getERROR().get(0).getECODE();
//			String errordesc = res1.getFCUBSERRORRESP().get(0).getERROR().get(0).getEDESC();
//			return ResponseEntity.status(HttpStatus.OK).body("Errorcode" + errorcode + "Errordesc" + errordesc);
//		}
//		return ResponseEntity.status(HttpStatus.OK).body(res1);
//	}
//
//	public ResponseEntity<?> reopenDEBranchRestIO(REOPENDEBRANCHRESTIOPKREQ req) {
//		FCUBSHEADERType header = getHeader();
//		header.setACTION("NEW");
//		header.setFUNCTIONID("DEDMJONL");
//		header.setSERVICE("FCUBSDEService");
//		header.setOPERATION("CreateDEMultiOffset");
//
//		DEBatchBrowserQueryIOType value = new DEBatchBrowserQueryIOType();
//		value.setDEBATCHNUMBER(null);
//		value.setDEBRN(null);
//		QUERYDEBATCHBROWSERIOFSREQ flexreq = new QUERYDEBATCHBROWSERIOFSREQ();
//		QUERYDEBATCHBROWSERIOFSREQ.FCUBSBODY body = new QUERYDEBATCHBROWSERIOFSREQ.FCUBSBODY();
//		body.setBatchBrowserIO(value);
//		flexreq.setFCUBSHEADER(header);
//		flexreq.setFCUBSBODY(body);
//		ResponseEntity<?> res = dESevicesImpl.reopenDEBranchRestIO(req);
//		FCUBSBODY res1 = (CREATEDEMULTIOFFSETFSFSRES.FCUBSBODY) res.getBody();
//		if (res1.getFCUBSERRORRESP() != null) {
//			String errorcode = res1.getFCUBSERRORRESP().get(0).getERROR().get(0).getECODE();
//			String errordesc = res1.getFCUBSERRORRESP().get(0).getERROR().get(0).getEDESC();
//			return ResponseEntity.status(HttpStatus.OK).body("Errorcode" + errorcode + "Errordesc" + errordesc);
//		}
//		return ResponseEntity.status(HttpStatus.OK).body(res1);
//	}
//}
